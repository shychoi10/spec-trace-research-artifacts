#!/usr/bin/env python3
"""Independently replay projected text from XML token/ancestor addresses.

Does not import the producer or certify semantic labels or full Word rendering.
Checks all frozen inputs and both old and corrected views, preserving evidence
for every changed paragraph and examples with native XML addresses.
"""
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
OUTPUT = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation/standards_changes/transition_library/content_projection'
WORD = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
MATH = 'http://schemas.openxmlformats.org/officeDocument/2006/math'
DRAW = 'http://schemas.openxmlformats.org/drawingml/2006/main'
W = '{' + WORD + '}'


def bind(path):
    digest = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1048576), b''):
            digest.update(block)
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def check(item):
    path = ROOT / item['path']
    if bind(path) != item:
        raise ValueError('Binding mismatch: ' + str(item['path']))
    return path


def split(tag):
    uri, local = tag[1:].split('}', 1) if tag.startswith('{') else ('', tag)
    return uri, local


def inspect(row):
    input_paths = [check(item) for item in row['reading_inputs']]
    corrected = json.loads(check(row['projection']).read_text())
    old_items = {a['prior_projection']['path']: a['prior_projection'] for a in row['aliases']}
    for alias in row['aliases']:
        check(alias['native'])
    old = [json.loads(check(item).read_text()) for item in old_items.values()]
    with zipfile.ZipFile(input_paths[0]) as archive:
        xml = archive.read('word/document.xml')
        root = ET.fromstring(xml)
        parts = archive.namelist()
    parents = {child: parent for parent in root.iter() for child in parent}
    paragraphs = list(root.iter(W + 'p'))
    if len(paragraphs) != len(corrected['paragraphs']) or any(len(x['paragraphs']) != len(paragraphs) for x in old):
        raise ValueError('Paragraph coverage differs')
    addresses = {root: '/w:document'}
    for parent in root.iter():
        numbers = Counter()
        for child in parent:
            numbers[child.tag] += 1
            uri, local = split(child.tag)
            prefix = {WORD: 'w', MATH: 'm', DRAW: 'a'}.get(uri, '{' + uri + '}')
            addresses[child] = addresses[parent] + '/' + prefix + ':' + local + '[' + str(numbers[child.tag]) + ']'
    removed, changes, examples = Counter(), [], []
    real_tabs = 0
    for index, paragraph in enumerate(paragraphs):
        contributions = []
        for token in paragraph.iter():
            uri, local = split(token.tag)
            if local not in {'t', 'delText', 'tab', 'br', 'cr'}:
                continue
            ancestors = []
            parent = parents.get(token)
            while parent is not None and parent is not paragraph:
                ancestors.append(parent); parent = parents.get(parent)
            is_property = any(split(p.tag)[0] in {WORD, MATH, DRAW} and
                              (split(p.tag)[1].endswith('Pr') or split(p.tag)[1].endswith('PrChange')) for p in ancestors)
            valid = (local == 't' and uri in {WORD, MATH, DRAW}) or (uri == WORD and local in {'delText', 'tab', 'br', 'cr'})
            if not is_property and not valid:
                raise ValueError('Unsupported content token: ' + token.tag)
            if local == 'tab' and not is_property:
                if parents[token].tag != W + 'r':
                    raise ValueError('Content tab lacks a run parent: ' + addresses[token])
                real_tabs += 1
            value = token.text or '' if local in {'t', 'delText'} else '\t' if local == 'tab' else '\n'
            contributions.append((token, ancestors, is_property, value))
        before_values, after_values, old_before, old_after, emitted_removed = [], [], [], [], []
        for token, ancestors, is_property, value in contributions:
            for view, original, new in [('before', old_before, before_values), ('after', old_after, after_values)]:
                forbidden = {'ins', 'moveTo'} if view == 'before' else {'del', 'moveFrom'}
                if any(split(p.tag)[1] in forbidden for p in ancestors):
                    continue
                original.append(value)
                if is_property:
                    removed[view + ':' + token.tag] += len(value)
                    emitted_removed.append({'view': view, 'xml_path': addresses[token], 'tag': token.tag, 'emitted': value})
                else:
                    new.append(value)
        expected = {'paragraph_index': index, 'before': ''.join(before_values), 'after': ''.join(after_values),
                    'insertions': sum(x.tag == W + 'ins' for x in paragraph.iter()),
                    'deletions': sum(x.tag == W + 'del' for x in paragraph.iter()),
                    'style': next((x.get(W + 'val') for x in paragraph.findall(W + 'pPr/' + W + 'pStyle')), None)}
        if expected != corrected['paragraphs'][index]:
            raise ValueError('Corrected XML replay differs at ' + str(index))
        for prior in old:
            prior_expected = {**expected, 'before': ''.join(old_before), 'after': ''.join(old_after)}
            if prior_expected != prior['paragraphs'][index]:
                raise ValueError('Prior XML replay differs at ' + str(index))
        if old_before != before_values or old_after != after_values:
            changes.append({'paragraph_index': index, 'removed_tokens': emitted_removed})
            if len(examples) < 3:
                examples.append({'paragraph_index': index, 'paragraph_xml_path': addresses[paragraph],
                                 'prior_before': ''.join(old_before), 'prior_after': ''.join(old_after),
                                 'corrected_before': expected['before'], 'corrected_after': expected['after'],
                                 'removed_tokens': emitted_removed})
    for key, value in [('package_parts', parts), ('embedded_object_count', sum(x.tag == W + 'object' for x in root.iter())),
                       ('drawing_count', sum(x.tag == W + 'drawing' for x in root.iter()))]:
        if corrected[key] != value or any(prior[key] != value for prior in old):
            raise ValueError('Non-text package inventory differs: ' + key)
    limitations = Counter(split(x.tag)[1] for x in root.iter() if split(x.tag)[1] in
                          {'AlternateContent', 'instrText', 'fldSimple', 'sym', 'softHyphen', 'noBreakHyphen'})
    limitations['structural_revision_markers'] = sum(x.tag in {W + 'ins', W + 'del'} and parents.get(x) is not None and
                                                     parents[x].tag in {W + 'pPr', W + 'rPr', W + 'trPr'} for x in root.iter())
    return {'reading_input': row['reading_inputs'][0], 'projection': row['projection'], 'paragraphs_verified': len(paragraphs),
            'changed_paragraphs': changes, 'examples': examples, 'property_characters_removed': dict(removed),
            'real_run_tabs_retained': real_tabs, 'unresolved_rendering_feature_counts': dict(limitations)}


def main():
    manifest = json.loads((OUTPUT / 'manifest.json').read_text())
    check(manifest['producer']); check(manifest['allocation'])
    allocation = json.loads(check(manifest['allocation']).read_text())
    for item in allocation['manifests']:
        check(item)
    rows = [json.loads(line) for line in check(manifest['output']).open()]
    if len(rows) != len(allocation['groups']) or [r['reading_sha256'] for r in rows] != [r['reading_sha256'] for r in allocation['groups']]:
        raise ValueError('Allocation coverage differs')
    totals, limitations = Counter(), Counter()
    paragraphs, changed, real_tabs = 0, 0, 0
    with (OUTPUT / 'verification_rows.jsonl').open('x') as handle, ProcessPoolExecutor(max_workers=4) as pool:
        for row in pool.map(inspect, rows, chunksize=1):
            handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n'); handle.flush()
            paragraphs += row['paragraphs_verified']; changed += len(row['changed_paragraphs'])
            real_tabs += row['real_run_tabs_retained']; totals.update(row['property_characters_removed'])
            limitations.update(row['unresolved_rendering_feature_counts'])
    result = {'status': 'PASS', 'producer': bind(Path(__file__)), 'projection_manifest': bind(OUTPUT / 'manifest.json'),
              'output': bind(OUTPUT / 'verification_rows.jsonl'), 'created_utc': datetime.now(timezone.utc).isoformat(),
              'reading_inputs': len(rows), 'paragraphs_verified': paragraphs, 'changed_paragraphs': changed,
              'property_characters_removed': dict(totals), 'real_run_tabs_retained': real_tabs,
              'unresolved_rendering_feature_counts': dict(limitations),
              'scope': 'Independent token/ancestor replay of every old and corrected paragraph and package inventory. Every text difference is explained by excluded properties. Raw native bytes and prior bindings checked. Not full Word rendering or semantic verification.'}
    with (OUTPUT / 'verification.json').open('x') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2); handle.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in {'producer', 'projection_manifest', 'output'}}))


if __name__ == '__main__':
    main()
