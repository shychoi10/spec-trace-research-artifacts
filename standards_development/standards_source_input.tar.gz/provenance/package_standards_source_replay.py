#!/usr/bin/env python3
"""Prepare an independently replayable, exposed official-source input bundle.

Only packages already frozen development inputs and their bound provenance.
Publication and anonymous download verification are separate recorded actions.
"""
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile

import run_compatible_standards_control as compatible
from verify_standards_source_replay import verify

ROOT = compatible.ROOT
BASE = compatible.control.BASE
OUTPUT = BASE / 'development/source_replay_bundle'


def fingerprint(path):
    raw = path.read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def main():
    plan = compatible.check_plan()
    source = json.loads(compatible.control.checked(plan['source_units']).read_text())
    OUTPUT.mkdir(exist_ok=False)
    (OUTPUT / 'objects').mkdir()
    (OUTPUT / 'provenance').mkdir()
    paths, objects, bindings = {}, {}, {}

    def source_object(bound):
        path = ROOT / bound['path']
        actual = fingerprint(path)
        if actual['sha256'] != bound['sha256'] or ('bytes' in bound and actual['bytes'] != bound['bytes']):
            raise ValueError('Changed source provenance: ' + bound['path'])
        digest = actual['sha256']
        if digest not in objects:
            suffix = path.suffix.lower()
            filename = 'objects/' + digest + suffix
            shutil.copyfile(path, OUTPUT / filename)
            objects[digest] = filename
        paths[bound['path']] = objects[digest]
        bindings[bound['path']] = actual

    def collect(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str):
                source_object(value)
            for child in value.values():
                collect(child)
        elif isinstance(value, list):
            for child in value:
                collect(child)

    collect(source)
    for row in source['metadata']:
        if 'source_path' in row:
            source_object({'path': row['source_path'], 'sha256': row['source_sha256']})
    for filename in ['source_units.json', 'source_packet.txt', 'questions.json', 'prompts.json', 'model_spec.json']:
        key = Path(filename).stem
        shutil.copyfile(compatible.control.checked(plan[key]), OUTPUT / filename)
    shutil.copyfile(compatible.ACTIVE / 'plan.json', OUTPUT / 'plan.json')
    shutil.copyfile(compatible.control.checked(plan['reference']), OUTPUT / 'development_reference.json')
    shutil.copyfile(Path(__file__).with_name('verify_standards_source_replay.py'), OUTPUT / 'verify.py')
    provenance = [Path(__file__), Path(compatible.__file__),
        Path(__file__).with_name('project_standards_content.py'),
        Path(__file__).with_name('verify_standards_content.py'),
        Path(__file__).with_name('compact_standards_full_source_control.py'),
        Path(__file__).with_name('run_standards_full_source_control.py'),
        Path(__file__).with_name('run_corrected_standards_control.py'),
        compatible.PARENT / 'input_capacity.json', compatible.PARENT / 'source_feature_readback.json',
        compatible.PARENT / 'correction_verification.json',
        compatible.PARENT / 'runtime_loaded_compatibility/verification.json',
        compatible.PARENT / 'runtime_compatibility/failure.json',
        compatible.PARENT / 'runtime_compatibility/server.log',
        compatible.PARENT / 'runtime_compatibility_interruption.json']
    for path in provenance:
        label = path.name
        if label in {'verification.json', 'failure.json', 'server.log'}:
            label = path.parent.name + '_' + label
        shutil.copyfile(path, OUTPUT / 'provenance' / label)
    listing = []
    for unit in source['units']:
        occurrence = unit['occurrences'][0]
        native = paths[occurrence['native']['path']]
        reading = paths[occurrence['conversion']['derived']['path']] if occurrence.get('conversion') else native
        listing.append({'id': unit['id'], 'native': native, 'reading_input': reading,
            'converted_reading_aid': occurrence.get('conversion') is not None,
            'native_aliases': len(unit['occurrences']), 'paragraphs': len(unit['paragraphs'])})
    (OUTPUT / 'native_documents.json').write_text(json.dumps(listing, indent=2) + '\n')
    with (OUTPUT / 'blank_judgements.jsonl').open('x') as stream:
        questions = json.loads((OUTPUT / 'questions.json').read_text())['questions']
        for question in questions:
            stream.write(json.dumps({'question_id': question['id'], 'question': question['question'],
                'annotator': None, 'answer': None, 'claims': [], 'evidence': [], 'unresolved_scope': [],
                'annotation_completed': False, 'independent_human_judgement': None}) + '\n')
    readme = '''# Official-source development input replay

This exposed TS 38.314 V18.0.0→V19.0.0 development family supplies 21
byte-distinct native documents (24 occurrences), 5,786 XML paragraphs, 16
literal collected metadata rows and four fixed questions. It is an input
resource for evaluating what the supplied official records support.

From the extracted directory run `python3 -B verify.py .`. Python 3.11+
standard library only; no repository, model, network, GPU or credentials are
required. The verifier replays native archive members, paragraph projections,
spreadsheet/CSV field values, input serialization and development reference
coordinates. This performs no inference and establishes no semantic accuracy.

`native_documents.json` maps source IDs to actual original files and reading
aids. `source_units.json` retains every alias and original source binding.
`source_packet.txt` is the exact complete model input, with blanks and tracked
text preserved; `prompts.json` contains its four exact message inputs.
`objects/` also contains bound archive containers and prior projection aids
for provenance. Their unselected members are not additional model inputs.
`manifest.json` maps original repository paths to packaged objects.

Two TSG cover DOC files have converted DOCX reading aids. The original DOC
remains authoritative; conversion fidelity is not certified. XML paragraph
numbers are not printed page numbers. The bounded BEFORE/AFTER text views
do not resolve structural revisions, fields, alternate content, images or
full equation geometry. Consult the native files when layout is material.

`development_reference.json` contains source-inspected assistant development
claims, separately from the prompts. It is neither blinded nor independent
semantic gold. `blank_judgements.jsonl` has no completed annotations. Actual
human judgements, model responses and measured method superiority are all
absent. This is not a completed independently labelled benchmark.

`plan.json` records the pinned local model and effective execution settings.
The model and executable are not bundled. Their original hashes and sources
are retained; provenance code retains repository paths and is not a standalone
inference runner. The only runtime repairs use the full context size as a
nonnegative `repeat_last_n` and resolve the relocated pinned shared libraries.
The historical incompatibilities are preserved under `provenance/`.

Native standard, CR and liaison documents retain their original attribution
and notices. This resource does not claim authorship or relicensing of them.
Each document's record and archive origin is retained in `source_units.json`.

''' + '\n'.join(f"- {row['id']}: [native file]({row['native']}); {row['paragraphs']} paragraphs" + ('; [converted reading aid](' + row['reading_input'] + ')' if row['converted_reading_aid'] else '') for row in listing) + '\n'
    (OUTPUT / 'README.md').write_text(readme)
    files = {str(path.relative_to(OUTPUT)): fingerprint(path) for path in sorted(OUTPUT.rglob('*')) if path.is_file()}
    manifest = {'kind': 'standards_whole_source_development_input_replay',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'files': files,
        'source_path_objects': paths, 'original_source_bindings': bindings,
        'source_families': 1, 'source_units': len(source['units']), 'native_occurrences': 24,
        'model_responses_included': 0, 'independent_human_labels': 0, 'semantic_accuracy': None,
        'public_upload': False, 'doi': None,
        'preparer': compatible.control.utility.binding(Path(__file__)),
        'frozen_control_plan': compatible.control.utility.binding(compatible.ACTIVE / 'plan.json')}
    (OUTPUT / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    local = verify(OUTPUT)
    archive_path = BASE / 'development/standards_source_input.tar.gz'
    with archive_path.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for path in sorted(OUTPUT.rglob('*')):
                if path.is_file():
                    info = archive.gettarinfo(str(path), arcname=str(path.relative_to(OUTPUT)))
                    info.uid = info.gid = info.mtime = 0; info.uname = info.gname = ''; info.mode = 0o644
                    archive.addfile(info, io.BytesIO(path.read_bytes()))
    with tempfile.TemporaryDirectory(prefix='standards-native-input-replay-') as temporary:
        outside = Path(temporary)
        with tarfile.open(archive_path) as archive:
            archive.extractall(outside, filter='data')
        result = subprocess.run([sys.executable, '-B', str(outside / 'verify.py'), str(outside)], cwd=outside, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError('Outside-repository input replay failed: ' + result.stderr)
        outside_replay = json.loads(result.stdout)
    report = {'status': 'LOCAL_PACKAGE_AND_OUTSIDE_REPOSITORY_NATIVE_REPLAY_PASS',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'archive': compatible.control.utility.binding(archive_path),
        'manifest': compatible.control.utility.binding(OUTPUT / 'manifest.json'),
        'local_replay': local, 'outside_repository_replay': outside_replay,
        'public_upload': False, 'anonymous_download_verified': False, 'independent_human_labels': 0}
    compatible.control.write(BASE / 'development/source_replay_verification.json', report)
    print(json.dumps(report))


if __name__ == '__main__':
    main()
