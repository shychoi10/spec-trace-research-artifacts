#!/usr/bin/env python3
"""Create separately bound content projections; never replace frozen inputs.

Repairs property tab stops being emitted as text. This is input fidelity work,
not a semantic annotation, incorporation test or method improvement result.
"""
from __future__ import annotations

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
BASE = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation/standards_changes'
LIBRARY = BASE / 'transition_library'
OUTPUT = LIBRARY / 'content_projection'
W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
SCOPE = ('word/document.xml paragraph content tokens, excluding property subtrees. '
         'Word run text, deleted text, real run tabs/breaks and textual math/drawing tokens are retained. '
         'BEFORE/AFTER apply inline insertion/deletion/move containers within each enumerated paragraph. '
         'Paragraph numbers include blanks and are XML enumeration, not page positions. '
         'Paragraph/table structural revisions, field evaluation, alternate-content branch selection, '
         'headers, footnotes, images, drawing geometry and full math layout are not resolved. '
         'This is not a certified rendering of a published or fully revision-accepted document.')
REFERENCES = [
    'https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.tabstop?view=openxml-3.0.1',
    'https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.tabchar?view=openxml-3.0.1',
    'https://learn.microsoft.com/en-us/dotnet/api/documentformat.openxml.wordprocessing.deletedrun?view=openxml-3.0.1',
]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def binding(path):
    return {'path': str(path.relative_to(ROOT)), 'sha256': sha(path), 'bytes': path.stat().st_size}


def checked(item):
    path = ROOT / item['path']
    if path.stat().st_size != item['bytes'] or sha(path) != item['sha256']:
        raise ValueError('Changed source: ' + item['path'])
    return path


def write(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def property_element(tag):
    namespace, _, local = tag.rpartition('}')
    return namespace + '}' in {W, M, A} and (local.endswith('Pr') or local.endswith('PrChange'))


def project_docx(data):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        root = ET.fromstring(archive.read('word/document.xml'))
        parts = archive.namelist()

    def content(element, view):
        tag = element.tag
        if property_element(tag):
            return ''
        if view == 'before' and tag in {W + 'ins', W + 'moveTo'}:
            return ''
        if view == 'after' and tag in {W + 'del', W + 'moveFrom'}:
            return ''
        if tag in {W + 't', W + 'delText', M + 't', A + 't'}:
            return element.text or ''
        if tag == W + 'tab':
            return '\t'
        if tag in {W + 'br', W + 'cr'}:
            return '\n'
        # Do not silently discard a previously interpreted token in an unknown
        # namespace. Preserve the failure and investigate before further use.
        if tag.rsplit('}', 1)[-1] in {'t', 'delText', 'tab', 'br', 'cr'}:
            raise ValueError('Unresolved token namespace: ' + tag)
        return ''.join(content(child, view) for child in element)

    paragraphs = []
    for index, paragraph in enumerate(root.iter(W + 'p')):
        style = paragraph.find(W + 'pPr/' + W + 'pStyle')
        paragraphs.append({'paragraph_index': index, 'before': content(paragraph, 'before'),
                           'after': content(paragraph, 'after'),
                           'insertions': len(list(paragraph.iter(W + 'ins'))),
                           'deletions': len(list(paragraph.iter(W + 'del'))),
                           'style': style.get(W + 'val') if style is not None else None})
    return {'paragraphs': paragraphs, 'projection_scope': SCOPE, 'package_parts': parts,
            'embedded_object_count': len(list(root.iter(W + 'object'))),
            'drawing_count': len(list(root.iter(W + 'drawing')))}


def allocate():
    manifests = [LIBRARY / 'sources.json', LIBRARY / 'legacy_conversion/sources.json',
                 LIBRARY / 'tsg_inputs/sources.json',
                 BASE / 'development/full_source_control/execution/source_units.json']
    groups = {}

    def visit(value, manifest, pointer):
        if isinstance(value, dict):
            if isinstance(value.get('projection'), dict) and isinstance(value.get('native'), dict):
                native = value['native']
                reading = value.get('reading_input') or (value.get('conversion') or {}).get('derived') or native
                if Path(reading['path']).suffix.lower() != '.docx':
                    raise ValueError('No DOCX reading input: ' + str(pointer))
                group = groups.setdefault(reading['sha256'], {'reading_inputs': [], 'aliases': []})
                if reading not in group['reading_inputs']:
                    group['reading_inputs'].append(reading)
                group['aliases'].append({'manifest': str(manifest.relative_to(ROOT)), 'json_pointer': pointer,
                                        'native': native, 'prior_projection': value['projection'],
                                        'conversion': value.get('conversion')})
            # Legacy conversion entries use original/derived instead of native.
            elif value.get('status') == 'converted' and value.get('projection') and value.get('derived'):
                reading = value['derived']
                group = groups.setdefault(reading['sha256'], {'reading_inputs': [], 'aliases': []})
                if reading not in group['reading_inputs']:
                    group['reading_inputs'].append(reading)
                group['aliases'].append({'manifest': str(manifest.relative_to(ROOT)), 'json_pointer': pointer,
                                        'native': value['original'], 'prior_projection': value['projection'],
                                        'conversion': {'derived': reading, 'full_fidelity_verified': False}})
            for key, child in value.items():
                visit(child, manifest, pointer + '/' + key.replace('~', '~0').replace('/', '~1'))
        elif isinstance(value, list):
            for index, child in enumerate(value):
                visit(child, manifest, pointer + '/' + str(index))

    for path in manifests:
        visit(json.loads(path.read_text()), path, '')
    OUTPUT.mkdir(exist_ok=False)
    write(OUTPUT / 'allocation.json', {'producer': binding(Path(__file__)), 'manifests': [binding(p) for p in manifests],
          'groups': [{'reading_sha256': digest, **group} for digest, group in sorted(groups.items())],
          'selection': 'Union of every previously projected DOCX in the four frozen manifests. Byte-identical reading inputs share output; every occurrence and prior projection binding remains.',
          'created_utc': datetime.now(timezone.utc).isoformat(), 'model_outputs_observed': 0,
          'semantic_reference_labels': 0, 'references': REFERENCES})
    print(json.dumps({'byte_distinct_reading_inputs': len(groups), 'aliases': sum(len(g['aliases']) for g in groups.values())}))


def process(group):
    inputs = [checked(item) for item in group['reading_inputs']]
    for alias in group['aliases']:
        checked(alias['native']); checked(alias['prior_projection'])
    result = project_docx(inputs[0].read_bytes())
    changes = []
    old_bindings = {a['prior_projection']['path']: a['prior_projection'] for a in group['aliases']}
    for old_binding in old_bindings.values():
        old = json.loads(checked(old_binding).read_text())
        changed = []
        for before, after in zip(old['paragraphs'], result['paragraphs'], strict=True):
            for field in ['paragraph_index', 'style', 'insertions', 'deletions']:
                if before[field] != after[field]:
                    raise ValueError('Unexpected non-text change: ' + field)
            if before['before'] != after['before'] or before['after'] != after['after']:
                changed.append({'paragraph_index': after['paragraph_index'],
                                'before_removed_characters': len(before['before']) - len(after['before']),
                                'after_removed_characters': len(before['after']) - len(after['after'])})
        changes.append({'prior_projection': old_binding, 'changed_paragraphs': changed})
    path = OUTPUT / 'objects' / (group['reading_sha256'] + '.json')
    write(path, result)
    return {**group, 'projection': binding(path), 'paragraphs': len(result['paragraphs']),
            'after_characters': sum(len(p['after']) for p in result['paragraphs']), 'prior_comparisons': changes}


def run():
    allocation = json.loads((OUTPUT / 'allocation.json').read_text())
    checked(allocation['producer'])
    for item in allocation['manifests']:
        checked(item)
    (OUTPUT / 'objects').mkdir(exist_ok=False)
    rows = []
    with (OUTPUT / 'rows.jsonl').open('x') as handle, ProcessPoolExecutor(max_workers=4) as pool:
        for row in pool.map(process, allocation['groups'], chunksize=1):
            handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n'); handle.flush()
            rows.append(row)
    checked(allocation['producer'])
    write(OUTPUT / 'manifest.json', {'allocation': binding(OUTPUT / 'allocation.json'), 'output': binding(OUTPUT / 'rows.jsonl'),
          'producer': binding(Path(__file__)), 'created_utc': datetime.now(timezone.utc).isoformat(),
          'reading_inputs': len(rows), 'paragraphs': sum(r['paragraphs'] for r in rows),
          'after_characters': sum(r['after_characters'] for r in rows),
          'inputs_with_changed_text': sum(any(c['changed_paragraphs'] for c in r['prior_comparisons']) for r in rows),
          'semantic_reference_labels': 0, 'independent_verification': 'pending', 'originals_overwritten': False})
    print(json.dumps({k: v for k, v in json.loads((OUTPUT / 'manifest.json').read_text()).items() if k not in {'output', 'allocation', 'producer'}}))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['allocate', 'run'])
    args = parser.parse_args()
    (allocate if args.action == 'allocate' else run)()
