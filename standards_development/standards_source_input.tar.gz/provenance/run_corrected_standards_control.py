#!/usr/bin/env python3
"""Prepare a content-corrected source control and dispatch it at most once.

Retains the frozen sources, aliases, questions, model and settings. Changes are
the independently replayed projection and source coordinates of development
quotes. The original failed/interrupted preparation remains untouched.
"""
import argparse
import copy
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import shutil


def load_module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


control = load_module('corrected_source_control_runtime', 'run_standards_full_source_control.py')
compact = load_module('corrected_source_control_encoding', 'compact_standards_full_source_control.py')
projection = load_module('corrected_source_projection', 'project_standards_content.py')
ROOT = control.ROOT
ORIGINAL = control.CONTROL / 'execution'
OUTPUT = control.CONTROL / 'content_corrected'
CORRECTION = projection.OUTPUT


def prepare():
    old_plan = json.loads((ORIGINAL / 'plan.json').read_text())
    for item in old_plan.values():
        if isinstance(item, dict) and {'path', 'sha256', 'bytes'} <= item.keys():
            projection.checked(item)
    if any((path / 'run').exists() for path in [control.CONTROL, control.CONTROL / 'compact', ORIGINAL]):
        raise ValueError('An earlier preparation has already attempted inference')
    verification = json.loads((CORRECTION / 'verification.json').read_text())
    if verification['status'] != 'PASS':
        raise ValueError('Independent content replay must pass first')
    projection.checked(verification['producer']); projection.checked(verification['output'])
    manifest = json.loads(projection.checked(verification['projection_manifest']).read_text())
    projection.checked(manifest['producer']); projection.checked(manifest['allocation'])
    corrected_rows = {r['reading_sha256']: r for r in map(json.loads, projection.checked(manifest['output']).open())}
    original = json.loads((ORIGINAL / 'source_units.json').read_text())
    source = copy.deepcopy(original)
    changed = []
    for unit in source['units']:
        reading_hashes = set()
        for occurrence in unit['occurrences']:
            reading = (occurrence.get('conversion') or {}).get('derived') or occurrence['native']
            projection.checked(reading); projection.checked(occurrence['native']); projection.checked(occurrence['projection'])
            row = corrected_rows[reading['sha256']]
            if not any(alias['prior_projection'] == occurrence['projection'] and alias['native'] == occurrence['native'] for alias in row['aliases']):
                raise ValueError('Corrected projection lacks original occurrence binding')
            reading_hashes.add(reading['sha256'])
            occurrence['prior_projection'] = occurrence['projection']
            occurrence['projection'] = row['projection']
        if len(reading_hashes) != 1:
            raise ValueError('Byte-identical source group has different reading inputs')
        corrected = json.loads(projection.checked(row['projection']).read_text())
        for before, after in zip(unit['paragraphs'], corrected['paragraphs'], strict=True):
            for key in ['paragraph_index', 'style', 'insertions', 'deletions']:
                if before[key] != after[key]:
                    raise ValueError('Paragraph coordinate/metadata changed')
            if before != after:
                changed.append({'source_id': unit['id'], 'paragraph_index': before['paragraph_index'],
                                'before_removed_characters': len(before['before']) - len(after['before']),
                                'after_removed_characters': len(before['after']) - len(after['after'])})
        unit['paragraphs'] = corrected['paragraphs']; unit['projection_scope'] = corrected['projection_scope']
    if source['metadata'] != original['metadata']:
        raise ValueError('Official metadata changed')
    source['input_correction'] = {'prior_source_units': projection.binding(ORIGINAL / 'source_units.json'),
                                  'independent_verification': projection.binding(CORRECTION / 'verification.json')}
    packet = compact.packet(source)
    decoded, metadata = compact.decode(packet)
    for before, after in zip(source['units'], decoded, strict=True):
        expected_aliases = [{'record': r.get('id', r.get('record')), 'member_chain': r.get('archive_member_chain', r.get('member_chain')),
                            'cr_identity': r.get('cr_identity'), 'conversion': r.get('conversion') is not None} for r in before['occurrences']]
        if after != {'id': before['id'], 'aliases': expected_aliases, 'paragraphs': before['paragraphs'], 'projection_scope': before['projection_scope']}:
            raise ValueError('Lossy source serialization')
    if metadata != source['metadata']:
        raise ValueError('Lossy metadata serialization')
    reference = json.loads((ORIGINAL / 'development_reference.json').read_text())
    original_units = {u['id']: u for u in original['units']}
    new_units = {u['id']: u for u in source['units']}
    reference_changes, verified_quotes = [], 0
    for question_id, claims in reference['requested_claims'].items():
        for claim_index, claim in enumerate(claims):
            for evidence_index, evidence in enumerate(claim['evidence']):
                if evidence['source_id'] not in new_units:
                    continue  # Official metadata rows are unchanged.
                old_text = original_units[evidence['source_id']]['paragraphs'][evidence['paragraph_index']][evidence['view']]
                new_text = new_units[evidence['source_id']]['paragraphs'][evidence['paragraph_index']][evidence['view']]
                start, end = evidence['span']
                if old_text[start:end] != evidence['quote']:
                    raise ValueError('Original reference quote does not match bound coordinates')
                old_evidence = copy.deepcopy(evidence)
                if evidence['quote'] == old_text:
                    evidence['quote'] = new_text; evidence['span'] = [0, len(new_text)]
                elif new_text[start:end] != evidence['quote']:
                    if new_text.count(evidence['quote']) != 1:
                        raise ValueError('Partial reference requires explicit XML coordinate inspection')
                    new_start = new_text.index(evidence['quote'])
                    evidence['span'] = [new_start, new_start + len(evidence['quote'])]
                start, end = evidence['span']
                if new_text[start:end] != evidence['quote']:
                    raise ValueError('Corrected reference quote mismatch')
                verified_quotes += 1
                if old_evidence != evidence:
                    reference_changes.append({'question': question_id, 'claim_index': claim_index, 'evidence_index': evidence_index,
                                              'prior': old_evidence, 'corrected': copy.deepcopy(evidence)})
    OUTPUT.mkdir(exist_ok=False)
    projection.write(OUTPUT / 'source_units.json', source)
    (OUTPUT / 'source_packet.txt').write_text(packet)
    for filename in ['questions.json', 'model_spec.json']:
        shutil.copyfile(ORIGINAL / filename, OUTPUT / filename)
    reference['source_units_sha256'] = projection.sha(OUTPUT / 'source_units.json')
    reference['projection_coordinate_correction'] = {'prior_reference': projection.binding(ORIGINAL / 'development_reference.json'),
                                                     'meaning_of_claims_changed': False, 'model_responses_observed': 0}
    projection.write(OUTPUT / 'development_reference.json', reference)
    questions = json.loads((OUTPUT / 'questions.json').read_text())['questions']
    prompts = [{'id': q['id'], 'messages': [{'role': 'system', 'content': control.SYSTEM},
                {'role': 'user', 'content': 'OFFICIAL-SOURCE PACKET:\n' + packet + '\n\nQUESTION:\n' + q['question']}]} for q in questions]
    projection.write(OUTPUT / 'prompts.json', {'prompts': prompts})
    from jinja2 import Environment
    from transformers import AutoTokenizer
    tokenizer_path = control.CONTROL / 'tokenizer'
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)
    template = Environment().from_string((tokenizer_path / 'chat_template.jinja').read_text())
    counts = [{'id': p['id'], 'tokens': len(tokenizer.encode(template.render(messages=p['messages'], add_generation_prompt=True, tools=None), add_special_tokens=False))} for p in prompts]
    needed = max(c['tokens'] for c in counts) + old_plan['settings']['n_predict']
    context_size = ((needed + 4095) // 4096) * 4096
    config = json.loads((tokenizer_path / 'config.json').read_text())
    if context_size > config['max_position_embeddings']:
        raise ValueError('Corrected complete input exceeds native model capacity')
    model = json.loads((OUTPUT / 'model_spec.json').read_text())['model']
    kv_bytes = context_size * config['num_hidden_layers'] * config['num_key_value_heads'] * config['head_dim'] * 4
    available = next(int(line.split()[1]) * 1024 for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:'))
    if kv_bytes + model['bytes'] > available:
        raise ValueError('Estimated weights and FP16 KV exceed available memory')
    plan = copy.deepcopy(old_plan)
    for key in ['source_packet', 'source_units', 'questions', 'prompts', 'model_spec', 'reference']:
        filename = 'development_reference.json' if key == 'reference' else key + ('.txt' if key == 'source_packet' else '.json')
        plan[key] = projection.binding(OUTPUT / filename)
    plan.update({'created_utc': datetime.now(timezone.utc).isoformat(), 'context_size': context_size,
                 'content_correction_preparer': projection.binding(Path(__file__)),
                 'content_projector': projection.binding(Path(projection.__file__)),
                 'projection_utility': projection.binding(Path(projection.__file__)),
                 'encoding_utility': projection.binding(Path(compact.__file__)),
                 'content_verification': projection.binding(CORRECTION / 'verification.json'),
                 'prior_interrupted_plan': projection.binding(ORIGINAL / 'plan.json'),
                 'prior_interruption': projection.binding(ORIGINAL / 'projection_defect_interruption.json'),
                 'capacity_selection': 'Smallest multiple of 4096 covering independently corrected complete inputs plus unchanged answer cap. Within pinned model native limit; no model response used.',
                 'representation_change': 'Formatting properties no longer produce content. All original native sources, aliases, paragraph numbers, styles, revision counts and collected metadata remain. Development claim meanings, questions, system, model and sampling settings remain.',
                 'memory_preflight': {'available_bytes': available, 'estimated_fp16_kv_bytes': kv_bytes, 'distribution_weight_bytes': model['bytes'],
                                      'scope': 'Weights/KV estimate only; actual runtime allocations and compute buffers must be observed.'}})
    projection.write(OUTPUT / 'plan.json', plan)
    projection.write(OUTPUT / 'input_capacity.json', {'counts': counts, 'context_size': context_size,
                     'output_cap': old_plan['settings']['n_predict'], 'fits_all': all(c['tokens'] + old_plan['settings']['n_predict'] <= context_size for c in counts),
                     'prompts': projection.binding(OUTPUT / 'prompts.json'), 'tokenizer_acquisition': projection.binding(tokenizer_path / 'acquisition.json'),
                     'scope': 'Pinned official tokenizer and Jinja template. Actual GGUF template/token preflight also required before completion requests.'})
    projection.write(OUTPUT / 'correction_verification.json', {'original_plan': projection.binding(ORIGINAL / 'plan.json'),
                     'source_units': projection.binding(OUTPUT / 'source_units.json'), 'source_packet': projection.binding(OUTPUT / 'source_packet.txt'),
                     'units': len(source['units']), 'native_occurrences': sum(len(u['occurrences']) for u in source['units']),
                     'paragraphs': sum(len(u['paragraphs']) for u in source['units']), 'metadata_rows': len(metadata),
                     'changed_paragraphs': changed, 'paragraph_reference_quotes_verified': verified_quotes, 'reference_changes': reference_changes,
                     'questions_unchanged': projection.sha(OUTPUT / 'questions.json') == projection.sha(ORIGINAL / 'questions.json'),
                     'model_spec_unchanged': projection.sha(OUTPUT / 'model_spec.json') == projection.sha(ORIGINAL / 'model_spec.json'),
                     'system_and_settings_unchanged': True, 'model_responses_observed': 0})
    print(json.dumps({'units': len(source['units']), 'native_occurrences': sum(len(u['occurrences']) for u in source['units']),
                      'paragraphs': sum(len(u['paragraphs']) for u in source['units']), 'metadata_rows': len(metadata),
                      'changed_paragraphs': len(changed), 'reference_changes': len(reference_changes), 'counts': counts, 'context_size': context_size}))


def run(port):
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    for key in ['content_correction_preparer', 'content_projector', 'encoding_utility', 'content_verification',
                'reference', 'prior_interrupted_plan', 'prior_interruption']:
        projection.checked(plan[key])
    capacity = json.loads((OUTPUT / 'input_capacity.json').read_text())
    projection.checked(capacity['prompts']); projection.checked(capacity['tokenizer_acquisition'])
    if not capacity['fits_all'] or capacity['context_size'] != plan['context_size'] or plan['settings'] != control.SETTINGS:
        raise ValueError('Missing capacity or unchanged setting check')
    control.CONTROL = OUTPUT
    control.run(port)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'run'])
    parser.add_argument('--port', type=int, default=18092)
    args = parser.parse_args()
    (prepare if args.action == 'prepare' else lambda: run(args.port))()
