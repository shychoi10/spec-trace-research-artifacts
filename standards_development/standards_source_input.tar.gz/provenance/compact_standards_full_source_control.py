#!/usr/bin/env python3
"""Losslessly compact a failed complete-source input before model responses.

Repeated serialization defaults are omitted; native paragraphs and metadata
are unchanged. This is a capacity repair, not a research comparison condition.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import shutil

PRODUCER = Path(__file__).with_name('run_standards_full_source_control.py')
spec = importlib.util.spec_from_file_location('complete_source_control', PRODUCER)
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
ORIGINAL = control.CONTROL
OUTPUT = ORIGINAL / 'compact'


def dumps(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'))


def packet(source):
    lines = ['ENCODING: Each P line is P<number> <JSON array>. Array fields are [style, insertions, deletions, AFTER, optional BEFORE]. If BEFORE is absent it equals AFTER. Style null and counts 0 are defaults when the first three fields are omitted: [AFTER, optional BEFORE]. All paragraph numbers, including blank paragraphs, are supplied. Paragraph citations retain [Snn:pN].']
    for unit in source['units']:
        aliases = [{'record': r.get('id', r.get('record')), 'member_chain': r.get('archive_member_chain', r.get('member_chain')),
                    'cr_identity': r.get('cr_identity'), 'conversion': r.get('conversion') is not None} for r in unit['occurrences']]
        lines += ['SOURCE ' + unit['id'] + ' ' + dumps(aliases), 'SCOPE ' + dumps(unit['projection_scope'])]
        for paragraph in unit['paragraphs']:
            values = [paragraph['after']]
            if paragraph['before'] != paragraph['after']:
                values.append(paragraph['before'])
            if paragraph['style'] is not None or paragraph['insertions'] or paragraph['deletions']:
                values = [paragraph['style'], paragraph['insertions'], paragraph['deletions'], *values]
            lines.append('P' + str(paragraph['paragraph_index']) + ' ' + dumps(values))
    for row in source['metadata']:
        lines.append('METADATA ' + row['id'] + ' ' + dumps(row))
    return '\n'.join(lines)


def decode(text):
    units, metadata = [], []
    for line in text.splitlines():
        if line.startswith('SOURCE '):
            _, identifier, aliases = line.split(' ', 2)
            units.append({'id': identifier, 'aliases': json.loads(aliases), 'paragraphs': []})
        elif line.startswith('SCOPE '):
            units[-1]['projection_scope'] = json.loads(line[6:])
        elif line.startswith('P') and line[1:2].isdigit():
            label, payload = line.split(' ', 1)
            values = json.loads(payload)
            if len(values) >= 4:
                style, insertions, deletions, *texts = values
            else:
                style, insertions, deletions = None, 0, 0
                texts = values
            if len(texts) not in (1, 2):
                raise ValueError('Unexpected paragraph fields')
            units[-1]['paragraphs'].append({'paragraph_index': int(label[1:]), 'before': texts[1] if len(texts) == 2 else texts[0],
                'after': texts[0], 'style': style, 'insertions': insertions, 'deletions': deletions})
        elif line.startswith('METADATA '):
            _, identifier, payload = line.split(' ', 2)
            row = json.loads(payload)
            if row['id'] != identifier:
                raise ValueError('Metadata identity mismatch')
            metadata.append(row)
    return units, metadata


def prepare():
    old_plan = json.loads((ORIGINAL / 'plan.json').read_text())
    for key in ['producer', 'projection_utility', 'source_packet', 'source_units', 'questions', 'prompts', 'model_spec', 'runtime']:
        control.checked(old_plan[key])
    if (ORIGINAL / 'run').exists():
        raise ValueError('The original condition has already attempted model execution')
    capacity = json.loads((ORIGINAL / 'tokenizer/input_capacity.json').read_text())
    if capacity['fits_all']:
        raise ValueError('The original input did not fail capacity')
    OUTPUT.mkdir(exist_ok=False)
    source = json.loads((ORIGINAL / 'source_units.json').read_text())
    text = packet(source)
    units, metadata = decode(text)
    for before, after in zip(source['units'], units, strict=True):
        if before['id'] != after['id'] or before['paragraphs'] != after['paragraphs'] or before['projection_scope'] != after['projection_scope']:
            raise ValueError('Lossy paragraph serialization')
    if metadata != source['metadata']:
        raise ValueError('Lossy metadata serialization')
    (OUTPUT / 'source_packet.txt').write_text(text)
    for name in ['source_units.json', 'questions.json', 'model_spec.json', 'development_reference.json']:
        shutil.copyfile(ORIGINAL / name, OUTPUT / name)
    questions = json.loads((OUTPUT / 'questions.json').read_text())['questions']
    prompts = [{'id': q['id'], 'messages': [{'role': 'system', 'content': control.SYSTEM},
        {'role': 'user', 'content': 'OFFICIAL-SOURCE PACKET:\n' + text + '\n\nQUESTION:\n' + q['question']}]} for q in questions]
    control.write(OUTPUT / 'prompts.json', {'prompts': prompts})
    plan = dict(old_plan)
    for name in ['source_packet', 'source_units', 'questions', 'prompts', 'model_spec']:
        plan[name] = control.utility.binding(OUTPUT / (name + ('.txt' if name == 'source_packet' else '.json')))
    plan.update({'created_utc': datetime.now(timezone.utc).isoformat(), 'capacity_repair_producer': control.utility.binding(Path(__file__)),
        'original_failed_preparation': control.utility.binding(ORIGINAL / 'plan.json'),
        'original_failed_capacity': control.utility.binding(ORIGINAL / 'tokenizer/input_capacity.json'),
        'representation_change': 'Repeated defaults omitted with explicit encoding; all native paragraph fields, blank paragraphs and metadata are exactly reconstructable. No source, question, reference, model or sampling settings changed.',
        'reference': control.utility.binding(OUTPUT / 'development_reference.json')})
    control.write(OUTPUT / 'plan.json', plan)
    control.write(OUTPUT / 'representation_verification.json', {'source': control.utility.binding(ORIGINAL / 'source_units.json'),
        'packet': control.utility.binding(OUTPUT / 'source_packet.txt'), 'verification': 'All decoded paragraph fields and metadata equal the frozen source units; native layout/media beyond those projections were not supplied in either representation.',
        'paragraphs': sum(len(u['paragraphs']) for u in units), 'units': len(units), 'metadata_rows': len(metadata),
        'model_responses_observed': 0, 'method_improvement_claim': False})
    print(dumps({'packet_characters': len(text), 'paragraphs': sum(len(u['paragraphs']) for u in units), 'responses': 0}))


def capacity():
    from jinja2 import Environment
    from transformers import AutoTokenizer
    tokenizer_path = ORIGINAL / 'tokenizer'
    tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, local_files_only=True)
    template = Environment().from_string((tokenizer_path / 'chat_template.jinja').read_text())
    prompts = json.loads((OUTPUT / 'prompts.json').read_text())['prompts']
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    counts = []
    for row in prompts:
        rendered = template.render(messages=row['messages'], add_generation_prompt=True, tools=None)
        counts.append({'id': row['id'], 'tokens': len(tokenizer.encode(rendered, add_special_tokens=False))})
    result = {'counts': counts, 'context_size': plan['context_size'], 'output_cap': plan['settings']['n_predict'],
        'fits_all': all(row['tokens'] + plan['settings']['n_predict'] <= plan['context_size'] for row in counts),
        'renderer': 'Pinned official tokenizer and Jinja template rendered directly; local GGUF template must also be checked before dispatch.',
        'prompts': control.utility.binding(OUTPUT / 'prompts.json'), 'acquisition': control.utility.binding(tokenizer_path / 'acquisition.json')}
    control.write(OUTPUT / 'input_capacity.json', result)
    print(dumps(result))
    if not result['fits_all']:
        raise ValueError('Complete input still exceeds fixed capacity')


def run(port):
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    for key in ['capacity_repair_producer', 'reference', 'original_failed_preparation', 'original_failed_capacity']:
        control.checked(plan[key])
    if not json.loads((OUTPUT / 'input_capacity.json').read_text())['fits_all']:
        raise ValueError('Missing successful capacity check')
    control.CONTROL = OUTPUT
    control.run(port)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'capacity', 'run'])
    parser.add_argument('--port', type=int, default=18092)
    args = parser.parse_args()
    {'prepare': prepare, 'capacity': capacity, 'run': lambda: run(args.port)}[args.action]()
