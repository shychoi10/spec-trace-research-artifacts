#!/usr/bin/env python3
"""Make the corrected, frozen whole-source control executable after relocation.

Retains prior preparations. Repairs only the migrated shared-library lookup
and the API representation of the intended complete-context penalty window.
No source, question, reference claim, model or sampling search is changed.
"""
import argparse
import copy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import check_standards_runtime_compatibility as neutral
import run_corrected_standards_control as corrected
import run_standards_full_source_control as control

ROOT, PARENT = control.ROOT, corrected.OUTPUT
ACTIVE = PARENT / 'runtime_compatible'
LIBRARIES = control.HISTORICAL / 'runtime_build/bin'


def runtime_environment():
    build_path = control.HISTORICAL / 'runtime_verification.json'
    build = json.loads(build_path.read_text())
    files = []
    for item in build['files']:
        path = control.HISTORICAL / item['path']
        bound = control.utility.binding(path)
        if bound['sha256'] != item['sha256'] or bound['bytes'] != item['bytes']:
            raise ValueError('Runtime library differs from the pinned build')
        files.append(bound)
    return {'LD_LIBRARY_PATH': str(LIBRARIES)}, files


def check_neutral():
    environment, files = runtime_environment()
    os.environ.update(environment)
    executable = control.checked(json.loads((PARENT / 'plan.json').read_text())['runtime'])
    readelf = subprocess.run(['readelf', '-d', str(executable)], capture_output=True, text=True, check=True)
    loader = subprocess.run(['ldd', str(executable)], capture_output=True, text=True, check=True)
    if 'not found' in loader.stdout:
        raise ValueError('Pinned shared libraries still fail to resolve')
    control.write(PARENT / 'runtime_loader_invocation.json', {
        'created_utc': datetime.now(timezone.utc).isoformat(), 'producer': control.utility.binding(Path(__file__)),
        'neutral_checker': control.utility.binding(Path(neutral.__file__)), 'environment_overrides': environment,
        'runtime_files': files, 'readelf_stdout': readelf.stdout, 'ldd_stdout': loader.stdout,
        'prior_startup_failure': control.utility.binding(PARENT / 'runtime_compatibility/failure.json'),
        'target_requests': 0})
    neutral.OUT = PARENT / 'runtime_loaded_compatibility'
    neutral.main()


def prepare():
    proof = PARENT / 'runtime_loaded_compatibility/verification.json'
    if json.loads(proof.read_text())['status'] != 'PASS':
        raise ValueError('Neutral API compatibility did not pass')
    prior_path = PARENT / 'plan.json'
    prior = json.loads(prior_path.read_text())
    if (PARENT / 'run').exists() or prior['settings']['repeat_last_n'] != -1:
        raise ValueError('Expected unexecuted frozen incompatible preparation')
    stopped = json.loads((PARENT / 'continuation_status.json').read_text())
    if stopped['status'] != 'STOPPED_BEFORE_TARGET_DISPATCH_RUNTIME_SETTING_INCOMPATIBLE':
        raise ValueError('Prior automatic execution was not stopped')
    environment, files = runtime_environment()
    plan = copy.deepcopy(prior)
    plan['settings']['repeat_last_n'] = prior['context_size']
    ACTIVE.mkdir(exist_ok=False)
    (ACTIVE / 'development_reference.json').write_bytes(control.checked(prior['reference']).read_bytes())
    plan.update({
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'runtime_compatibility_preparer': control.utility.binding(Path(__file__)),
        'prior_corrected_plan': control.utility.binding(prior_path),
        'prior_compatibility_interruption': control.utility.binding(PARENT / 'runtime_compatibility_interruption.json'),
        'runtime_compatibility_proof': control.utility.binding(proof),
        'runtime_loader_invocation': control.utility.binding(PARENT / 'runtime_loader_invocation.json'),
        'runtime_environment_overrides': environment, 'runtime_files': files,
        'reference': control.utility.binding(ACTIVE / 'development_reference.json'),
        'representation_change': prior['representation_change'] + ' Subsequently, the unsupported HTTP repeat_last_n=-1 is represented as the full context size; migrated pinned libraries are resolved with an explicit local directory.',
        'compatibility_change': {'only_setting_field': 'repeat_last_n', 'before': -1, 'after': prior['context_size'],
            'intent': 'Entire available context; explicit nonnegative value accepted by the same pinned HTTP server on neutral input.',
            'model_outputs_observed': 0, 'source_packet_changed': False, 'questions_changed': False,
            'model_changed': False, 'reference_claims_changed': False},
    })
    for field in ['source_units', 'source_packet', 'questions', 'prompts', 'model_spec']:
        if plan[field] != prior[field]:
            raise ValueError('Compatibility repair changed a research input')
    before = {k: v for k, v in prior['settings'].items() if k != 'repeat_last_n'}
    after = {k: v for k, v in plan['settings'].items() if k != 'repeat_last_n'}
    if before != after:
        raise ValueError('Compatibility repair changed sampling settings')
    control.write(ACTIVE / 'plan.json', plan)
    print(json.dumps({'status': 'PREPARED', 'repeat_last_n': plan['settings']['repeat_last_n'], 'model_outputs': 0}), flush=True)


def check_plan():
    plan = json.loads((ACTIVE / 'plan.json').read_text())
    for key in ['runtime_compatibility_preparer', 'prior_corrected_plan', 'prior_compatibility_interruption',
                'runtime_compatibility_proof', 'runtime_loader_invocation', 'reference',
                'content_correction_preparer', 'content_projector', 'encoding_utility', 'content_verification']:
        control.checked(plan[key])
    for item in plan['runtime_files']:
        control.checked(item)
    prior = json.loads(control.checked(plan['prior_corrected_plan']).read_text())
    expected = dict(prior['settings'], repeat_last_n=prior['context_size'])
    if plan['settings'] != expected or plan['context_size'] != prior['context_size']:
        raise ValueError('Effective settings differ from the frozen compatibility repair')
    for key in ['source_units', 'source_packet', 'questions', 'prompts', 'model_spec']:
        if plan[key] != prior[key]:
            raise ValueError('Frozen source input differs')
    capacity = json.loads((PARENT / 'input_capacity.json').read_text())
    control.checked(capacity['prompts']); control.checked(capacity['tokenizer_acquisition'])
    if not capacity['fits_all'] or capacity['context_size'] != plan['context_size']:
        raise ValueError('Complete input capacity did not pass')
    environment, files = runtime_environment()
    if environment != plan['runtime_environment_overrides'] or files != plan['runtime_files']:
        raise ValueError('Runtime environment changed')
    return plan


def run(port):
    plan = check_plan()
    if (ACTIVE / 'run').exists():
        raise ValueError('The fixed control has already been attempted')
    os.environ.update(plan['runtime_environment_overrides'])
    control.write(ACTIVE / 'effective_environment.json', {
        'plan': control.utility.binding(ACTIVE / 'plan.json'),
        'environment_overrides': plan['runtime_environment_overrides'], 'runtime_files': plan['runtime_files']})
    control.CONTROL = ACTIVE
    control.SETTINGS = plan['settings']
    control.run(port)


def process_identity(pid):
    try:
        directory = Path('/proc') / str(pid)
        fields = (directory / 'stat').read_text().split(') ', 1)[1].split()
        return {'command': (directory / 'cmdline').read_bytes().replace(b'\0', b' ').decode(),
                'start_ticks': fields[19], 'state': fields[0]}
    except FileNotFoundError:
        return None


def state(value):
    value.update(updated_utc=datetime.now(timezone.utc).isoformat(), supervisor_pid=os.getpid())
    temporary = ACTIVE / 'continuation_status.json.partial'
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(ACTIVE / 'continuation_status.json')
    print(json.dumps(value), flush=True)


def continue_download(pid):
    check_plan()
    if (ACTIVE / 'run').exists():
        raise ValueError('The fixed control has already been attempted')
    identity = process_identity(pid)
    acquisition_path = control.BASE / 'model/model_acquisition.json'
    if not acquisition_path.is_file() and (identity is None or 'download_issue_lineage_model.py' not in identity['command']):
        raise ValueError('The existing model acquisition is not alive')
    bindings = [control.utility.binding(p) for p in [Path(__file__), ACTIVE / 'plan.json',
                PARENT / 'plan.json', PARENT / 'input_capacity.json', ACTIVE / 'development_reference.json']]
    control.write(ACTIVE / 'continuation_launch.json', {'download_pid': pid, 'process_identity': identity,
        'bindings': bindings, 'automatic_retry': False, 'prior_supervisors_remain_stopped': True})
    state({'status': 'WAITING_FOR_EXISTING_DOWNLOAD', 'download_pid': pid, 'model_responses': 0})
    while not acquisition_path.is_file():
        current = process_identity(pid)
        if current is None or current['start_ticks'] != identity['start_ticks'] or current['state'] == 'Z':
            state({'status': 'DOWNLOAD_TERMINATED_WITHOUT_VERIFIED_MANIFEST', 'model_responses': 0})
            return
        time.sleep(15)
    for item in bindings:
        control.checked(item)
    model = json.loads(control.checked(check_plan()['model_spec']).read_text())['model']
    acquisition = json.loads(acquisition_path.read_text())
    if (acquisition['sha256'], acquisition['bytes']) != (model['sha256'], model['bytes']):
        raise ValueError('Existing acquisition differs from the pinned model')
    state({'status': 'RUNNING_COMPATIBLE_CORRECTED_CONTROL', 'model_responses': 0})
    with (ACTIVE / 'execution.log').open('x') as log:
        result = subprocess.run(['nice', '-n', '15', sys.executable, str(Path(__file__)), 'run'], stdout=log, stderr=subprocess.STDOUT)
    completion, failure = ACTIVE / 'run/completion.json', ACTIVE / 'run/failure.json'
    state({'status': 'CONTROL_RESPONSES_SAVED' if result.returncode == 0 and completion.is_file() else 'CONTROL_EXECUTION_FAILED',
           'returncode': result.returncode, 'completion': control.utility.binding(completion) if completion.is_file() else None,
           'failure': control.utility.binding(failure) if failure.is_file() else None, 'semantic_evaluation': 'not_yet_evaluated'})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['neutral', 'prepare', 'run', 'continue'])
    parser.add_argument('--port', type=int, default=18092)
    parser.add_argument('--download-pid', type=int)
    args = parser.parse_args()
    if args.action == 'continue':
        if args.download_pid is None:
            parser.error('--download-pid is required for continuation')
        continue_download(args.download_pid)
    elif args.action == 'run':
        run(args.port)
    else:
        {'neutral': check_neutral, 'prepare': prepare}[args.action]()
