#!/usr/bin/env python3
"""Verify a standalone development-input bundle, without network or inference.

Raw XML replay follows the bounded content-token projection recorded by
project_standards_content.py. It does not implement full Word rendering or
establish the semantic correctness of the assistant's development references.
"""
import argparse
import csv
from datetime import datetime, timedelta
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET
import zipfile

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
X = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def projection(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        root = ET.fromstring(package.read('word/document.xml'))

    def tokens(node, view, ancestors=()):
        tag = node.tag
        namespace, _, local = tag.rpartition('}')
        if namespace + '}' in {W, M, A} and (local.endswith('Pr') or local.endswith('PrChange')):
            return ''
        if (view == 'before' and tag in {W + 'ins', W + 'moveTo'}) or (view == 'after' and tag in {W + 'del', W + 'moveFrom'}):
            return ''
        if tag in {W + 't', W + 'delText', M + 't', A + 't'}:
            return node.text or ''
        if tag == W + 'tab':
            return '\t'
        if tag in {W + 'br', W + 'cr'}:
            return '\n'
        require(local not in {'t', 'delText', 'tab', 'br', 'cr'}, 'Unresolved token namespace')
        return ''.join(tokens(child, view, (*ancestors, tag)) for child in node)

    paragraphs = []
    for index, paragraph in enumerate(root.iter(W + 'p')):
        style = paragraph.find(W + 'pPr/' + W + 'pStyle')
        paragraphs.append({'paragraph_index': index, 'style': style.get(W + 'val') if style is not None else None,
            'insertions': len(list(paragraph.iter(W + 'ins'))), 'deletions': len(list(paragraph.iter(W + 'del'))),
            'before': tokens(paragraph, 'before'), 'after': tokens(paragraph, 'after')})
    return paragraphs


def unpack(raw, chain):
    for member in chain:
        with zipfile.ZipFile(io.BytesIO(raw)) as package:
            raw = package.read(member)
    return raw


def column_number(label):
    number = 0
    for character in re.match(r'^[A-Z]+', label).group():
        number = number * 26 + ord(character) - ord('A') + 1
    return number - 1


def worksheet(raw, name):
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        workbook = ET.fromstring(package.read('xl/workbook.xml'))
        relation = next(s.get(R + 'id') for s in workbook.find(X + 'sheets') if s.get('name') == name)
        relations = ET.fromstring(package.read('xl/_rels/workbook.xml.rels'))
        target = next(r.get('Target') for r in relations if r.get('Id') == relation)
        target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        require('..' not in PurePosixPath(target).parts, 'Unexpected worksheet relationship')
        strings = []
        if 'xl/sharedStrings.xml' in package.namelist():
            strings = [''.join(t.text or '' for t in node.iter(X + 't')) for node in ET.fromstring(package.read('xl/sharedStrings.xml'))]
        styles = ET.fromstring(package.read('xl/styles.xml'))
        formats = {int(node.get('numFmtId')): node.get('formatCode') for node in styles.find(X + 'numFmts') or []}
        style_ids = [int(node.get('numFmtId', 0)) for node in styles.find(X + 'cellXfs')]
        properties = workbook.find(X + 'workbookPr')
        epoch = datetime(1904, 1, 1) if properties is not None and properties.get('date1904') in {'1', 'true'} else datetime(1899, 12, 30)
        result = {}
        for row in ET.fromstring(package.read(target)).find(X + 'sheetData'):
            cells = {}
            for cell in row:
                typ, node = cell.get('t', 'n'), cell.find(X + 'v')
                text = node.text if node is not None else None
                datatype = typ
                if typ == 's':
                    value = strings[int(text)]
                elif typ == 'inlineStr':
                    value = ''.join(t.text or '' for t in cell.iter(X + 't')); datatype = 's'
                elif typ == 'd':
                    value = str(datetime.fromisoformat(text.replace('Z', '+00:00')))
                elif typ == 'n' and text is not None:
                    value = float(text) if any(c in text for c in '.eE') else int(text)
                    fmt = style_ids[int(cell.get('s', '0'))]
                    code = re.sub(r'"[^"]*"|\[[^]]*\]', '', formats.get(fmt, ''))
                    if fmt in set(range(14, 23)) | {45, 46, 47} or re.search(r'[dmyhs]', code, re.I):
                        day = int(value); milliseconds = round((value - day) * 86400000)
                        value = str(epoch + timedelta(days=day, milliseconds=milliseconds)); datatype = 'd'
                elif typ == 'b':
                    value = text == '1'
                else:
                    value = text
                cells[column_number(cell.get('r'))] = (value, datatype)
            result[int(row.get('r'))] = cells
        return result


def verify(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    require(manifest['kind'] == 'standards_whole_source_development_input_replay', 'Wrong package kind')
    actual = {str(path.relative_to(folder)) for path in folder.rglob('*') if path.is_file()}
    require(actual == set(manifest['files']) | {'manifest.json'}, 'Package file set differs')
    for name, bound in manifest['files'].items():
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts, 'Unsafe package path')
        require(not (folder / name).is_symlink(), 'Package contains a symlink')
        require(digest((folder / name).read_bytes()) == bound, 'Changed file: ' + name)

    def read_bound(bound):
        name = manifest['source_path_objects'][bound['path']]
        raw = (folder / name).read_bytes()
        measured = digest(raw)
        require(measured['sha256'] == bound['sha256'], 'Changed source binding')
        if 'bytes' in bound:
            require(measured['bytes'] == bound['bytes'], 'Changed source size')
        return raw

    source = json.loads((folder / 'source_units.json').read_text())
    units = {unit['id']: unit for unit in source['units']}
    metadata = {row['id']: row for row in source['metadata']}
    archive_checks = 0
    for unit in source['units']:
        natives = [read_bound(occurrence['native']) for occurrence in unit['occurrences']]
        require(all(raw == natives[0] for raw in natives), 'Alias bytes differ')
        occurrence = unit['occurrences'][0]
        reading = read_bound(occurrence['conversion']['derived']) if occurrence.get('conversion') else natives[0]
        require(projection(reading) == unit['paragraphs'], 'Native paragraph replay differs: ' + unit['id'])
        for occurrence, native in zip(unit['occurrences'], natives):
            require(json.loads(read_bound(occurrence['projection']))['paragraphs'] == unit['paragraphs'], 'Stored projection differs')
            if 'original' in occurrence:
                require(read_bound(occurrence['original']) == native, 'Original/native differ')
            relations = []
            for prefix in ['wg', 'tsg']:
                if prefix + '_archive' in occurrence:
                    relations.append((occurrence[prefix + '_archive'], [occurrence[prefix + '_member']]))
            if 'archive' in occurrence:
                relations.append((occurrence['archive'], occurrence['member_chain']))
            if 'parent_reference' in occurrence:
                relations.append((occurrence['parent_reference']['source_archive'], occurrence['archive_member_chain']))
            for bound, chain in relations:
                require(unpack(read_bound(bound), chain) == native, 'Archive member differs')
                archive_checks += 1
    sheets = {}
    for row in source['metadata']:
        if 'source' in row:
            key = (row['source']['sha256'], row['sheet'])
            if key not in sheets:
                sheets[key] = worksheet(read_bound(row['source']), row['sheet'])
            cells = sheets[key]
            headers = [cells[1][i][0] for i in range(len(row['fields']))]
            require(set(headers) == set(row['fields']), 'Spreadsheet column names differ')
            observed = {header: cells[row['row_1based']].get(i, (None, 'n'))[0] for i, header in enumerate(headers)}
            require(observed == row['fields'], 'Spreadsheet literal row differs: ' + row['id'])
        else:
            bound = {'path': row['source_path'], 'sha256': row['source_sha256']}
            records = csv.DictReader(io.StringIO(read_bound(bound).decode()))
            for number, fields in enumerate(records, 2):
                if number == row['csv_record_number']:
                    require(fields == row['recorded_fields'], 'CSV literal row differs'); break
            else:
                raise ValueError('CSV record missing')
    packet_units, packet_metadata = [], []
    for line in (folder / 'source_packet.txt').read_text().splitlines():
        if line.startswith('SOURCE '):
            _, identifier, aliases = line.split(' ', 2)
            packet_units.append({'id': identifier, 'aliases': json.loads(aliases), 'paragraphs': []})
        elif line.startswith('SCOPE '):
            packet_units[-1]['projection_scope'] = json.loads(line[6:])
        elif line.startswith('P') and line[1:2].isdigit():
            identifier, payload = line.split(' ', 1); values = json.loads(payload)
            style, insertions, deletions = (values[:3] if len(values) >= 4 else [None, 0, 0])
            texts = values[3:] if len(values) >= 4 else values
            require(len(texts) in {1, 2}, 'Unexpected packet paragraph')
            packet_units[-1]['paragraphs'].append({'paragraph_index': int(identifier[1:]), 'style': style,
                'insertions': insertions, 'deletions': deletions, 'after': texts[0], 'before': texts[-1]})
        elif line.startswith('METADATA '):
            _, identifier, payload = line.split(' ', 2); row = json.loads(payload)
            require(row['id'] == identifier, 'Metadata packet identity differs'); packet_metadata.append(row)
    require(len(packet_units) == len(source['units']), 'Packet source count differs')
    for expected, actual in zip(source['units'], packet_units):
        require(all(expected[key] == actual[key] for key in ['id', 'paragraphs', 'projection_scope']), 'Packet data differs')
        aliases = [{'record': occurrence.get('id', occurrence.get('record')),
            'member_chain': occurrence.get('archive_member_chain', occurrence.get('member_chain')),
            'cr_identity': occurrence.get('cr_identity'), 'conversion': occurrence.get('conversion') is not None} for occurrence in expected['occurrences']]
        require(aliases == actual['aliases'], 'Packet aliases differ')
    require(packet_metadata == source['metadata'], 'Packet metadata differs')
    questions = json.loads((folder / 'questions.json').read_text())['questions']
    prompts = json.loads((folder / 'prompts.json').read_text())['prompts']
    require([q['id'] for q in questions] == [p['id'] for p in prompts] == ['SC01', 'SC02', 'SC03', 'SC04'], 'Question set differs')
    packet = (folder / 'source_packet.txt').read_text()
    for question, prompt in zip(questions, prompts):
        require(prompt['messages'][1] == {'role': 'user', 'content': 'OFFICIAL-SOURCE PACKET:\n' + packet + '\n\nQUESTION:\n' + question['question']}, 'Actual input differs')
    reference = json.loads((folder / 'development_reference.json').read_text())
    require(reference['independent_semantic_gold'] is False and reference['independent_human_labels'] == 0, 'Reference provenance differs')
    require(reference['questions_sha256'] == digest((folder / 'questions.json').read_bytes())['sha256'], 'Reference questions differ')
    require(reference['source_units_sha256'] == digest((folder / 'source_units.json').read_bytes())['sha256'], 'Reference sources differ')
    paragraph_quotes, metadata_values = 0, 0
    for claims in reference['requested_claims'].values():
        for claim in claims:
            for evidence in claim['evidence']:
                if 'paragraph_index' in evidence:
                    text = units[evidence['source_id']]['paragraphs'][evidence['paragraph_index']][evidence['view']]
                    start, end = evidence['span']
                    require(text[start:end] == evidence['quote'], 'Reference quote differs'); paragraph_quotes += 1
                else:
                    row = metadata[evidence['source_id']]
                    require(row.get('fields', row.get('recorded_fields'))[evidence['field']] == evidence['value'], 'Reference metadata differs'); metadata_values += 1
    plan = json.loads((folder / 'plan.json').read_text())
    require(plan['settings']['repeat_last_n'] == plan['context_size'], 'Explicit whole-context penalty window missing')
    require(plan['settings']['n_predict'] == 4096 and plan['cpu_threads'] == 4 and plan['gpu_layers'] == 0, 'Fixed execution settings differ')
    require(manifest['model_responses_included'] == 0 and manifest['independent_human_labels'] == 0, 'Input bundle misrepresented as results')
    return {'status': 'PASS_STANDALONE_NATIVE_INPUT_REPLAY', 'files': len(manifest['files']),
        'source_units': len(units), 'native_occurrences': sum(len(u['occurrences']) for u in units.values()),
        'paragraphs': sum(len(u['paragraphs']) for u in units.values()), 'metadata_rows': len(metadata),
        'native_archive_member_checks': archive_checks, 'development_paragraph_quotes': paragraph_quotes,
        'development_metadata_values': metadata_values, 'questions': len(questions),
        'new_model_requests': 0, 'independent_human_labels': 0, 'semantic_accuracy': None,
        'scope': 'Packaged bytes, raw archive members, bounded XML paragraph projections, literal collected spreadsheet/CSV rows, lossless input packet, question prompts and development reference coordinates. Not full Word rendering, fresh inference, independent semantic truth or method superiority.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('bundle', type=Path, nargs='?', default=Path('.'))
    args = parser.parse_args()
    print(json.dumps(verify(args.bundle.resolve()), indent=2))
