#!/usr/bin/env python3
"""Measure first-return source-aware actions with unconditional action controls.

All policies share the same initial answer and recommendation. The adaptive
policy uses that first recommendation, never the author reference. Missing
target text is a declared source ablation. Initial successes are retained.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess

import run_codex_relation_comparison as executor

ROOT = executor.ROOT
AREA = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
OUT = AREA / 'priority10-followup-action-utility'
VARIANTS = ('source_aware', 'always_ask', 'always_acquire')
ACTIONS = ('ACQUIRE', 'ASK', 'RETAIN', 'KEEP_UNKNOWN')
POLICY = '''You answer questions about a bounded collection of versioned technical records.
Use only the supplied source text and source inventory. No tools or outside
knowledge. A CR is a proposal; its before/after text is not an observed published
version. Byte-identical WG/TSG copies and matching observed wording do not prove
official approval, sole causation, first introduction or device performance.
Preserve applicability, version and stated exceptions. Cite literal nonempty
quotes with supplied source IDs for technical facts. Inventory absence supports
an unknown, not a universal negative. Answer each of Q1,Q2,Q3 in order with at
most 250 words of answer text each. Return only JSON:
{"answers":[{"id":"Q1","answer":"...","established_facts":["..."],
"missing_information":["..."],"evidence":[{"source_id":"...","quote":"..."}],
"next_action":"ACQUIRE|ASK|RETAIN|KEEP_UNKNOWN","action_reason":"..."}]}
Choose one next action per question from the actual inventory and supplied text.
ACQUIRE: necessary evidence is not supplied but exists in the bounded available
source catalogue. ASK: necessary text is already supplied but a detail needs
explicit reconsideration. RETAIN: the answer already resolves the request at
its supported scope. KEEP_UNKNOWN: necessary authority, history or measurement
evidence is absent from the entire available catalogue; name the missing type.
The available catalogue describes roles, versions, clauses and entry labels,
never a reference answer. Do not infer technical facts from catalogue metadata.
If this is a follow-up, reassess all the same questions using the newly supplied
text, if any. The prior answer is an unverified model response, not evidence.
'''

REQUESTS = {
    'spec38_304_CR0453': {
        'clause': '5.2.4.12.2', 'entry_labels': [],
        'questions': [
            'Compare TS38.304 19.1.0 and 19.2.0 clause5.2.4.12.2: what condition is stated for a UE supporting both LP-SS and SSB to choose either LR measurement type when determining the relaxed measurement criterion? Separate CR0453 revision1 proposed wording from wording directly observed in each published version.',
            'In those two observed versions and that same clause, does adding a condition require the UE to always select LP-SS rather than SSB, or is the choice still up to UE implementation? State the supported scope and retain the configured-threshold condition.',
            'Do these sources establish official CR0453 approval, its sole causal responsibility for the observed wording, or a particular deployed UE satisfying the criterion? Distinguish observed text, proposed text and missing approval/history/device evidence.'
        ],
        'technical_reference': [
            'The base allows implementation choice if UE supports both measurement types. The target adds that thresholds for both measurement types are configured. CR proposed text matches that local target wording; no sole-causation or approval inference.',
            'The choice remains up to UE implementation; target applicability includes support of both types and thresholds configured for both. No mandatory preference for LP-SS over SSB follows.'
        ],
        'anchor_needles': ['If UE supports both measurement types', 'up to UE implementation to choose LR measurements based on LP-SS or based on SSB']
    },
    'spec38_305_CR0197': {
        'clause': '8.10.3.1.2.1.0', 'entry_labels': [],
        'questions': [
            'Compare TS38.305 19.0.0 and 19.1.0 clause8.10.3.1.2.1.0: what exact change occurs in the sentence describing the number of TRPs for which a UE can store assistance data? Separate CR0197 revision1 proposal from each directly observed version and distinguish editorial wording from a changed numeric limit.',
            'In those same observed versions, what happens when a UE receives assistance data for a TRP whose data it has already stored, versus a new TRP? Does the observed edit remove the UE-capability/number-of-areas qualification or establish unlimited storage? Preserve the unchanged conditions.',
            'Do these sources establish official CR0197 approval, its sole causal responsibility for every clause difference, or a particular deployed UE\'s positioning performance or storage limit? Distinguish local observed text from absent approval/history/device evidence.'
        ],
        'technical_reference': [
            'The base says number TRPs and the target says number of TRPs. CR proposes insertion of of. This is an editorial insertion in the compared sentence, not a measured or newly numeric storage limit.',
            'Existing TRP data is overwritten; a new TRP is stored while previously stored data for other TRPs is maintained. PRS-ID and Cell-ID identify TRPs. Number of supported areas indicates the UE capability for stored TRPs; unlimited storage is not established.'
        ],
        'anchor_needles': ['The number', 'it overwrites the stored assistance data']
    },
    'spec38_306_CR1403': {
        'clause': '4.2.7.4',
        'entry_labels': ['parallelTxPUCCH-PUSCH-r17', 'parallelTxPUCCH-PUSCH-SamePriority-r17'],
        'questions': [
            'Compare TS38.306 19.1.0 and 19.2.0 clause4.2.7.4 entries parallelTxPUCCH-PUSCH-r17 and parallelTxPUCCH-PUSCH-SamePriority-r17: what changes in their component-carrier/frequency-band applicability wording? Separate CR1403 revision2 proposal from each directly observed version; assess whether target wording licenses simultaneous transmission within one frequency band.',
            'For those two entries in the same observed versions, distinguish different-priority versus same-priority transmission. Does the edit remove the NR SA or NR SCG in (NG)EN-DC qualification? Preserve the unchanged setting and the explicit target frequency-band condition.',
            'Do these sources establish official CR1403 approval, the requested liaison\'s complete original content, sole causal responsibility for the observed wording, or simultaneous-transmission performance of a particular deployed UE? Distinguish proposal claims and observed versions from absent records.'
        ],
        'technical_reference': [
            'The base refers to across CCs in an inter-band CA band combination. Target explicitly says across different CCs belonging to different frequency bands in a CA band combination. Both named entries carry this change; the target does not license within-one-band operation through these entries.',
            'parallelTxPUCCH-PUSCH-r17 addresses different priorities; the SamePriority entry addresses the same priority. Both retain NR SA or NR SCG in (NG)EN-DC. The same-priority entry retains reference to clause9 of TS38.213; its full text is not supplied.'
        ],
        'anchor_needles': ['parallelTxPUCCH-PUSCH-r17', 'parallelTxPUCCH-PUSCH-SamePriority-r17']
    }
}


def selected_units(pool, request):
    result = []
    labels = set(request['entry_labels'])
    for u in pool['units']:
        if u['role'] == 'CR' and u['clause'] is None:
            result.append(u)
        elif u['clause'] == request['clause']:
            if not labels or u['kind'] == 'paragraph':
                result.append(u)
            elif u.get('cells'):
                lines = (u['cells'][0]['after'] or u['cells'][0]['before']).splitlines()
                key = lines[0].strip() if lines else ''
                if key in labels or u['row'] == 0:
                    result.append(u)
    return result


def model_units(units):
    return [{k: u[k] for k in ('id', 'role', 'version', 'clause', 'text')} for u in units]


def validate_answer(path, input_units):
    answer = executor.read(path)
    assert [a['id'] for a in answer['answers']] == ['Q1', 'Q2', 'Q3'], 'Preserve malformed first output'
    by_id = {u['id']: u['text'] for u in input_units}
    for a in answer['answers']:
        assert isinstance(a['answer'], str) and a['answer'].strip()
        assert a['next_action'] in ACTIONS and isinstance(a['action_reason'], str)
        assert isinstance(a['established_facts'], list) and isinstance(a['missing_information'], list)
        assert isinstance(a['evidence'], list)
        for e in a['evidence']:
            assert e['source_id'] in by_id and e['quote'] and e['quote'] in by_id[e['source_id']], 'Literal citation defect, not automatic semantic failure'
    return answer


def prepare():
    executor.guarded()
    population = executor.read(OUT / 'selection.json')
    assert [c['id'] for c in population['cases']] == list(REQUESTS), 'Do not silently substitute selected cases'
    (OUT / 'inputs').mkdir()
    executor.text_new(OUT / 'answer_and_action_policy.txt', POLICY)
    jobs, references, sources = [], [], []
    for c in population['cases']:
        case = executor.verify(c['selection']).parent
        preparation = executor.read(case / 'source_preparation.json')
        pool_path = executor.verify(preparation['pool'])
        pool = executor.read(pool_path)
        request = REQUESTS[c['id']]
        scoped = selected_units(pool, request)
        assert all(any(u['role'] == r for u in scoped) for r in ('CR', 'base', 'target'))
        packet = case / 'sources/action_scope.json'
        executor.save(packet, {'units': scoped, 'parent_pool': preparation['pool'],
                              'rule': 'All CR cover units and the explicit question clause; for named table entries keep full matching first-cell rows and original row0 headers, with clause prose. No output or reference occurrence ID selection.',
                              'request_clause': request['clause'], 'entry_labels': request['entry_labels'],
                              'scope': 'Only saved question-scoped original units; outside rows/clauses, external references and complete native rendering are not supplied or certified.'})
        inventory = {'specification': c['selected']['spec_number'], 'submitted_CR': pool['inventory']['submitted_CR'],
                     'wg_tdoc': pool['inventory']['wg_tdoc'], 'tsg_copy': pool['inventory']['tsg_copy'],
                     'tsg_copy_is_byte_identical': pool['inventory']['tsg_copy_is_byte_identical'],
                     'available_catalogue': [{'role': r, 'version': next(u['version'] for u in scoped if u['role'] == r),
                                               'clause': request['clause'], 'entry_labels': request['entry_labels']} for r in ('CR', 'base', 'target')],
                     'absent_evidence_types': pool['inventory']['absent_evidence_types'],
                     'source_scope': 'CR cover plus stated question clause/entry excerpts; proposals and observed versions have different roles. Available catalogue is not technical evidence.',
                     'projection_scope': pool['inventory']['projection_scope']}
        questions = [{'id': 'Q' + str(i + 1), 'request': q} for i, q in enumerate(request['questions'])]
        source_chars = sum(len(u['text']) for u in scoped)
        for allocation in ('withheld_target', 'intact'):
            actual = [u for u in scoped if allocation == 'intact' or u['role'] != 'target']
            body = {'questions': questions, 'source_inventory': inventory,
                    'supplied_sources': model_units(actual), 'phase': 'initial'}
            path = OUT / 'inputs' / (c['id'] + '.' + allocation + '.initial.json')
            executor.save(path, body)
            jobs.append({'id': c['id'] + '.' + allocation, 'case': c['id'], 'allocation': allocation,
                         'input': executor.bind(path), 'scope': executor.bind(packet),
                         'source_characters': sum(len(u['text']) for u in actual),
                         'available_source_characters': source_chars,
                         'source_occurrences': len(actual), 'phase': 'initial'})
        anchors = []
        for role in ('base', 'target'):
            for needle in request['anchor_needles']:
                matches = [u for u in scoped if u['role'] == role and needle in u['text']]
                assert matches, (c['id'], role, needle)
                anchors.extend({'role': role, 'source_id': u['id'], 'quote': u['text']} for u in matches)
        references.append({'case': c['id'], 'technical_reference': request['technical_reference'],
                           'anchors': anchors,
                           'Q3': 'Not established by this bounded source inventory. Matching observed text and byte-identical CR copies do not establish official approval, sole causation, complete external liaison content or deployed device facts.',
                           'expected_actions_intact': ['RETAIN', 'RETAIN', 'KEEP_UNKNOWN'],
                           'expected_actions_withheld_target': ['ACQUIRE', 'ACQUIRE', 'KEEP_UNKNOWN'],
                           'withheld_target_resolution': 'Q1/Q2 may state CR proposal and base facts but cannot verify the requested target observations until target text is supplied. Source-supported abstention is distinguished from resolved technical decision.'})
        sources.extend([executor.bind(case / 'source_preparation.json'), executor.bind(pool_path), executor.bind(packet)])
    executor.save(OUT / 'author_reference.json', {'state': 'ROOT_SOURCE_SUPPORTED_REFERENCE_FROZEN_BEFORE_FIRST_OUTPUTS',
        'created_utc': executor.now(), 'cases': references, 'sources': sources,
        'reference_not_supplied_to_predictions': True, 'expert_gold': False,
        'root_readback_scope': 'All CR and selected endpoint units for38.304/38.305;38.306 CR cover, first22000 characters, all five changed table rows and corresponding base/target rows. The questions use two of those five named entries. Full38.306 CR/table/specification semantic reading is not claimed.',
        'causal_or_population_accuracy_claim': False})
    previous = executor.read(AREA / 'priority9-source-decision-audit/protocol.json')
    binary = executor.verify(previous['cli_binary'])
    auth = subprocess.run([str(binary), 'login', 'status'], capture_output=True, text=True, timeout=30)
    assert auth.returncode == 0 and 'ChatGPT' in auth.stdout + auth.stderr
    policy = executor.bind(OUT / 'answer_and_action_policy.txt')
    executor.save(OUT / 'protocol.json', {'state': 'FROZEN_BEFORE_FIRST_ANSWER_AND_ACTION_MEASUREMENT',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
        'dependencies': [executor.bind(OUT / n) for n in ('selection.json', 'primary_recomparison.json', 'dependency_audit.json', 'author_reference.json')] + sources + [executor.bind(Path(__file__))],
        'reference_not_supplied': executor.bind(OUT / 'author_reference.json'),
        'cli_binary': previous['cli_binary'], 'config_overrides': previous['config_overrides'], 'sampling': previous['sampling'],
        'policies': {'answer': policy}, 'jobs': jobs, 'variants': VARIANTS,
        'shared_initial': 'Each allocation has one first answer with automatic action recommendations. That exact initial answer/cost is shared by all three policies. Controls ignore recommendations. No cost-free oracle or post-output root action override.',
        'source_aware': 'If any first recommendation is ACQUIRE, acquire all remaining target units from the same bounded question scope. If no ACQUIRE but any ASK, reconsider the same text. If only RETAIN/KEEP_UNKNOWN, retain the initial output without another model call. This batch-level union is applied mechanically; per-question recommendations are also scored.',
        'always_ask': 'One follow-up reconsideration with unchanged source information, regardless of first success or recommendation.',
        'always_acquire': 'One follow-up after supplying every remaining target unit from the same catalogue. Intact allocation has no remaining source; that fact is preserved.',
        'identical_acquire_followups': 'Literal identical policy+question+source+prior-answer follow-up inputs are executed once and referenced by each requesting variant, not counted as independent observations. Logical workflow costs include the shared result once in each variant.',
        'same_explicit_predicates_per_allocation': True, 'same_per_question_answer_allowance_words': 250,
        'action_limit': 'At most one post-initial action/follow-up per allocation and policy; stopping is allowed.',
        'source_volume_limit': max(j['available_source_characters'] for j in jobs),
        'source_volume_reason': 'Actual maximum of complete predetermined question-scoped units; no output-selected trimming or wider-corpus retrieval. Every variant has the identical catalogue and limit.',
        'per_turn_wall_limit_seconds': 900, 'attempts_per_unique_input_and_policy': 1, 'retries': 0,
        'controlled_ablation': 'Withheld-target allocation intentionally removes observed target text. It is not a natural retrieval-failure sample.',
        'intact_reference': 'Intact allocation is the same scoped evidence with the target present. Keep successes/ceiling results and unknown boundary questions; do not manufacture omission failures.',
        'cost': 'Report first-call and follow-up input/output/cache tokens, model calls, source characters acquired, observed seconds. Physical unique dispatches and logical shared workflow costs remain separate. No provider money/TCO inference.',
        'failure': 'Preserve an incomplete/uncontrolled or schema-invalid first return and stop dispatching; no reroll.',
        'claim_scope': 'Three prospectively metadata-selected new-specification development cases, source-dependency limitations retained. An action diagnostic and controlled workflow utility study, not independent expert gold, population accuracy, named-system reproduction or a new general adaptive-retrieval principle.',
        'protected_email_family_bodies_opened': 0})
    print(json.dumps({'state': 'P10_PROTOCOL_FROZEN', 'initial_jobs': len(jobs), 'case_scope_characters': {j['case']: j['available_source_characters'] for j in jobs}, 'model_calls': 0}), flush=True)


def run_initial(case_id):
    executor.guarded()
    plan = executor.read(OUT / 'protocol.json')
    for b in plan['dependencies'] + list(plan['policies'].values()):
        executor.verify(b)
    executor.OUT = OUT
    predictions = OUT / 'predictions'
    predictions.mkdir(exist_ok=True)
    for job in [j for j in plan['jobs'] if j['case'] == case_id]:
        destination = predictions / (job['id'] + '.initial')
        body = executor.read(executor.verify(job['input']))
        answer_path = executor.turn(plan, destination, job['input'], 'answer')
        try:
            answer = validate_answer(answer_path, body['supplied_sources'])
        except Exception as error:
            executor.save(destination / 'schema_failure.json', {'state': 'FIRST_OUTPUT_SCHEMA_OR_LITERAL_FAILURE', 'error': repr(error), 'retries': 0})
            raise
        executor.save(destination / 'mechanical_check.json', {'state': 'JSON_SCHEMA_AND_LITERAL_QUOTES_PASS',
            'semantic_assessment': 'NOT_PERFORMED', 'actions': [a['next_action'] for a in answer['answers']],
            'answer': executor.bind(answer_path), 'first_return': True})


def run_followups(case_id):
    executor.guarded()
    plan = executor.read(OUT / 'protocol.json')
    for b in plan['dependencies'] + list(plan['policies'].values()):
        executor.verify(b)
    executor.OUT = OUT
    for job in [j for j in plan['jobs'] if j['case'] == case_id]:
        prior = OUT / 'predictions' / (job['id'] + '.initial')
        initial_result = executor.read(prior / 'result.json')
        assert initial_result['state'] == 'SAVED_CONTROLLED_ANSWER'
        executor.verify(executor.read(prior / 'mechanical_check.json')['answer'])
        initial_body = executor.read(executor.verify(job['input']))
        initial_answer = validate_answer(executor.verify(initial_result['answer']), initial_body['supplied_sources'])
        all_units = model_units(executor.read(executor.verify(job['scope']))['units'])
        actions = [a['next_action'] for a in initial_answer['answers']]
        policy_action = 'ACQUIRE' if 'ACQUIRE' in actions else 'ASK' if 'ASK' in actions else 'STOP'
        variants = {'source_aware': policy_action, 'always_ask': 'ASK', 'always_acquire': 'ACQUIRE'}
        operations, dispatched = [], {}
        for variant in VARIANTS:
            action = variants[variant]
            if action == 'STOP':
                operations.append({'variant': variant, 'action': action, 'answer': initial_result['answer'], 'result': executor.bind(prior / 'result.json'), 'additional_calls': 0, 'acquired_source_characters': 0})
                continue
            actual = all_units if action == 'ACQUIRE' else initial_body['supplied_sources']
            body = {**initial_body, 'supplied_sources': actual, 'phase': 'follow-up',
                    'prior_answer': initial_answer,
                    'instruction': 'Reassess the same explicit Q1,Q2,Q3 against the supplied sources. Preserve supported facts and correct any missing detail or scope promotion. Prior answer is not evidence.'}
            path = OUT / 'inputs' / (job['id'] + '.' + action.lower() + '.followup.json')
            key = hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
            if key not in dispatched:
                executor.save(path, body)
                destination = OUT / 'predictions' / (job['id'] + '.' + action.lower() + '.followup')
                answer_path = executor.turn(plan, destination, executor.bind(path), 'answer')
                try:
                    validate_answer(answer_path, actual)
                except Exception as error:
                    executor.save(destination / 'schema_failure.json', {'state': 'FIRST_OUTPUT_SCHEMA_OR_LITERAL_FAILURE', 'error': repr(error), 'retries': 0})
                    raise
                dispatched[key] = {'input': executor.bind(path), 'answer': executor.bind(answer_path), 'result': executor.bind(destination / 'result.json')}
            have = {u['id'] for u in initial_body['supplied_sources']}
            acquired = sum(len(u['text']) for u in actual if u['id'] not in have)
            operations.append({'variant': variant, 'action': action, **dispatched[key],
                               'additional_calls': 1, 'acquired_source_characters': acquired,
                               'physical_call_shared_by_identical_input': sum(variants[v] == action for v in VARIANTS) > 1})
        executor.save(OUT / 'predictions' / (job['id'] + '.operations.json'), {
            'state': 'FIRST_RECOMMENDATIONS_APPLIED_WITHOUT_REFERENCE_OR_ROOT_OVERRIDE',
            'initial': executor.bind(prior / 'result.json'), 'recommended_actions': actions,
            'operations': operations, 'physical_followup_calls': len(dispatched), 'retries': 0})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'initial', 'followups'))
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        assert args.case in REQUESTS
        (run_initial if args.action == 'initial' else run_followups)(args.case)
