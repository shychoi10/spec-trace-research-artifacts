#!/usr/bin/env python3
"""Audit P11 byte/package/literal dependencies, including all P10 sources."""
import json
from pathlib import Path
import re

import audit_followup_sources as prior

e = prior.executor
ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
OUT = prior.AREA / 'priority11-inventory-coverage-actions'


def main():
    e.guarded()
    selected = e.read(OUT / 'selection.json')
    rows = e.read(prior.LIB / 'rows.json')
    docs = e.read(prior.LIB / 'documents.json')
    p7s = e.read(prior.AREA / 'priority7-new-component-diagnostic/selection.json')
    p7c = e.read(prior.AREA / 'priority7-new-component-diagnostic/cr_preparation.json')
    natives = {i['native']['sha256'] for r in rows for i in r['inputs']}
    natives |= {o['native']['sha256'] for o in p7c['origins']}
    packages = {r['tsg_packet']['sha256'] for r in rows if r['tsg_packet']}
    packages.add(p7s['archives']['tsg']['sha256'])
    families = {r[k].upper() for r in rows for k in ('wg_tdoc', 'tsg_tdoc')}
    families |= {ref['family'].upper() for d in docs for ref in d['references']}
    families |= {p7s['selected']['wg_tdoc'], p7s['selected']['tsg_tdoc']}
    p10 = prior.AREA / 'priority10-followup-action-utility'
    p10selection = e.read(p10 / 'selection.json')
    historical = [e.bind(prior.LIB / n) for n in ('rows.json', 'documents.json')]
    historical += [e.bind(p10 / 'selection.json'), e.bind(prior.AREA / 'priority7-new-component-diagnostic/cr_preparation.json')]
    for c in p10selection['cases']:
        directory = e.verify(c['selection']).parent
        s = e.read(directory / 'selection.json')
        cr = e.read(directory / 'sources/CR.rows.json')
        natives.add(cr['native']['sha256'])
        packages.add(s['archives']['tsg']['sha256'])
        families |= {s['selected'][k].upper() for k in ('wg_tdoc', 'tsg_tdoc')}
        for u in cr['units']:
            families |= {re.sub(r'r\d+$', '', m.group(), flags=re.I).upper() for m in prior.TDOC.finditer(u['text'])}
        historical += [e.bind(directory / 'selection.json'), e.bind(directory / 'sources/CR.rows.json')]
    allocation = e.read(prior.LIB.parent / 'allocation.json')
    protected = set(e.read(e.verify(allocation['protected_scope']))['protected_record_families'])
    protected |= {json.loads(line)['record'] for line in e.verify(allocation['protected_inventory']).open()}
    cases = []
    for c in selected['cases']:
        directory = e.verify(c['selection']).parent
        s = e.read(directory / 'selection.json')
        cr = e.read(directory / 'sources/CR.rows.json')
        preparation = e.read(directory / 'source_preparation.json')
        occurrences = []
        for u in cr['units']:
            for m in prior.TDOC.finditer(u['text']):
                family = re.sub(r'r\d+$', '', m.group(), flags=re.I).upper()
                occurrences.append({'source_id': u['id'], 'literal': m.group(), 'family': family,
                                    'span': [m.start(), m.end()], 'protected_family': family in protected})
        refs = sorted({v for u in cr['units'] for v in prior.SPEC.findall(u['text'])})
        cases.append({'case': c['id'], 'selection': c['selection'], 'CR_native': cr['native'],
            'WG_TSG_native_byte_identity': cr['WG_TSG_native_byte_identity'],
            'prior_CR_native_byte_match': cr['native']['sha256'] in natives,
            'prior_TSG_package_byte_match': s['archives']['tsg']['sha256'] in packages,
            'prior_literal_family_overlap': sorted({o['family'] for o in occurrences} & families),
            'literal_tdoc_occurrences': occurrences,
            'referenced_specifications_in_CR_text': refs,
            'known_exposed_specification_references': sorted(set(refs) & set(selected['excluded_specifications'])),
            'protected_literal_families': sorted({o['family'] for o in occurrences if o['protected_family']}),
            'covers': [{'role': v['role'], 'version': v['version'], 'identity': v['cover_identity']} for v in preparation['endpoints']],
            'source_preparation': e.bind(directory / 'source_preparation.json'),
            'independent_component_certified': False})
    e.save(OUT / 'dependency_audit.json', {'state': 'P11_ACTUAL_DEPENDENCIES_AUDITED_BEFORE_OUTPUTS',
        'created_utc': e.now(), 'producer': e.bind(Path(__file__)), 'selection': e.bind(OUT / 'selection.json'),
        'historical_metadata': historical, 'cases': cases, 'model_calls': 0,
        'scope': '648-row library, P7 and all three P10 native CR/package/literal TDoc families. Earlier CR projections scanned for literal references only, not reinterpreted. General specification references and hidden semantic/training dependencies not ruled out.',
        'independent_components_certified': False, 'evaluation_split_created': False,
        'protected_email_family_bodies_opened': 0})
    print(json.dumps({'state': 'P11_DEPENDENCY_AUDIT_SAVED', 'cases': [{k: c[k] for k in
        ('case', 'prior_CR_native_byte_match', 'prior_TSG_package_byte_match', 'prior_literal_family_overlap', 'known_exposed_specification_references')} for c in cases]}))


if __name__ == '__main__':
    main()
