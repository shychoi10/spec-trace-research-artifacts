#!/usr/bin/env python3
"""Prepare, publish and anonymously replay the separate P11 development resource.

Each action is explicit and requires the existing local CPU/nice guard. Preparation
does not run inference or publish; replay checks recorded provenance, not meaning.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

sys.dont_write_bytecode = True
import verify_inventory_coverage_resource as verifier
import verify_source_decision_resource as provenance


ROOT = next(path for path in Path(__file__).resolve().parents if (path / '.git').exists())
OUT = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation/priority11-inventory-coverage-actions'
PUB = OUT / 'publication'
REPO = 'shychoi10/spec-trace-research-artifacts'
DIRECTORY = 'inventory_coverage_development'
ARCHIVE = DIRECTORY + '.tar.gz'
NAMES = ('README.md', 'resource.json', ARCHIVE, 'checksums.sha256')
REQUIRED = ('selection.json', 'strategy_adoption.json', 'dependency_audit.json',
            'root_source_readback.json', 'author_reference.json', 'protocol.json',
            'answer_and_action_policy.txt', 'completed_first_call_accounting.json',
            'author_answer_readback.json')
PRODUCERS = ('prepare_inventory_coverage_sources.py', 'audit_inventory_coverage_sources.py',
             'compare_inventory_coverage_actions.py', 'admit_inventory_coverage_dispatch.py',
             'collect_inventory_coverage_actions.py', 'publish_inventory_coverage_resource.py')
GUARD_PREFIXES = ('selection-', 'base-', 'cr-', 'endpoints-', 'dependency-audit-',
                  'protocol-prepare-', 'initial-', 'followup-', 'first-return-accounting-')
README = '''# Inventory coverage development resource

This separate P11 development resource contains three metadata-selected cases.
Selection and eligibility metadata are preserved in selection.json. The saved
mixed_catalogue and intact allocations use whole source roles and complete
declared clauses as controls, rather than selecting excerpts from model outputs.
The frozen policy names are answer_aware, inventory_optimized and inventory_first.

Inventory-first reuses the full identical intact initial input and its recorded
physical result. Logical workflows charge their actual declared result bindings,
including initial diagnosis where applicable; physical calls are deduplicated by
result binding. Reuse does not remove logical charges. Actual counts and measured
costs are in completed_first_call_accounting.json and are not preset by this
publisher. Optional unobserved token usage remains null, with missing fields and
partial observed sums recorded explicitly; observed durations are not causal
latency or total cost of ownership. Source preparation and author readback are
outside model-call costs.

This is development material and author interpretation, not independent semantic
gold. Root textual-comparison readback completion does not assert that every
requested fact was observed. The package preserves saved source projections,
inputs, first returns, operations, admissions, completion guards and hash-bound
protocol dependencies. Its replay does not rerender native documents, run a
model, assess answer meaning, or reverify the host CLI executable. CLI binding
metadata remains recorded; the executable and authentication files are excluded.

Run python3 -B verify.py /path/to/unpacked/package, and separately run
python3 -O -B verify.py /path/to/unpacked/package. Both use only the standard
library and saved package bytes. manifest.json covers every member other than
itself; source_locators.json maps original artifact bindings to package members.

Canonical research records, manuscripts, reviews, external memory, protected
email source bodies and CLI authentication are excluded. Existing public RAN
case native files are preserved as recorded bytes, without native rerender.
Local preparation, repository upload and credential-free download replay are
separate recorded states. No DOI or independent external users are claimed.
An anonymous check on the preparing host is not independent external use.
'''


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def guarded():
    require(sorted(os.sched_getaffinity(0)) == [0, 1]
            and os.getpriority(os.PRIO_PROCESS, 0) == 19,
            'CPU affinity and nice resource guard required')


def read(path):
    return provenance.read(Path(path))


def save(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def text_new(path, value):
    with Path(path).open('x', encoding='utf-8') as stream:
        stream.write(value)


def digest(path):
    raw = Path(path).read_bytes()
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def bind(path):
    path = Path(path).resolve()
    locator = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    return {'path': locator, **digest(path)}


def allowed_source(path):
    path = Path(path)
    require(not path.is_symlink(), 'Do not distribute a symlink: ' + str(path))
    path = path.resolve()
    require(path.is_relative_to(ROOT), 'Dependency outside research repository: ' + str(path))
    parts = {part.lower() for part in path.relative_to(ROOT).parts}
    forbidden = {'.codex', '.ssh', '.aws', '.config', 'memory', 'memories',
                 'review', 'reviews', 'email', 'emails', 'mail', 'protected84',
                 'protected_84', 'protected-84'}
    require(not parts.intersection(forbidden), 'Excluded source category: ' + str(path))
    name = path.name.lower()
    require(not name.startswith(('canonical', 'memory', 'review', 'credentials', 'token'))
            and name not in {'auth.json', 'auth.toml', '.env', 'id_rsa', 'id_ed25519'}
            and not name.startswith('manuscript'), 'Excluded source file: ' + str(path))
    require(path.is_file(), 'Missing source file: ' + str(path))
    return path


def verify_binding(binding):
    require(isinstance(binding, dict) and isinstance(binding.get('path'), str),
            'Invalid saved artifact binding')
    path = allowed_source(ROOT / binding['path'])
    require(digest(path) == provenance._hash_fields(binding),
            'Bound artifact changed: ' + binding['path'])
    return path


def new_member_path(package, relative):
    require(isinstance(relative, str) and bool(relative), 'Empty package member')
    name = PurePosixPath(relative)
    require(not name.is_absolute() and not PureWindowsPath(relative).drive
            and '\\' not in relative and '..' not in name.parts
            and relative == name.as_posix() and relative != '.',
            'Non-canonical or escaping package member: ' + relative)
    target = package.joinpath(*name.parts)
    require(package in target.resolve().parents, 'Package member escapes destination')
    return target


def replay_subprocess(package, mode, output_prefix):
    command = [sys.executable] + (['-O'] if mode == 'optimized' else [])
    command += ['-B', str(package / 'verify.py'), str(package)]
    result = subprocess.run(command, cwd=package, capture_output=True, text=True)
    text_new(PUB / (output_prefix + '.stdout.txt'), result.stdout)
    text_new(PUB / (output_prefix + '.stderr.txt'), result.stderr)
    require(result.returncode == 0, 'Inspect first ' + output_prefix + ' replay failure')
    return json.loads(result.stdout)


def prepare():
    guarded()
    gate_bindings = {name: bind(OUT / name) for name in
                     ('completed_first_call_accounting.json', 'author_answer_readback.json',
                      'protocol.json')}
    accounting = read(OUT / 'completed_first_call_accounting.json')
    assessment = read(OUT / 'author_answer_readback.json')
    count = accounting.get('physical_unique_answers')
    directly_read = assessment.get('physical_unique_answers_directly_read')
    require(type(count) is int and count > 0 and type(directly_read) is int,
            'Actual unique-answer accounting and readback counts required')
    require(assessment.get('root_completed') is True and directly_read == count,
            'Completed root readback must match actual unique-answer accounting')
    plan = read(OUT / 'protocol.json')
    for name in REQUIRED:
        allowed_source(OUT / name)
    dependencies = plan['dependencies'] + list(plan['policies'].values())
    for binding in dependencies + [accounting['collector'], accounting['protocol']]:
        verify_binding(binding)
    require(verify_binding(accounting['protocol']) == (OUT / 'protocol.json').resolve(),
            'Accounting does not bind the current P11 protocol')
    PUB.mkdir()
    package = PUB / 'package'
    package.mkdir()
    locators = {}

    def copy(source, relative):
        source = allowed_source(source)
        target = new_member_path(package, relative)
        target.parent.mkdir(parents=True, exist_ok=True)
        require(not target.exists(), 'Do not overwrite package member: ' + relative)
        before = bind(source)
        shutil.copyfile(source, target)
        require(digest(target) == provenance._hash_fields(before) and bind(source) == before,
                'Source changed during copy: ' + before['path'])
        require(before['path'] not in locators, 'Duplicate original artifact locator')
        locators[before['path']] = relative

    for name in REQUIRED:
        copy(OUT / name, name)
    for name, binding in gate_bindings.items():
        require(digest(package / name) == provenance._hash_fields(binding),
                'Readback, accounting or protocol changed during preparation: ' + name)
    # P11 carries eligibility in selection.json. Never borrow a P10 eligibility file.
    for name in ('root_first_four_answer_readback.json', 'root_initial_six_answer_readback.json'):
        if (OUT / name).is_file():
            copy(OUT / name, name)
    for folder in ('cases', 'inputs', 'predictions', 'dispatch_admissions'):
        require((OUT / folder).is_dir(), 'Missing P11 artifact directory: ' + folder)
        for source in sorted((OUT / folder).rglob('*')):
            if source.is_file():
                copy(source, str(source.relative_to(OUT)))
    for guard in sorted(OUT.glob('*-guard')):
        if not guard.name.startswith(GUARD_PREFIXES):
            continue
        outcome = read(guard / 'result.json')
        require(outcome.get('state') == 'CHILD_EXITED'
                and type(outcome.get('child_exit_code')) is int
                and outcome['child_exit_code'] == 0,
                'Uncompleted included guard: ' + guard.name)
        for name in ('admission.json', 'result.json', 'child.log'):
            if (guard / name).is_file():
                copy(guard / name, guard.name + '/' + name)
    for name in PRODUCERS:
        copy(Path(__file__).with_name(name), 'producers/' + name)
    copy(Path(verifier.__file__), 'verify.py')
    copy(Path(provenance.__file__), 'verify_source_decision_resource.py')
    for index, binding in enumerate(dependencies + [accounting['collector']]):
        source = verify_binding(binding)
        if binding['path'] not in locators:
            copy(source, 'dependencies/' + str(index) + '-' + source.name)
        require(digest(package / locators[binding['path']]) == provenance._hash_fields(binding),
                'Distributed dependency differs from saved binding')
    save(package / 'source_locators.json', locators)
    text_new(package / 'README.md', README)
    files = [{'path': str(f.relative_to(package)), **digest(f)}
             for f in sorted(package.rglob('*')) if f.is_file()]
    save(package / 'manifest.json', {'files': files, 'development_only': True,
        'expert_gold': False, 'native_projection_rerun': False})
    replay = verifier.verify(package)
    save(PUB / 'local_replay.json', replay)
    optimized = replay_subprocess(package, 'optimized', 'optimized_replay')
    require(replay == optimized, 'Normal and optimized local replay differ')
    with tarfile.open(PUB / ARCHIVE, 'x:gz') as archive:
        for source in sorted(package.rglob('*')):
            if source.is_file():
                archive.add(source, arcname=str(source.relative_to(package)))
    shutil.copyfile(package / 'README.md', PUB / 'README.md')
    save(PUB / 'resource.json', {'state': 'LOCALLY_PREPARED_AND_REPLAYED',
        'created_utc': now(), 'producer': bind(Path(__file__)), 'archive': digest(PUB / ARCHIVE),
        'files': len(files) + 1, 'unique_first_model_calls': replay['unique_model_calls'],
        'physical_unique_answers': count, 'logical_workflows': replay['logical_workflows'],
        'initial_allocations': replay['initial_allocations'],
        'source_cases': len({job['case'] for job in plan['jobs']}),
        'uploaded': False, 'anonymous_download_verified': False,
        'normal_and_optimized_replay_match': True,
        'missing_usage_fields': replay['missing_usage_fields'],
        'usage_totals_complete': replay['usage_totals_complete'],
        'expert_gold': False, 'native_projection_rerun': False,
        'doi': None, 'external_users_observed': 0})
    text_new(PUB / 'checksums.sha256', ''.join(
        digest(PUB / name)['sha256'] + '  ' + name + '\n' for name in NAMES[:-1]))
    print(json.dumps({'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'replay': replay}), flush=True)


def upload():
    """Use the existing isolated-checkout API, with a P11-specific commit description."""
    guarded()
    require(not (PUB / 'upload.json').exists(), 'Inspect existing upload instead of repeating')
    resource = read(PUB / 'resource.json')
    require(resource['state'] == 'LOCALLY_PREPARED_AND_REPLAYED', 'Local replay required')
    repository = json.loads(subprocess.check_output(
        ['gh', 'repo', 'view', REPO, '--json', 'isPrivate,url,defaultBranchRef'], text=True))
    require(not repository['isPrivate'] and repository['defaultBranchRef']['name'] == 'main',
            'Unexpected public repository or default branch')
    checkout = Path(tempfile.mkdtemp(prefix='inventory-coverage-publication-')) / 'checkout'
    with (PUB / 'upload_commands.log').open('x', encoding='utf-8') as log:
        def run(command):
            result = subprocess.run(command, cwd=checkout if checkout.exists() else None,
                                    stdout=log, stderr=subprocess.STDOUT)
            log.flush()
            require(result.returncode == 0, 'Inspect publication command failure')

        run(['gh', 'repo', 'clone', REPO, str(checkout), '--', '--depth=1'])
        require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout),
                'Isolated checkout is not clean')
        target = checkout / DIRECTORY
        target.mkdir()
        files = {}
        for name in NAMES:
            source = PUB / name
            before = digest(source)
            shutil.copyfile(source, target / name)
            require(digest(target / name) == before and digest(source) == before,
                    'Publication input changed during copy')
            files[name] = before
        require(files[ARCHIVE] == resource['archive'], 'Archive differs from local replay')
        run(['git', 'add', '--', *[DIRECTORY + '/' + name for name in NAMES]])
        staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'],
                                         cwd=checkout, text=True).splitlines()
        require(set(staged) == {DIRECTORY + '/' + name for name in NAMES},
                'Unexpected staged files')
        run(['git', 'commit', '-m', 'Publish inventory coverage development and saved provenance replay'])
        commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
        run(['git', 'push', 'origin', 'HEAD:main'])
    record = {'status': 'UPLOADED_DOWNLOAD_UNVERIFIED', 'observed_utc': now(),
        'repository': repository['url'], 'commit': commit, 'directory': DIRECTORY,
        'files': files, 'isolated_checkout': str(checkout),
        'original_repository_remote_modified': False, 'prepared_resource_flags_preserved': True,
        'independent_semantic_gold': False, 'native_projection_rerun': False,
        'doi': None, 'external_users_observed': 0}
    save(PUB / 'upload.json', record)
    print(json.dumps(record), flush=True)


def check():
    guarded()
    record = read(PUB / 'upload.json')
    require(record['status'] == 'UPLOADED_DOWNLOAD_UNVERIFIED'
            and record['directory'] == DIRECTORY and set(record['files']) == set(NAMES),
            'Unexpected upload state or members')
    require(not (PUB / 'publication.json').exists(), 'Do not repeat completed public verification')
    outside = Path(tempfile.mkdtemp(prefix='inventory-coverage-anonymous-replay-'))
    download = outside / 'download'
    download.mkdir()

    def fetch(name):
        url = 'https://raw.githubusercontent.com/' + REPO + '/' + record['commit'] + '/' + DIRECTORY + '/' + name
        request = urllib.request.Request(url, headers={'User-Agent': 'inventory-coverage-replay'})
        require(not any(key.lower() in ('authorization', 'cookie')
                        for key, _ in request.header_items()), 'Credentials in anonymous request')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=180) as response:
            raw, status = response.read(), response.status
        target = download / name
        target.write_bytes(raw)
        require(digest(target) == record['files'][name], 'Downloaded hash mismatch: ' + name)
        return name, {'url': url, 'http_status': status, **digest(target),
                      'authorization_header_sent': False, 'cookie_header_sent': False}

    try:
        with ThreadPoolExecutor(max_workers=len(NAMES)) as pool:
            downloads = dict(pool.map(fetch, NAMES))
        unpacked = outside / 'unpacked'
        unpacked.mkdir()
        with tarfile.open(download / ARCHIVE) as archive:
            archive.extractall(unpacked, filter='data')
        normal = replay_subprocess(unpacked, 'normal', 'anonymous_normal')
        optimized = replay_subprocess(unpacked, 'optimized', 'anonymous_optimized')
        require(normal == optimized, 'Anonymous normal and optimized replay differ')
        require(normal == read(PUB / 'local_replay.json'), 'Anonymous and local replay differ')
        publication = {'status': 'PUBLIC_UPLOAD_AND_ANONYMOUS_ACTION_PROVENANCE_REPLAY_VERIFIED',
            'observed_utc': now(), 'repository': record['repository'], 'commit': record['commit'],
            'directory': DIRECTORY,
            'snapshot_url': record['repository'] + '/tree/' + record['commit'] + '/' + DIRECTORY,
            'downloaded_files': downloads, 'anonymous_replay': normal,
            'normal_and_optimized_replay_match': True, 'outside_repository_workspace': str(outside),
            'external_download_scope': 'Credential-free same-host replay outside checkout; not an independent user or machine.',
            'native_projection_rerun': False, 'meaning_certified': False, 'expert_gold': False,
            'external_users_observed': 0, 'doi': None, 'model_calls_for_replay': 0}
        save(PUB / 'publication.json', publication)
        print(json.dumps({'status': publication['status'], 'replay': normal}), flush=True)
    except BaseException as error:
        save(PUB / 'publication_download_failure.json',
             {'error': repr(error), 'workspace': str(outside), 'commit': record['commit']})
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'upload', 'check'))
    arguments = parser.parse_args()
    globals()[arguments.action]()
