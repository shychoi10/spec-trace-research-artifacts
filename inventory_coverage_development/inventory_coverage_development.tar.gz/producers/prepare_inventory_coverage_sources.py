#!/usr/bin/env python3
"""Select the next metadata-only batch and reuse unchanged native source tools."""
import argparse
import json
from pathlib import Path

import prepare_followup_action_sources as previous

e = previous.executor
ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
AREA = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
PRIOR = AREA / 'priority10-followup-action-utility'
OUT = AREA / 'priority11-inventory-coverage-actions'
CASE_BUDGET = 3


def require(condition, message):
    if not condition:
        raise ValueError(message)


def select():
    e.guarded()
    OUT.mkdir(parents=True, exist_ok=True)
    require(not (OUT / 'selection.json').exists(), 'Population already frozen')
    prior = e.read(PRIOR / 'selection.json')
    eligibility = e.read(e.verify(prior['metadata_eligibility']))
    e.verify(eligibility['metadata'])
    e.verify(eligibility['inventory'])
    excluded = sorted(set(prior['excluded_specifications']) |
                      {c['selected']['spec_number'] for c in prior['cases']})
    eligible = [r for r in eligibility['eligible_order'] if r['spec_number'] not in excluded]
    selected, seen = [], set()
    for row in eligible:
        if row['spec_number'] not in seen:
            selected.append(row)
            seen.add(row['spec_number'])
        if len(selected) == CASE_BUDGET:
            break
    require(selected, 'No new eligible source cases; preserve empty availability')
    parent_allocation = e.read(previous.LIBRARY / 'allocation.json')
    protected = set(e.read(e.verify(parent_allocation['protected_scope']))['protected_record_families'])
    protected |= {json.loads(line)['record'] for line in
                  e.verify(parent_allocation['protected_inventory']).open()}
    endpoints = {}
    for line in e.verify(eligibility['inventory']).open():
        row = json.loads(line)
        if row['wg'] == 'RAN2' and row['cover_status'] == 'matched':
            endpoints.setdefault(tuple(row['cover_identity']), []).append(row)
    folder = e.verify(eligibility['metadata']).parent.parent
    cases = []
    for row in selected:
        cid = 'spec' + row['spec_number'].replace('.', '_') + '_CR' + row['cr_number']
        case = OUT / 'cases' / cid
        case.mkdir(parents=True)
        archives = {role: folder / subdir / (row[key] + '.zip')
                    for role, subdir, key in [('wg', 'wg_docs', 'wg_tdoc'), ('tsg', 'TSG', 'tsg_tdoc')]}
        names = {role: previous.archive_names.members(path.read_bytes(), [], protected)
                 for role, path in archives.items()}
        target = sorted(endpoints[(row['spec_number'], row['new_version'])],
                        key=lambda t: (not t['path'].endswith('.zip'), t['path']))[0]
        e.verify({k: target[k] for k in ('path', 'bytes', 'sha256')})
        e.save(case / 'selection.json', {
            'state': 'CASE_METADATA_FROZEN_BEFORE_TECHNICAL_READING', 'created_utc': e.now(),
            'producer': e.bind(Path(__file__)), 'selected': row,
            'archives': {role: e.bind(path) for role, path in archives.items()},
            'archive_member_names_only': names,
            'target': {k: target[k] for k in ('path', 'bytes', 'sha256', 'cover_identity')},
            'exact_local_base_available': bool(endpoints.get((row['spec_number'], row['impacted_version']))),
            'protected_scope': parent_allocation['protected_scope'],
            'protected_inventory': parent_allocation['protected_inventory'],
            'independent_components_certified': False, 'evaluation_split_created': False,
            'model_calls': 0, 'source_bodies_read_for_selection': 0,
            'protected_email_family_bodies_opened': 0})
        cases.append({'id': cid, 'selected': row, 'selection': e.bind(case / 'selection.json')})
    e.save(OUT / 'selection.json', {
        'state': 'PROSPECTIVE_METADATA_POPULATION_FROZEN_BEFORE_BODIES_OR_OUTPUTS',
        'created_utc': e.now(), 'producer': e.bind(Path(__file__)),
        'parent_review_analysis': e.bind(ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/reviews/priority-sequence/priority-10/analysis.json'),
        'parent_selection': e.bind(PRIOR / 'selection.json'),
        'prior_metadata_eligibility': prior['metadata_eligibility'],
        'verified_current_metadata': eligibility['metadata'], 'verified_current_inventory': eligibility['inventory'],
        'excluded_specifications': excluded, 'cases': cases,
        'selection_rule': prior['selection_rule'], 'case_budget': CASE_BUDGET,
        'budget_reason': 'Small sequential development batch, not a statistical threshold. Preserve all cases and first returns without failure-conditioned replacement.',
        'available_new_specifications': len({r['spec_number'] for r in eligible}),
        'eligible_metadata_rows': len(eligible),
        'remaining_metadata_rows_not_selected': [r for r in eligible if r not in selected],
        'planned_measurement': 'First conditional answers and actual next actions versus optimized inventory-only acquisition/stopping and same-text reconsideration. Freeze questions, scopes, author references and matched one-follow-up protocol before outputs. Mixed supplied/unavailable predicates may be used; any controlled omission is labelled as an ablation.',
        'reference_status': 'Not yet authored; root direct reading required.',
        'source_bodies_read_for_selection': 0, 'model_calls': 0,
        'independent_components_certified': False, 'evaluation_split_created': False,
        'protected_email_family_bodies_opened': 0})
    print(json.dumps({'state': 'P11_METADATA_POPULATION_FROZEN', 'cases': selected,
                      'eligible_rows': len(eligible), 'model_calls': 0}), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['select', 'cr', 'fetch_base', 'endpoints'])
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.action == 'select':
        select()
    else:
        require(args.case is not None, 'Case identity required')
        previous.OUT = OUT
        previous.materialize(args.action, args.case)


if __name__ == '__main__':
    main()
