#!/usr/bin/env python3
"""Replay frozen P11 citations and account for actual shared first dispatches.

The collector performs no model calls, reference comparison or semantic judgment.
An inventory-first workflow charges its actual intact initial dispatch once.
Unavailable optional usage remains unknown in every affected aggregate.
"""
from collections import Counter, defaultdict
import json
import math
from pathlib import Path

import compare_inventory_coverage_actions as experiment


ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
OUT = experiment.OUT
e = experiment.executor
require = experiment.require
VARIANTS = ('answer_aware', 'inventory_optimized', 'inventory_first')
ALLOCATIONS = ('mixed_catalogue', 'intact')
FIELDS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens',
          'output_tokens', 'reasoning_output_tokens')
MANDATORY_USAGE = ('input_tokens', 'output_tokens')


def cost(binding):
    """Verify a controlled first return and retain its measured usage fields."""
    path = e.verify(binding)
    result = e.read(path)
    require(result['state'] == 'SAVED_CONTROLLED_ANSWER',
            'Uncontrolled first return cannot be collected: ' + binding['path'])
    require(type(result['returncode']) is int and result['returncode'] == 0
            and result['timed_out'] is False,
            'Failed or timed-out first return: ' + binding['path'])
    audit = e.collector.inspect_events(e.verify(result['events']))
    e.verify(result['stderr'])
    for key in ('event_count', 'startup_warnings', 'unexpected_tool_or_item_events',
                'turn_completed_events', 'errors'):
        require(result[key] == audit[key],
                'Saved event audit differs from first event stream: ' + key)
    require(not audit['errors'] and not audit['unexpected_tool_or_item_events'],
            'Uncontrolled event stream: ' + binding['path'])
    require(len(audit['turn_completed_events']) == 1,
            'Exactly one completed first turn is required: ' + binding['path'])
    usage = audit['turn_completed_events'][0].get('usage')
    require(isinstance(usage, dict),
            'Missing measured usage object: ' + binding['path'])
    measured, missing = {}, []
    for key in FIELDS:
        value = usage.get(key)
        if value is None:
            require(key not in MANDATORY_USAGE,
                    'Missing mandatory measured usage: ' + key + ' in ' + binding['path'])
            measured[key] = None
            missing.append(key)
        else:
            require(type(value) is int and value >= 0,
                    'Usage must be a nonnegative integer: ' + key)
            measured[key] = value
    elapsed = result['elapsed_seconds']
    require(type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0,
            'Invalid observed elapsed seconds: ' + binding['path'])
    return {'model_calls': 1, **measured, 'observed_seconds': elapsed,
            'missing_usage_fields': missing, 'usage_totals_complete': not missing}


def sum_costs(rows):
    """Unknown components remain null; measured partial sums are named explicitly."""
    output = {'model_calls': sum(row['model_calls'] for row in rows),
              'observed_seconds': sum(row['observed_seconds'] for row in rows)}
    missing, partial, counts = [], {}, {}
    for key in FIELDS:
        values = [row[key] for row in rows]
        missing_count = sum(row.get('missing_usage_field_call_counts', {}).get(
            key, int(row[key] is None)) for row in rows)
        if missing_count:
            output[key] = None
            missing.append(key)
            partial[key] = sum(row[key] if row[key] is not None
                               else row.get('partial_observed_usage', {}).get(key, 0)
                               for row in rows)
            counts[key] = missing_count
        else:
            output[key] = sum(values)
    output.update({'missing_usage_fields': missing,
                   'missing_usage_field_call_counts': counts,
                   'partial_observed_usage': partial,
                   'usage_totals_complete': not missing})
    return output


def replay(answer_binding, input_binding):
    body = e.read(e.verify(input_binding))
    answer = experiment.validate_answer(e.verify(answer_binding), body['supplied_sources'])
    return answer, sum(len(a['evidence']) for a in answer['answers'])


def acquired_characters(initial_input, final_input):
    before = e.read(e.verify(initial_input))['supplied_sources']
    after = e.read(e.verify(final_input))['supplied_sources']
    have = {unit['id']: unit['text'] for unit in before}
    require(len(have) == len(before), 'Duplicate initial source occurrence IDs')
    require(len({unit['id'] for unit in after}) == len(after),
            'Duplicate final source occurrence IDs')
    for unit in after:
        if unit['id'] in have:
            require(unit['text'] == have[unit['id']],
                    'An existing source occurrence was changed in a follow-up')
    return sum(len(unit['text']) for unit in after if unit['id'] not in have)


def main():
    plan = e.read(OUT / 'protocol.json')
    require(tuple(experiment.VARIANTS) == VARIANTS, 'Unexpected frozen variants')
    for binding in plan['dependencies'] + list(plan['policies'].values()) + [plan['cli_binary']]:
        e.verify(binding)
    jobs = plan['jobs']
    require(isinstance(jobs, list) and jobs, 'No frozen jobs to collect')
    require(len({job['id'] for job in jobs}) == len(jobs), 'Duplicate frozen job IDs')
    case_jobs = defaultdict(dict)
    initial_bindings, initial_results, initial_answers = {}, {}, {}
    for job in jobs:
        require(job['allocation'] in ALLOCATIONS, 'Unexpected frozen allocation')
        require(job['allocation'] not in case_jobs[job['case']],
                'Duplicate case/allocation in frozen jobs')
        case_jobs[job['case']][job['allocation']] = job
        e.verify(job['scope'])
        result_binding = e.bind(OUT / 'predictions' / (job['id'] + '.initial') / 'result.json')
        result = e.read(e.verify(result_binding))
        answer, _ = replay(result['answer'], job['input'])
        initial_bindings[job['id']] = result_binding
        initial_results[job['id']] = result
        initial_answers[job['id']] = answer
    for allocations in case_jobs.values():
        require(set(allocations) == set(ALLOCATIONS), 'A case lacks its paired allocation')

    unique_calls, unique_answers, result_costs = {}, {}, {}
    workflows, operation_bindings = [], []
    by_variant, by_allocation_variant = defaultdict(list), defaultdict(list)

    def register(binding):
        path = binding['path']
        if path in unique_calls:
            require(unique_calls[path] == binding, 'Different bindings for the same result path')
        else:
            unique_calls[path] = binding
            result_costs[path] = cost(binding)
        return result_costs[path]

    def record_answer(answer_binding, input_binding, result_binding):
        result_path = e.verify(result_binding)
        result = e.read(result_path)
        require(result['answer'] == answer_binding, 'Final answer differs from its first result')
        dispatch = e.read(result_path.parent / 'dispatch.json')
        require(dispatch['input'] == input_binding, 'Replay input differs from actual dispatch input')
        require(dispatch['policy'] in plan['policies'].values(), 'Dispatch policy is not frozen')
        answer, quotes = replay(answer_binding, input_binding)
        key = answer_binding['path']
        if key in unique_answers:
            require(unique_answers[key] == (answer_binding, input_binding),
                    'A shared answer is attributed to a different input')
        else:
            unique_answers[key] = (answer_binding, input_binding)
        return answer, quotes

    for job in jobs:
        initial_binding = initial_bindings[job['id']]
        initial_result = initial_results[job['id']]
        register(initial_binding)
        record_answer(initial_result['answer'], job['input'], initial_binding)
        op_path = OUT / 'predictions' / (job['id'] + '.operations.json')
        operation_bindings.append(e.bind(op_path))
        operations = e.read(e.verify(operation_bindings[-1]))
        require(operations['initial'] == initial_binding, 'Operations have a different initial return')
        recommendations = [a['next_action'] for a in initial_answers[job['id']]['answers']]
        require(operations['recommended_actions'] == recommendations,
                'Saved recommendations differ from the first output')
        require([op['variant'] for op in operations['operations']] == list(VARIANTS),
                'Operations do not preserve all frozen variants in order')
        followups = {op['result']['path'] for op in operations['operations']
                     if op['additional_calls'] == 1}
        require(type(operations['physical_followup_calls']) is int
                and operations['physical_followup_calls'] == len(followups),
                'Physical follow-up count differs from actual result bindings')
        intact_job = case_jobs[job['case']]['intact']
        intact_binding = initial_bindings[intact_job['id']]
        for op in operations['operations']:
            require(type(op['additional_calls']) is int and op['additional_calls'] in (0, 1),
                    'Invalid additional call count')
            require(type(op['physical_call_shared_by_identical_input']) is bool,
                    'Invalid declared physical sharing flag')
            require(isinstance(op['action'], str) and op['action'], 'Missing operation action')
            if op['variant'] == 'inventory_first':
                require(op['result'] == intact_binding and op['input'] == intact_job['input'],
                        'Inventory-first must use the actual paired intact initial dispatch')
                require(op['charged_results'] == [intact_binding] and op['additional_calls'] == 0,
                        'Inventory-first must charge exactly its one actual initial dispatch')
                require(op['action'] in ('ACQUIRE_THEN_ANSWER', 'ANSWER_WITH_SUPPLIED'),
                        'Unexpected inventory-first operation')
            elif op['additional_calls'] == 0:
                require(op['action'] == 'STOP' and op['result'] == initial_binding
                        and op['input'] == job['input'] and op['charged_results'] == [initial_binding],
                        'Stopped workflow must charge and retain its own initial dispatch')
            else:
                require(op['result'] != initial_binding
                        and op['charged_results'] == [initial_binding, op['result']],
                        'Follow-up workflow must charge its initial and actual follow-up once')
            charged = op['charged_results']
            require(len({binding['path'] for binding in charged}) == len(charged),
                    'A workflow charges a physical result more than once')
            charges = [register(binding) for binding in charged]
            final_answer, quotes = record_answer(op['answer'], op['input'], op['result'])
            acquired = acquired_characters(job['input'], op['input'])
            require(type(op['acquired_source_characters']) is int
                    and op['acquired_source_characters'] == acquired,
                    'Acquired character count differs from actual supplied sources')
            workflow_cost = sum_costs(charges)
            by_variant[op['variant']].append(workflow_cost)
            by_allocation_variant[(job['allocation'], op['variant'])].append(workflow_cost)
            workflows.append({'job': job['id'], 'case': job['case'],
                'allocation': job['allocation'], 'variant': op['variant'], 'action': op['action'],
                'initial_recommendations': recommendations, 'initial_result': initial_binding,
                'final_answer': op['answer'], 'final_result': op['result'], 'final_input': op['input'],
                'charged_results': charged, 'cost': workflow_cost,
                'additional_calls': op['additional_calls'],
                'acquired_source_characters': acquired,
                'declared_physical_call_shared_by_identical_input': op['physical_call_shared_by_identical_input'],
                'literal_quotes': quotes,
                'final_actions': [a['next_action'] for a in final_answer['answers']],
                'semantic_assessment': 'ROOT_READBACK_REQUIRED'})

    recorded_dispatches = set()
    for directory in (OUT / 'predictions').iterdir():
        if directory.is_dir():
            result_path = directory / 'result.json'
            require(result_path.exists(), 'Unfinished first dispatch: ' + str(directory))
            require(not (directory / 'schema_failure.json').exists(),
                    'Preserved first schema failure: ' + str(directory))
            recorded_dispatches.add(e.bind(result_path)['path'])
    require(recorded_dispatches == set(unique_calls),
            'Recorded physical dispatches and charged result bindings differ')
    final_shares = Counter((row['job'], row['final_result']['path']) for row in workflows)
    global_final_shares = Counter(row['final_result']['path'] for row in workflows)
    sharing_errata = []
    for row in workflows:
        actual = final_shares[(row['job'], row['final_result']['path'])] > 1
        row['actual_physical_final_result_shared'] = actual
        row['physical_final_result_workflow_uses'] = global_final_shares[row['final_result']['path']]
        if actual != row['declared_physical_call_shared_by_identical_input']:
            sharing_errata.append({'job': row['job'], 'variant': row['variant'],
                'original_flag': row['declared_physical_call_shared_by_identical_input'],
                'actual_shared_by_final_result_binding': actual, 'result': row['final_result']})
    call_bindings = [unique_calls[path] for path in sorted(unique_calls)]
    citations = sum(replay(answer, inp)[1] for answer, inp in unique_answers.values())
    output = {'state': 'ALL_FIXED_FIRST_RETURNS_COLLECTED_AND_LITERAL_REPLAYED',
        'collector': e.bind(Path(__file__).resolve()), 'protocol': e.bind(OUT / 'protocol.json'),
        'operation_bindings': operation_bindings,
        'initial_allocations': len(jobs), 'logical_policy_workflows': len(workflows),
        'physical_unique_calls': sum_costs([result_costs[b['path']] for b in call_bindings]),
        'physical_call_bindings': call_bindings,
        'physical_call_costs': [{'result': b, 'cost': result_costs[b['path']]} for b in call_bindings],
        'physical_unique_answers': len(unique_answers), 'physical_unique_literal_quotes': citations,
        'literal_defects': 0, 'semantic_accuracy_or_gold_certified': False,
        'logical_policy_cost': {v: sum_costs(by_variant[v]) for v in VARIANTS},
        'logical_allocation_policy_cost': [{'allocation': a, 'variant': v,
            'cost': sum_costs(by_allocation_variant[(a, v)])} for a in ALLOCATIONS for v in VARIANTS],
        'sharing_metadata_errata': sharing_errata, 'workflows': workflows,
        'automatic_retries': 0,
        'cost_interpretation': 'Each workflow charges its declared actual result bindings once. '
            'Answer-aware and inventory-optimized workflows include their shared initial diagnosis. '
            'Inventory-first uses and charges the paired intact initial dispatch once, including '
            'acquired-source input tokens. Physical calls are deduplicated by actual result binding. '
            'Optional unmeasured token components remain null; partial sums are explicitly marked. '
            'Observed seconds are recorded dispatch durations, not causal latency or TCO. '
            'Source preparation and author review are outside these model costs.'}
    e.save(OUT / 'completed_first_call_accounting.json', output)
    print(json.dumps({key: output[key] for key in
        ('state', 'initial_allocations', 'logical_policy_workflows', 'physical_unique_calls',
         'physical_unique_answers', 'physical_unique_literal_quotes', 'literal_defects',
         'logical_policy_cost')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
