#!/usr/bin/env python3
"""P11 first conditional answers versus two optimized inventory controls."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

import compare_followup_actions as previous

executor = previous.executor
ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
AREA = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
OUT = AREA / 'priority11-inventory-coverage-actions'
VARIANTS = ('answer_aware', 'inventory_optimized', 'inventory_first')
ALLOCATIONS = ('mixed_catalogue', 'intact')
ACTIONS = previous.ACTIONS
POLICY = previous.POLICY.replace('250 words', '400 words')

REQUESTS = {
    'spec38_321_CR2154': {
        'clauses': ['5.18.35'], 'mixed_rule': 'CR and complete target clause; base withheld',
        'mixed_roles': ['CR', 'target'], 'mixed_target_clauses': None,
        'questions': [
            'Compare TS38.321 versions19.1.0 and19.2.0 clause5.18.35. What observed wording changes concerning when the UE indicates an (Enhanced) LTM cell switch to upper layers and HARQ confirmation? Distinguish CR2154 revision1 proposed rationale from each directly observed version; does the target make waiting for HARQ mandatory or say that indication must always precede HARQ?',
            'Using the observed target19.2.0 clause5.18.35, describe the conditional procedure rather than an unconditional instruction to skip Random Access. Include which command is used under the MCG/security-ID condition, information indicated to upper layers, the upper-layer-requested MAC reset, the non-FFF Timing Advance branch, the measured-Timing-Advance alternative and its SpCell prerequisite, when SCG causes the skip indication, the SR Configuration ID/SRB1 qualification, and TCI information passed to lower layers. Keep the scope of the new timing note separate.',
            'Do the bounded sources establish official CR2154 approval, first historical introduction of the behavior, actual HARQ feedback omission by every UE, or measured latency/cell-switch failure for a particular deployment? Separate a CR interoperability prediction from a measured deployment and retain unknowns where the necessary evidence type is absent.'
        ],
        'criteria': [
            ['Base lacks this local timing note; target adds indication as soon as possible following reception.', 'The target says indication could precede HARQ confirmation, not that it always must, and does not require waiting.', 'CR rationale/proposal is distinct from observed endpoint wording.'],
            ['Enhanced command for MCG when candidate no-security-change ID differs from stored serving ID; otherwise ordinary command.', 'Indicate trigger/Target Configuration ID, adding NCC for Enhanced command.', 'MAC-reset subtree is conditional on upper-layer request.', 'Non-FFF branch processes received TA and considers RACH-less ongoing.', 'Alternative requires configured UE-based TA measurement plus successful target SpCell measurement; processes measured TA.', 'Each branch skips Random Access through an upper-layer indication only for SCG.', 'Included SR Configuration ID corresponds to the logical channel serving SRB1 during RACH-less procedure.', 'TCI state information is indicated to lower layers.', 'Timing note does not remove the conditional tree.'],
            ['Approval, exhaustive historical introduction and actual deployed HARQ/performance are unsupported.', 'CR interoperability/latency predictions are reported as proposal rationale, not measurements.']
        ],
        'anchor_needles': ['5.18.35', 'The network may instruct', 'indicate to upper layers', 'MAC reset operation', 'not set as FFF', 'successfully measured', 'SR Configuration ID', 'TCI state information'],
        'expected_mixed_actions': ['ACQUIRE', 'RETAIN', 'KEEP_UNKNOWN']
    },
    'spec38_322_CR0067': {
        'clauses': ['5.2.3.2.1'], 'mixed_rule': 'CR and complete base clause; target withheld',
        'mixed_roles': ['CR', 'base'], 'mixed_target_clauses': None,
        'questions': [
            'Compare TS38.322 versions19.1.0 and19.2.0 clause5.2.3.2.1. What changes in the receiving AM RLC operations when t-RxDiscard expires, and which state-variable/timer actions and clause reference remain? Separate CR0067 revision2 proposal from directly observed endpoint wording; is the same new action inserted into the t-Reassembly-expiry instruction?',
            'Using observed target19.2.0 clause5.2.3.2.1, state the receiving-window bounds and outside-window condition, and distinguish receiving an AMD PDU, the condition for updating/reassembling/delivering and starting/stopping timers, t-Reassembly expiry, and t-RxDiscard expiry. Preserve the conditional reception-buffer branch rather than saying every received PDU is reassembled or every timer expiry discards buffered AMD PDUs.',
            'Do these sources establish official CR0067 approval, first historical introduction, the complete operations in referenced clauses5.2.3.2.2 through5.2.3.2.5, or a deployed device interoperability measurement? Distinguish the CR statement about interoperability from measured evidence and missing full referenced clauses.'
        ],
        'criteria': [
            ['Target adds discard the corresponding AMD PDU(s) in the reception buffer when t-RxDiscard expires.', 'Update state variables and start t-RxDiscard as needed, with reference5.2.3.2.5, remain.', 't-Reassembly-expiry instruction still updates state variables/starts t-Reassembly with reference5.2.3.2.4; the new discard is not copied there.', 'CR proposal and observed versions remain separate.'],
            ['Window is RX_Next <= SN < RX_Next + AM_Window_Size; outside otherwise.', 'Received AMD PDU may be discarded or placed in reception buffer.', 'Only if placed in buffer, update/reassemble/deliver and start/stop t-Reassembly/t-RxDiscard as needed.', 't-Reassembly expiry updates state/start that timer as needed.', 't-RxDiscard expiry discards corresponding buffered AMD PDUs then updates state/start that timer as needed.', 'No unconditional discard/reassembly generalization.'],
            ['Approval, first historical introduction, complete referenced-clause internals and measured device interoperability are unavailable.', 'CR states no interoperability issue; that is not an observed device measurement.']
        ],
        'anchor_needles': ['RX_Next', 'When receiving an AMD', 'placed in the reception buffer', 'update state variables', 'When t-Reassembly', 'When t-RxDiscard', 'discard the corresponding AMD'],
        'expected_mixed_actions': ['ACQUIRE', 'ACQUIRE', 'KEEP_UNKNOWN']
    },
    'spec38_323_CR0151': {
        'clauses': ['3.1', '4.2.2', '5.16.1'],
        'mixed_rule': 'CR plus all complete base clauses and complete target3.1; target4.2.2/5.16.1 withheld',
        'mixed_roles': ['CR', 'base', 'target'], 'mixed_target_clauses': ['3.1'],
        'questions': [
            'Compare TS38.323 versions19.0.0 and19.1.0 clauses3.1,4.2.2,5.16.1 for CR0151 revision1. Identify the observed non-delay-reporting definition edit, the newly observed re-establishment note and its bearer/implementation qualification. Distinguish the CR claim of correcting Duplicte discarding in Figures4.2.2-1/-2 from what the supplied observed-version projection actually exposes; do captions and prose establish the embedded figure-label correction?',
            'Using observed target19.1.0 clause5.16.1, distinguish ordinary PDCP SN gap reporting from the new re-establishment note. Preserve UM/AM and upper-layer configuration scope, all three conjunctive triggering conditions, FDC COUNT selection, the condition for allocating a bitmap, its next-multiple-of8 and9000-byte bounds and1/0 mapping, lower-layer submission, implementation choice about reporting frequency, and the AM-only optional re-send on an upper-layer re-establishment request. Does the new note mandate re-send for all UM and AM DRBs?',
            'Do these sources establish official CR0151 approval, first historical introduction, an official agreement transcript behind the CR phrase It is agreed, measured XR performance or particular-device compliance? Distinguish the submitted assertion, observed wording and missing authority/history/device evidence.'
        ],
        'criteria': [
            ['The definition gains i:th before DSR-ReportingThreshold; preceding/excluding the same i:th reporting SDUs remains.', 'Target5.16.1 adds NOTE2 for AM DRBs: implementation decides whether to re-send on upper-layer re-establishment.', 'CR states figure-label typo correction, but supplied endpoint captions/prose do not expose those embedded labels; actual label correction remains unverified.', 'Do not promote CR proposed/summary text to a directly observed figure label.'],
            ['Ordinary report applies to upper-layer-configured UM/AM DRBs.', 'Trigger conjuncts: SDUs discarded under5.3; stored SDU has greater COUNT; discarded SDUs not submitted by any RLC entity to lower layers.', 'FDC is smallest discarded COUNT.', 'Bitmap only if more than one discarded; COUNT range after first through last, rounded to next8 or9000-byte PDU cap whichever first.', 'Bitmap1 for these discarded SDUs and0 for all other SDUs.', 'Submit to lower layers as5.2.1 for Uu; full external clause is not supplied.', 'NOTE1 leaves reporting frequency to UE implementation.', 'NOTE2 is AM-only, upper-layer re-establishment, optional implementation decision; no all-UM/all-AM mandatory resend.'],
            ['Approval, exhaustive first introduction, agreement transcript and measured/device conclusions remain unknown.', 'CR It is agreed is a submitted assertion rather than the official agreement record.']
        ],
        'anchor_needles': ['Non-delay-reporting PDCP SDU:', 'Figure 4.2.2-', 'For UM DRBs and AM DRBs', 'PDCP SDU(s) are discarded', 'at least one stored', 'not been submitted', 'FDC field', 'Discard Bitmap field', 'discard bitmap field', 'submit the PDCP SN gap', 'up to UE implementation'],
        'expected_mixed_actions': ['ACQUIRE', 'ACQUIRE', 'KEEP_UNKNOWN']
    }
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def model_units(units):
    return previous.model_units(units)


def validate_answer(path, input_units):
    answer = executor.read(path)
    require(isinstance(answer, dict) and isinstance(answer.get('answers'), list), 'Malformed first JSON')
    require([a.get('id') for a in answer['answers']] == ['Q1', 'Q2', 'Q3'], 'Wrong question IDs in first output')
    sources = {u['id']: u['text'] for u in input_units}
    for a in answer['answers']:
        require(isinstance(a.get('answer'), str) and a['answer'].strip(), 'Empty answer')
        require(len(a['answer'].split()) <= 400, 'Preserve first answer exceeding frozen word allowance')
        require(a.get('next_action') in ACTIONS and isinstance(a.get('action_reason'), str), 'Invalid action schema')
        for key in ('established_facts', 'missing_information'):
            require(isinstance(a.get(key), list) and all(isinstance(v, str) for v in a[key]), 'Invalid fact/missing schema')
        require(isinstance(a.get('evidence'), list), 'Invalid evidence schema')
        for quote in a['evidence']:
            require(isinstance(quote, dict) and quote.get('source_id') in sources and
                    isinstance(quote.get('quote'), str) and quote['quote'] and
                    quote['quote'] in sources[quote['source_id']], 'Literal quotation defect in first output')
    return answer


def prepare():
    executor.guarded()
    selected = executor.read(OUT / 'selection.json')
    require([c['id'] for c in selected['cases']] == list(REQUESTS), 'Population substitution')
    require(not (OUT / 'predictions').exists(), 'Outputs already exist')
    (OUT / 'inputs').mkdir()
    executor.text_new(OUT / 'answer_and_action_policy.txt', POLICY)
    jobs, references, sources = [], [], []
    for c in selected['cases']:
        directory = executor.verify(c['selection']).parent
        prepared = executor.read(directory / 'source_preparation.json')
        pool = executor.read(executor.verify(prepared['pool']))
        request = REQUESTS[c['id']]
        units = [u for u in pool['units'] if u['role'] == 'CR' and u['clause'] is None or u['clause'] in request['clauses']]
        require(all(any(u['role'] == role for u in units) for role in ('CR', 'base', 'target')), 'Missing role')
        scope = directory / 'sources/action_scope.json'
        executor.save(scope, {'units': units, 'parent_pool': prepared['pool'], 'clauses': request['clauses'],
            'mixed_roles': request['mixed_roles'], 'mixed_target_clauses': request['mixed_target_clauses'],
            'rule': 'Complete CR cover plus complete declared question clauses, without output/reference-ID selection or paragraph truncation.',
            'native_rendering_certified': False})
        inventory = {k: pool['inventory'][k] for k in ('specification', 'submitted_CR', 'wg_tdoc', 'tsg_copy',
            'tsg_copy_is_byte_identical', 'absent_evidence_types', 'projection_scope')}
        inventory['available_catalogue'] = [{k: u[k] for k in ('id', 'role', 'version', 'clause')} for u in units]
        inventory['source_scope'] = 'Complete supplied clause projections plus CR; outside clauses/history/authority/device data and native embedded-figure rendering are unavailable.'
        inventory['absent_evidence_types'] = list(inventory['absent_evidence_types']) + ['native embedded figure-label images/rendering']
        questions = [{'id': 'Q' + str(i+1), 'request': q} for i, q in enumerate(request['questions'])]
        for allocation in ALLOCATIONS:
            actual = units if allocation == 'intact' else [u for u in units if
                u['role'] in request['mixed_roles'] and
                (u['role'] != 'target' or request['mixed_target_clauses'] is None or u['clause'] in request['mixed_target_clauses'])]
            body = {'questions': questions, 'source_inventory': inventory, 'supplied_sources': model_units(actual), 'phase': 'initial'}
            path = OUT / 'inputs' / (c['id'] + '.' + allocation + '.initial.json')
            executor.save(path, body)
            jobs.append({'id': c['id'] + '.' + allocation, 'case': c['id'], 'allocation': allocation,
                'input': executor.bind(path), 'scope': executor.bind(scope), 'source_characters': sum(len(u['text']) for u in actual),
                'available_source_characters': sum(len(u['text']) for u in units), 'source_occurrences': len(actual)})
        anchors = [{'source_id': u['id'], 'role': u['role'], 'quote': u['text']} for u in units
                   if u['role'] in ('base', 'target') and any(n in u['text'] for n in request['anchor_needles'])]
        require(anchors, 'No source anchors')
        references.append({'case': c['id'], 'questions': questions, 'criteria': request['criteria'], 'anchors': anchors,
            'expected_mixed_actions': request['expected_mixed_actions'], 'expected_intact_actions': ['RETAIN', 'RETAIN', 'KEEP_UNKNOWN'],
            'scope': 'Supported content and justified unknowns, not proof of native figure labels or official agreement.'})
        sources += [executor.bind(directory / 'source_preparation.json'), prepared['pool'], executor.bind(scope)]
    executor.save(OUT / 'author_reference.json', {'state': 'ROOT_REFERENCE_FROZEN_BEFORE_P11_OUTPUTS',
        'created_utc': executor.now(), 'cases': references, 'root_source_readback': executor.bind(OUT / 'root_source_readback.json'),
        'reference_not_supplied_to_models': True, 'expert_gold': False, 'population_accuracy_certified': False})
    p10 = executor.read(AREA / 'priority10-followup-action-utility/protocol.json')
    cli = executor.verify(p10['cli_binary'])
    login = subprocess.run([str(cli), 'login', 'status'], capture_output=True, text=True, timeout=30)
    require(login.returncode == 0 and 'ChatGPT' in login.stdout + login.stderr, 'Logged-in authorized CLI required')
    producers = [Path(__file__), Path(__file__).with_name('admit_inventory_coverage_dispatch.py'),
                 Path(__file__).with_name('collect_inventory_coverage_actions.py'), Path(executor.__file__),
                 Path(previous.__file__), Path(executor.collector.__file__),
                 Path(__file__).with_name('admit_verified_followup_dispatch.py')]
    dependencies = [executor.bind(OUT / n) for n in ('selection.json', 'strategy_adoption.json',
        'dependency_audit.json', 'root_source_readback.json', 'author_reference.json')] + sources + [executor.bind(f) for f in producers]
    executor.save(OUT / 'protocol.json', {'state': 'FROZEN_BEFORE_FIRST_P11_ANSWER', 'created_utc': executor.now(),
        'producer': executor.bind(Path(__file__)), 'dependencies': dependencies, 'cli_binary': p10['cli_binary'],
        'config_overrides': p10['config_overrides'], 'sampling': p10['sampling'], 'policies': {'answer': executor.bind(OUT / 'answer_and_action_policy.txt')},
        'jobs': jobs, 'variants': VARIANTS, 'allocations': ALLOCATIONS,
        'shared_initial': 'Answer-aware and inventory-optimized share the identical first answer/diagnosis and charge it to each workflow. Inventory-first acquires available missing units before answering and shares the exactly identical intact.initial return; it charges that one return only.',
        'answer_aware': 'Use first recommendations: any ACQUIRE -> supply every remaining unit in bounded question scope; else any ASK -> reconsider supplied text; otherwise STOP. No author override.',
        'inventory_optimized': 'From catalogue metadata IDs only: if any available scoped unit is not supplied, acquire all missing units and answer once more; else STOP. It never reads answer contents to route.',
        'inventory_first': 'Before answering, supply all remaining question-scoped available units from the identical catalogue. Its effective policy/config/body equals intact.initial, verified byte-content equality before sharing. Charge one actual answer, no partial-input initial or unmeasured lean prompt.',
        'identical_input_sharing': 'Canonical effective body plus policy binding plus config/CLI bindings. Actual result paths determine sharing, not action-name equality. Shared returns are dependent.',
        'same_per_question_answer_allowance_words': 400, 'per_turn_wall_limit_seconds': 900,
        'source_volume_limit': max(j['available_source_characters'] for j in jobs),
        'source_volume_reason': 'Maximum complete frozen question-scope text; no outcome-selected trimming.',
        'controlled_source_allocations': {c: r['mixed_rule'] for c, r in REQUESTS.items()},
        'allocation_boundary': 'Deliberate whole-role/whole-clause source withholding, not natural retrieval failure, answer truncation or failure-selected samples.',
        'action_limit': 'At most one post-initial follow-up; inventory-first acquires before its only answer.',
        'failure': 'First incomplete/uncontrolled/schema/literal failure is preserved and blocks subsequent dispatch. One attempt, zero retries.',
        'cost': 'Unique physical calls and charged logical workflows separately; all first answering/diagnosis charged where used. Source preparation, acquisition I/O and author review outside model cost; no causal latency/TCO.',
        'claim_scope': 'Three metadata-selected new-spec development cases with package/reference dependency limits; no independent gold, firstness, population/general policy superiority or forced ASK.',
        'protected_email_family_bodies_opened': 0})
    print(json.dumps({'state': 'P11_PROTOCOL_FROZEN', 'initial_jobs': len(jobs), 'variants': VARIANTS,
        'source_characters': {j['case']: j['available_source_characters'] for j in jobs}, 'model_calls': 0}))


def plan_verified():
    executor.guarded()
    plan = executor.read(OUT / 'protocol.json')
    for b in plan['dependencies'] + list(plan['policies'].values()) + [plan['cli_binary']]:
        executor.verify(b)
    executor.OUT = OUT
    (OUT / 'predictions').mkdir(exist_ok=True)
    return plan


def checked_turn(plan, destination, binding):
    body = executor.read(executor.verify(binding))
    path = executor.turn(plan, destination, binding, 'answer')
    try:
        answer = validate_answer(path, body['supplied_sources'])
    except Exception as error:
        executor.save(destination / 'schema_failure.json', {'state': 'PRESERVED_FIRST_SCHEMA_OR_LITERAL_FAILURE', 'error': repr(error), 'retries': 0})
        raise
    executor.save(destination / 'mechanical_check.json', {'state': 'JSON_AND_LITERAL_REPLAY_PASS',
        'answer': executor.bind(path), 'actions': [a['next_action'] for a in answer['answers']], 'semantic_assessment': 'NOT_PERFORMED'})
    return path


def run_initial(case_id):
    plan = plan_verified()
    for job in [j for j in plan['jobs'] if j['case'] == case_id]:
        checked_turn(plan, OUT / 'predictions' / (job['id'] + '.initial'), job['input'])


def effective_key(plan, body):
    return hashlib.sha256(json.dumps({'body': body, 'policy': plan['policies']['answer'],
        'config': plan['config_overrides'], 'cli': plan['cli_binary']}, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def run_followups(case_id):
    plan = plan_verified()
    full_job = next(j for j in plan['jobs'] if j['case'] == case_id and j['allocation'] == 'intact')
    full_body = executor.read(executor.verify(full_job['input']))
    full_result_path = OUT / 'predictions' / (full_job['id'] + '.initial/result.json')
    full_binding = executor.bind(full_result_path)
    full_result = executor.read(full_result_path)
    require(full_result['state'] == 'SAVED_CONTROLLED_ANSWER', 'Intact first return required')
    for job in [j for j in plan['jobs'] if j['case'] == case_id]:
        result_path = OUT / 'predictions' / (job['id'] + '.initial/result.json')
        initial_binding = executor.bind(result_path)
        result = executor.read(result_path)
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER', 'Preserve failed first return')
        body = executor.read(executor.verify(job['input']))
        answer = validate_answer(executor.verify(result['answer']), body['supplied_sources'])
        all_units = model_units(executor.read(executor.verify(job['scope']))['units'])
        have = {u['id'] for u in body['supplied_sources']}
        missing_metadata_ids = {u['id'] for u in body['source_inventory']['available_catalogue']} - have
        acquired = sum(len(u['text']) for u in all_units if u['id'] not in have)
        actions = [a['next_action'] for a in answer['answers']]
        routes = {'answer_aware': 'ACQUIRE' if 'ACQUIRE' in actions else 'ASK' if 'ASK' in actions else 'STOP',
                  'inventory_optimized': 'ACQUIRE' if missing_metadata_ids else 'STOP'}
        operations, dispatched = [], {}
        for variant in VARIANTS:
            if variant == 'inventory_first':
                first_body = {**body, 'supplied_sources': all_units}
                require(effective_key(plan, first_body) == effective_key(plan, full_body), 'Inventory-first reuse is not identical')
                operations.append({'variant': variant, 'action': 'ACQUIRE_THEN_ANSWER' if missing_metadata_ids else 'ANSWER_WITH_SUPPLIED',
                    'answer': full_result['answer'], 'result': full_binding, 'input': full_job['input'],
                    'charged_results': [full_binding], 'additional_calls': 0, 'acquired_source_characters': acquired})
                continue
            action = routes[variant]
            if action == 'STOP':
                operations.append({'variant': variant, 'action': action, 'answer': result['answer'],
                    'result': initial_binding, 'input': job['input'], 'charged_results': [initial_binding],
                    'additional_calls': 0, 'acquired_source_characters': 0})
                continue
            actual = all_units if action == 'ACQUIRE' else body['supplied_sources']
            follow = {**body, 'supplied_sources': actual, 'phase': 'follow-up', 'prior_answer': answer,
                'instruction': 'Reassess the same explicit Q1,Q2,Q3 against supplied sources; preserve supported conditions and correct missing detail or scope promotion. Prior answer is not evidence.'}
            key = effective_key(plan, follow)
            if key not in dispatched:
                path = OUT / 'inputs' / (job['id'] + '.' + action.lower() + '.followup.json')
                executor.save(path, follow)
                destination = OUT / 'predictions' / (job['id'] + '.' + action.lower() + '.followup')
                output = checked_turn(plan, destination, executor.bind(path))
                dispatched[key] = {'answer': executor.bind(output), 'result': executor.bind(destination / 'result.json'), 'input': executor.bind(path)}
            operations.append({'variant': variant, 'action': action, **dispatched[key],
                'charged_results': [initial_binding, dispatched[key]['result']], 'additional_calls': 1,
                'acquired_source_characters': acquired if action == 'ACQUIRE' else 0})
        counts = Counter(o['result']['path'] for o in operations)
        for o in operations:
            o['physical_call_shared_by_identical_input'] = counts[o['result']['path']] > 1
        executor.save(OUT / 'predictions' / (job['id'] + '.operations.json'), {
            'state': 'FROZEN_ANSWER_AND_METADATA_ROUTES_APPLIED_NO_AUTHOR_OVERRIDE',
            'initial': initial_binding, 'recommended_actions': actions, 'inventory_missing_source_ids': sorted(missing_metadata_ids),
            'operations': operations, 'physical_followup_calls': len(dispatched), 'retries': 0})


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('prepare', 'initial', 'followups'))
    parser.add_argument('--case', choices=tuple(REQUESTS))
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        require(args.case is not None, 'Case required')
        (run_initial if args.action == 'initial' else run_followups)(args.case)
