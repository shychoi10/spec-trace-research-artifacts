#!/usr/bin/env python3
"""Use the unchanged first-failure admission checker with explicit P11 bindings."""
import argparse
from pathlib import Path

import admit_verified_followup_dispatch as admission
import compare_inventory_coverage_actions as experiment


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('initial', 'followups'))
    parser.add_argument('--case', required=True, choices=tuple(experiment.REQUESTS))
    args = parser.parse_args()
    admission.experiment = experiment
    original = experiment.executor.turn

    def turn(plan, destination, binding, policy_name):
        history = admission.check_history(destination)
        folder = experiment.OUT / 'dispatch_admissions'
        folder.mkdir(exist_ok=True)
        stamp = experiment.executor.now().replace(':', '').replace('+', '_')
        experiment.executor.save(folder / (stamp + '.json'), {
            'state': 'P11_NO_PRIOR_INCOMPLETE_UNCONTROLLED_OR_SCHEMA_FAILURE',
            'producer': experiment.executor.bind(Path(experiment.__file__)),
            'admission_wrapper': experiment.executor.bind(Path(__file__)),
            'inherited_admission': experiment.executor.bind(Path(admission.__file__)),
            'protocol': experiment.executor.bind(experiment.OUT / 'protocol.json'),
            'prior_results': history, 'next_input': binding,
            'next_destination': str(destination.relative_to(experiment.ROOT)),
            'scientific_inputs_or_policy_modified': False, 'retry_authorized': False})
        return original(plan, destination, binding, policy_name)

    experiment.executor.turn = turn
    (experiment.run_initial if args.action == 'initial' else experiment.run_followups)(args.case)


if __name__ == '__main__':
    main()
