#!/usr/bin/env python3
"""Replay distributed P11 allocations, routes, first returns and charged costs.

Standard-library verification reads saved package artifacts and never performs
inference. It does not interpret answers, rerender Word, certify expert gold,
reinspect the host CLI executable or establish absence of unrecorded executions.
"""
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
import verify_source_decision_resource as provenance


require, read, digest = provenance.require, provenance.read, provenance.digest
VARIANTS = ('answer_aware', 'inventory_optimized', 'inventory_first')
ALLOCATIONS = ('mixed_catalogue', 'intact')
ACTIONS = ('ACQUIRE', 'ASK', 'RETAIN', 'KEEP_UNKNOWN')
FIELDS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens',
          'output_tokens', 'reasoning_output_tokens')
MANDATORY_USAGE = ('input_tokens', 'output_tokens')
FOLLOWUP_INSTRUCTION = ('Reassess the same explicit Q1,Q2,Q3 against supplied sources; '
                        'preserve supported conditions and correct missing detail or scope promotion. '
                        'Prior answer is not evidence.')


def inspect_events(path, answer_path):
    """Retain the provenance helper's event checks with optional usage missingness."""
    lines = path.read_text(encoding='utf-8').splitlines()
    require(bool(lines) and all(line.strip() for line in lines), 'Empty raw event record')
    events = [provenance.loads(line) for line in lines]
    warnings, unexpected, errors, completed, messages = [], [], [], [], []
    for event in events:
        require(isinstance(event, dict) and isinstance(event.get('type'), str), 'Invalid raw event')
        kind = event['type']
        if kind in ('error', 'turn.failed'):
            errors.append(event)
        elif kind == 'turn.completed':
            completed.append(event)
        elif kind in ('thread.started', 'turn.started'):
            continue
        elif kind in ('item.started', 'item.updated', 'item.completed'):
            item = event.get('item')
            require(isinstance(item, dict), 'Invalid item event')
            if item.get('type') in ('agent_message', 'reasoning'):
                if kind == 'item.completed' and item['type'] == 'agent_message':
                    messages.append(item)
            elif (item.get('type') == 'error' and isinstance(item.get('message'), str)
                  and item['message'].startswith(provenance.WARNING_PREFIXES)):
                warnings.append(event)
            else:
                unexpected.append(event)
        else:
            unexpected.append(event)
    require(not errors and not unexpected, 'Raw events contain errors, tools or unknown events')
    require(len(completed) == 1, 'Expected exactly one completed first turn')
    require(len(messages) == 1 and isinstance(messages[0].get('text'), str),
            'Expected exactly one completed assistant message')
    require(messages[0]['text'].encode('utf-8') == answer_path.read_bytes(),
            'Completed assistant message differs from saved answer bytes')
    usage = completed[0].get('usage')
    require(isinstance(usage, dict), 'Missing completed usage object')
    require(all(type(usage.get(key)) is int and usage[key] >= 0 for key in MANDATORY_USAGE),
            'Missing or invalid mandatory completed usage')
    require(all(value is None or (type(value) is int and value >= 0)
                for value in usage.values()), 'Invalid completed usage count')
    return {'event_count': len(events), 'startup_warnings': warnings,
            'unexpected_tool_or_item_events': unexpected, 'turn_completed_events': completed,
            'errors': errors}


def measured_cost(usage, elapsed):
    require(type(elapsed) in (int, float) and math.isfinite(elapsed) and elapsed >= 0,
            'Invalid observed elapsed seconds')
    measured, missing = {}, []
    for key in FIELDS:
        value = usage.get(key)
        if value is None:
            require(key not in MANDATORY_USAGE, 'Missing mandatory measured usage: ' + key)
            measured[key] = None
            missing.append(key)
        else:
            require(type(value) is int and value >= 0, 'Invalid measured usage: ' + key)
            measured[key] = value
    return {'model_calls': 1, **measured, 'observed_seconds': elapsed,
            'missing_usage_fields': missing, 'usage_totals_complete': not missing}


def sum_costs(rows):
    output = {'model_calls': sum(row['model_calls'] for row in rows),
              'observed_seconds': sum(row['observed_seconds'] for row in rows)}
    missing, partial, counts = [], {}, {}
    for key in FIELDS:
        missing_count = sum(row.get('missing_usage_field_call_counts', {}).get(
            key, int(row[key] is None)) for row in rows)
        if missing_count:
            output[key] = None
            missing.append(key)
            partial[key] = sum(row[key] if row[key] is not None
                               else row.get('partial_observed_usage', {}).get(key, 0)
                               for row in rows)
            counts[key] = missing_count
        else:
            output[key] = sum(row[key] for row in rows)
    output.update({'missing_usage_fields': missing,
                   'missing_usage_field_call_counts': counts,
                   'partial_observed_usage': partial,
                   'usage_totals_complete': not missing})
    return output


def effective_key(plan, body):
    value = {'body': body, 'policy': plan['policies']['answer'],
             'config': plan['config_overrides'], 'cli': plan['cli_binary']}
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def verify(package):
    package = Path(package).resolve()
    manifest = read(package / 'manifest.json')
    require(isinstance(manifest.get('files'), list), 'Missing manifest file list')
    listed = set()
    for record in manifest['files']:
        require(isinstance(record, dict) and isinstance(record.get('path'), str),
                'Invalid manifest record')
        require(record['path'] not in listed and record['path'] != 'manifest.json',
                'Duplicate or recursive manifest member')
        listed.add(record['path'])
        path = provenance.safe_path(package, record['path'])
        require(digest(path) == provenance._hash_fields(record), 'Manifest mismatch: ' + record['path'])
    actual = {str(path.relative_to(package)) for path in package.rglob('*') if path.is_file()}
    require(actual == listed | {'manifest.json'}, 'Unlisted or missing package member')
    locators = read(package / 'source_locators.json')
    require(isinstance(locators, dict), 'Invalid source locator mapping')
    for original, member in locators.items():
        require(isinstance(original, str) and bool(original) and member in listed,
                'Locator is not a manifested package member')
        provenance.safe_path(package, member)

    def bound(binding):
        hashes = provenance._hash_fields(binding)
        require(isinstance(binding.get('path'), str) and binding['path'] in locators,
                'Missing distributed artifact binding')
        path = provenance.safe_path(package, locators[binding['path']])
        require(digest(path) == hashes, 'Bound artifact mismatch: ' + binding['path'])
        return path

    def locator_for(member):
        matches = [original for original, mapped in locators.items() if mapped == member]
        require(len(matches) == 1, 'Missing or ambiguous original locator: ' + member)
        return matches[0]

    def check_answer(binding, body):
        answer = read(bound(binding))
        require(isinstance(answer, dict) and isinstance(answer.get('answers'), list),
                'Malformed first answer JSON')
        require(all(isinstance(item, dict) for item in answer['answers']), 'Invalid answer record')
        require([item.get('id') for item in answer['answers']] == ['Q1', 'Q2', 'Q3'],
                'Answer IDs/order differ')
        sources = {unit['id']: unit['text'] for unit in body['supplied_sources']}
        require(len(sources) == len(body['supplied_sources']), 'Duplicate supplied source IDs')
        quotes = 0
        for item in answer['answers']:
            require(isinstance(item.get('answer'), str) and bool(item['answer'].strip())
                    and len(item['answer'].split()) <= 400, 'Empty or oversized first answer')
            require(item.get('next_action') in ACTIONS and isinstance(item.get('action_reason'), str),
                    'Invalid first action schema')
            for field in ('established_facts', 'missing_information'):
                require(isinstance(item.get(field), list)
                        and all(isinstance(value, str) for value in item[field]), 'Invalid answer list field')
            require(isinstance(item.get('evidence'), list), 'Invalid evidence list')
            for citation in item['evidence']:
                require(isinstance(citation, dict) and citation.get('source_id') in sources
                        and isinstance(citation.get('quote'), str) and bool(citation['quote'])
                        and citation['quote'] in sources[citation['source_id']], 'Literal quote defect')
                quotes += 1
        return answer, quotes

    plan = read(package / 'protocol.json')
    require(tuple(plan['variants']) == VARIANTS, 'Frozen variants differ')
    for binding in plan['dependencies'] + list(plan['policies'].values()):
        bound(binding)
    provenance._hash_fields(plan['cli_binary'])
    require(isinstance(plan['cli_binary'].get('path'), str) and bool(plan['cli_binary']['path']),
            'Missing recorded CLI binding metadata')
    jobs = plan['jobs']
    require(isinstance(jobs, list) and bool(jobs), 'No frozen jobs')
    require(len({job['id'] for job in jobs}) == len(jobs), 'Duplicate frozen job IDs')
    accounting = read(package / 'completed_first_call_accounting.json')
    require(accounting['protocol'] == {'path': locator_for('protocol.json'),
                                     **digest(package / 'protocol.json')}, 'Accounting protocol differs')
    bound(accounting['collector'])
    all_calls, all_answers, job_data, paired = {}, {}, {}, defaultdict(dict)
    operation_bindings = []

    def inspect_call(binding, input_binding):
        identifier = binding['path']
        if identifier in all_calls:
            previous = all_calls[identifier]
            require(previous['binding'] == binding and previous['input'] == input_binding,
                    'A shared physical result is assigned different binding/input provenance')
            return previous['result'], previous['cost']
        result_path = bound(binding)
        result = read(result_path)
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER' and type(result['returncode']) is int
                and result['returncode'] == 0 and result['timed_out'] is False,
                'Incomplete or uncontrolled first turn')
        audit = inspect_events(bound(result['events']), bound(result['answer']))
        bound(result['stderr'])
        for key, value in audit.items():
            require(result[key] == value, 'Saved result differs from raw event provenance: ' + key)
        dispatch_path = result_path.parent / 'dispatch.json'
        require(str(dispatch_path.relative_to(package)) in listed, 'Unmanifested dispatch record')
        dispatch = read(dispatch_path)
        provenance.inspect_dispatch(dispatch, plan, {'input': input_binding},
                                    plan['policies']['answer'], result['answer'])
        require(provenance._time(result['finished_utc']) >= provenance._time(dispatch['started_utc']),
                'Recorded finish precedes dispatch')
        charge = measured_cost(audit['turn_completed_events'][0]['usage'], result['elapsed_seconds'])
        all_calls[identifier] = {'binding': binding, 'input': input_binding,
                                 'result': result, 'cost': charge}
        return result, charge

    def record_answer(binding, body):
        answer, quotes = check_answer(binding, body)
        identifier = binding['path']
        if identifier in all_answers:
            require(all_answers[identifier] == (binding, body),
                    'A shared answer is assigned different replay information')
        else:
            all_answers[identifier] = (binding, body)
        return answer, quotes

    for job in jobs:
        require(job['allocation'] in ALLOCATIONS, 'Unknown allocation')
        require(job['allocation'] not in paired[job['case']], 'Duplicate case/allocation')
        paired[job['case']][job['allocation']] = job
        body = read(bound(job['input']))
        require(set(body) == {'questions', 'source_inventory', 'supplied_sources', 'phase'},
                'Undeclared initial input field')
        require(body['phase'] == 'initial' and [q['id'] for q in body['questions']] == ['Q1', 'Q2', 'Q3'],
                'Initial phase/question IDs differ')
        scope = read(bound(job['scope']))
        require(isinstance(scope['clauses'], list) and bool(scope['clauses'])
                and all(isinstance(clause, str) for clause in scope['clauses']), 'Invalid scoped clauses')
        require(isinstance(scope['mixed_roles'], list)
                and all(isinstance(role, str) for role in scope['mixed_roles']), 'Invalid mixed source roles')
        target_clauses = scope['mixed_target_clauses']
        require(target_clauses is None or (isinstance(target_clauses, list)
                and all(isinstance(clause, str) for clause in target_clauses)), 'Invalid mixed target clauses')
        pool = read(bound(scope['parent_pool']))
        expected_scope = [unit for unit in pool['units']
                          if (unit['role'] == 'CR' and unit['clause'] is None)
                          or unit['clause'] in scope['clauses']]
        require(scope['units'] == expected_scope, 'Complete scoped source projection differs')
        full = [{key: unit[key] for key in ('id', 'role', 'version', 'clause', 'text')}
                for unit in expected_scope]
        require(full and all(isinstance(unit['id'], str) and unit['id']
                and isinstance(unit['text'], str) for unit in full), 'Invalid full source projection')
        require(len({unit['id'] for unit in full}) == len(full), 'Duplicate full source IDs')
        mixed = [unit for unit in full if unit['role'] in scope['mixed_roles']
                 and (unit['role'] != 'target' or target_clauses is None
                      or unit['clause'] in target_clauses)]
        supplied = full if job['allocation'] == 'intact' else mixed
        require(body['supplied_sources'] == supplied, 'Initial source allocation differs')
        catalogue = [{key: unit[key] for key in ('id', 'role', 'version', 'clause')} for unit in full]
        require(body['source_inventory']['available_catalogue'] == catalogue, 'Available catalogue differs')
        for key, value in (('source_characters', sum(len(unit['text']) for unit in supplied)),
                           ('available_source_characters', sum(len(unit['text']) for unit in full)),
                           ('source_occurrences', len(supplied))):
            if key in job:
                require(type(job[key]) is int and job[key] == value, 'Job source-volume metadata differs: ' + key)
        op_locators = [original for original in locators
                       if original.endswith('/predictions/' + job['id'] + '.operations.json')]
        require(len(op_locators) == 1, 'Missing or ambiguous saved operations')
        op_path = provenance.safe_path(package, locators[op_locators[0]])
        operation_bindings.append({'path': op_locators[0], **digest(op_path)})
        operations = read(op_path)
        initial_binding = operations['initial']
        require(initial_binding['path'].endswith('/predictions/' + job['id'] + '.initial/result.json'),
                'Initial result belongs to a different frozen job')
        result, charge = inspect_call(initial_binding, job['input'])
        answer, _ = record_answer(result['answer'], body)
        job_data[job['id']] = {'body': body, 'scope': scope, 'full': full, 'supplied': supplied,
                               'operations': operations, 'initial': initial_binding,
                               'initial_result': result, 'initial_cost': charge, 'initial_answer': answer}
    for allocations in paired.values():
        require(set(allocations) == set(ALLOCATIONS), 'Case lacks a paired allocation')
        require(allocations['mixed_catalogue']['scope'] == allocations['intact']['scope'],
                'Paired allocations have different scoped sources')

    workflows, sharing_errata = [], []
    by_variant, by_allocation_variant = defaultdict(list), defaultdict(list)
    for job in jobs:
        data = job_data[job['id']]
        body, full, supplied = data['body'], data['full'], data['supplied']
        operations = data['operations']
        first_answer, first_binding = data['initial_answer'], data['initial']
        actions = [item['next_action'] for item in first_answer['answers']]
        require(operations['recommended_actions'] == actions, 'Recommendations differ from first answer')
        require([op['variant'] for op in operations['operations']] == list(VARIANTS), 'Variant order differs')
        have = {unit['id'] for unit in supplied}
        missing = {unit['id'] for unit in body['source_inventory']['available_catalogue']} - have
        if 'inventory_missing_source_ids' in operations:
            require(operations['inventory_missing_source_ids'] == sorted(missing), 'Saved missing source IDs differ')
        routes = {'answer_aware': 'ACQUIRE' if 'ACQUIRE' in actions else 'ASK' if 'ASK' in actions else 'STOP',
                  'inventory_optimized': 'ACQUIRE' if missing else 'STOP'}
        intact_job = paired[job['case']]['intact']
        intact = job_data[intact_job['id']]
        require(effective_key(plan, {**body, 'supplied_sources': full})
                == effective_key(plan, intact['body']), 'Inventory-first reuse changes effective initial input')
        acquired = sum(len(unit['text']) for unit in full if unit['id'] not in have)
        shares = Counter(op['result']['path'] for op in operations['operations'])
        physical_followups, by_effective_input = set(), {}
        for op in operations['operations']:
            require(type(op['additional_calls']) is int and op['additional_calls'] in (0, 1),
                    'Invalid additional call count')
            require(type(op['physical_call_shared_by_identical_input']) is bool, 'Invalid sharing flag')
            if op['variant'] == 'inventory_first':
                expected_action = 'ACQUIRE_THEN_ANSWER' if missing else 'ANSWER_WITH_SUPPLIED'
                require(op['action'] == expected_action and op['additional_calls'] == 0,
                        'Inventory-first route differs')
                require(op['result'] == intact['initial'] and op['input'] == intact_job['input']
                        and op['answer'] == intact['initial_result']['answer'],
                        'Inventory-first does not reuse the actual paired intact initial return')
                expected_charges = [intact['initial']]
                final_body, expected_acquired = intact['body'], acquired
            else:
                require(op['action'] == routes[op['variant']], 'Frozen recommendation/inventory route differs')
                if op['action'] == 'STOP':
                    require(op['additional_calls'] == 0 and op['result'] == first_binding
                            and op['input'] == job['input'] and op['answer'] == data['initial_result']['answer'],
                            'STOP does not retain its own actual initial return')
                    expected_charges = [first_binding]
                    final_body, expected_acquired = body, 0
                else:
                    require(op['additional_calls'] == 1 and op['result'] != first_binding,
                            'Follow-up does not preserve its one additional first dispatch')
                    final_body = {**body, 'supplied_sources': full if op['action'] == 'ACQUIRE' else supplied,
                                  'phase': 'follow-up', 'prior_answer': first_answer,
                                  'instruction': FOLLOWUP_INSTRUCTION}
                    require(read(bound(op['input'])) == final_body, 'Follow-up effective body differs')
                    key = effective_key(plan, final_body)
                    identity = (op['input'], op['answer'], op['result'])
                    if key in by_effective_input:
                        require(by_effective_input[key] == identity, 'Identical follow-up inputs were rerun')
                    else:
                        by_effective_input[key] = identity
                    physical_followups.add(op['result']['path'])
                    expected_charges = [first_binding, op['result']]
                    expected_acquired = acquired if op['action'] == 'ACQUIRE' else 0
            require(op['charged_results'] == expected_charges, 'Logical charged result bindings differ')
            require(type(op['acquired_source_characters']) is int
                    and op['acquired_source_characters'] == expected_acquired, 'Acquired source volume differs')
            require(len({binding['path'] for binding in expected_charges}) == len(expected_charges),
                    'A workflow charges a physical result twice')
            result, _ = inspect_call(op['result'], op['input'])
            require(result['answer'] == op['answer'], 'Operation answer differs from actual result')
            final_answer, quotes = record_answer(op['answer'], final_body)
            charges = []
            for binding in expected_charges:
                require(binding['path'] in all_calls and all_calls[binding['path']]['binding'] == binding,
                        'Charged result was not actually verified')
                charges.append(all_calls[binding['path']]['cost'])
            cost = sum_costs(charges)
            by_variant[op['variant']].append(cost)
            by_allocation_variant[(job['allocation'], op['variant'])].append(cost)
            actual_shared = shares[op['result']['path']] > 1
            if actual_shared != op['physical_call_shared_by_identical_input']:
                sharing_errata.append({'job': job['id'], 'variant': op['variant'],
                    'original_flag': op['physical_call_shared_by_identical_input'],
                    'actual_shared_by_final_result_binding': actual_shared, 'result': op['result']})
            workflows.append({'job': job['id'], 'case': job['case'],
                'allocation': job['allocation'], 'variant': op['variant'], 'action': op['action'],
                'initial_recommendations': actions, 'initial_result': first_binding,
                'final_answer': op['answer'], 'final_result': op['result'], 'final_input': op['input'],
                'charged_results': expected_charges, 'cost': cost,
                'additional_calls': op['additional_calls'], 'acquired_source_characters': expected_acquired,
                'declared_physical_call_shared_by_identical_input': op['physical_call_shared_by_identical_input'],
                'literal_quotes': quotes, 'final_actions': [item['next_action'] for item in final_answer['answers']],
                'semantic_assessment': 'ROOT_READBACK_REQUIRED', 'actual_physical_final_result_shared': actual_shared})
        require(type(operations['physical_followup_calls']) is int
                and operations['physical_followup_calls'] == len(physical_followups) == len(by_effective_input),
                'Physical follow-up deduplication/count differs')

    global_shares = Counter(row['final_result']['path'] for row in workflows)
    for row in workflows:
        row['physical_final_result_workflow_uses'] = global_shares[row['final_result']['path']]
    prefixes = {data['initial']['path'].rsplit('/predictions/', 1)[0] + '/predictions/'
                for data in job_data.values()}
    require(len(prefixes) == 1, 'Frozen jobs record different prediction roots')
    prefix = next(iter(prefixes))
    distributed_results = {original for original in locators
                           if original.startswith(prefix) and original.endswith('/result.json')}
    require(distributed_results == set(all_calls), 'Distributed calls were omitted from physical accounting')
    distributed_destinations = {original.rsplit('/', 1)[0] for original in locators
                                if original.startswith(prefix) and '/' in original[len(prefix):]}
    require(distributed_destinations == {record['binding']['path'].rsplit('/', 1)[0]
                                         for record in all_calls.values()},
            'Unfinished or unaccounted distributed first-call directory')
    require(not any(original.startswith(prefix) and original.endswith('/schema_failure.json')
                    for original in locators), 'Distributed first schema failure prevents completed replay')
    call_bindings = [all_calls[path]['binding'] for path in sorted(all_calls)]
    physical_cost = sum_costs([all_calls[binding['path']]['cost'] for binding in call_bindings])
    quotes = sum(check_answer(binding, body)[1] for binding, body in all_answers.values())
    expected = {'state': 'ALL_FIXED_FIRST_RETURNS_COLLECTED_AND_LITERAL_REPLAYED',
        'operation_bindings': operation_bindings, 'initial_allocations': len(jobs),
        'logical_policy_workflows': len(workflows), 'physical_unique_calls': physical_cost,
        'physical_call_bindings': call_bindings,
        'physical_call_costs': [{'result': binding, 'cost': all_calls[binding['path']]['cost']}
                                for binding in call_bindings],
        'physical_unique_answers': len(all_answers), 'physical_unique_literal_quotes': quotes,
        'literal_defects': 0, 'semantic_accuracy_or_gold_certified': False,
        'logical_policy_cost': {variant: sum_costs(by_variant[variant]) for variant in VARIANTS},
        'logical_allocation_policy_cost': [{'allocation': allocation, 'variant': variant,
            'cost': sum_costs(by_allocation_variant[(allocation, variant)])}
            for allocation in ALLOCATIONS for variant in VARIANTS],
        'sharing_metadata_errata': sharing_errata, 'workflows': workflows, 'automatic_retries': 0}
    for key, value in expected.items():
        require(accounting[key] == value, 'Saved accounting differs from independent replay: ' + key)
    return {'state': 'OFFLINE_FIRST_RETURN_INPUT_ACTION_COST_AND_LITERAL_PROVENANCE_PASS',
        'manifest_files': len(listed) + 1, 'initial_allocations': len(jobs),
        'logical_workflows': len(workflows), 'unique_model_calls': len(all_calls),
        'literal_quotes': quotes, 'literal_defects': 0, 'model_calls_during_replay': 0,
        'missing_usage_fields': physical_cost['missing_usage_fields'],
        'usage_totals_complete': physical_cost['usage_totals_complete'],
        'saved_unit_projection_replayed': True, 'native_projection_rerun': False,
        'host_cli_bytes_reverified': False, 'meaning_certified': False,
        'independent_semantic_gold': False, 'unobserved_execution_absence_certified': False}


if __name__ == '__main__':
    print(json.dumps(verify(sys.argv[1] if len(sys.argv) > 1 else '.'), ensure_ascii=False, indent=2))
