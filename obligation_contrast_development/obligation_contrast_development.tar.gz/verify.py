#!/usr/bin/env python3
"""Replay selected source inputs and literal quotes; never certify semantics."""
import argparse
import hashlib
import json
from pathlib import Path

def read(path):
    return json.loads(path.read_text())

def lf(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')

def verify(directory):
    directory = directory.resolve()
    manifest = directory / 'manifest.json'
    checked = 0
    if manifest.exists():
        for binding in read(manifest)['files']:
            path = directory / binding['path']
            assert path.is_relative_to(directory)
            raw = path.read_bytes()
            assert len(raw) == binding['bytes'] and hashlib.sha256(raw).hexdigest() == binding['sha256']
            checked += 1
    protocol = read(directory / 'protocol.json')
    reference = read(directory / 'author_reference.json')
    rows, costs, failures = [], {}, []
    for case in protocol['cases']:
        name = case['id']
        packet = read(directory / 'sources' / (name + '.json'))
        units = {u['id']: lf(u['text']) for u in packet['units']}
        assembled = '\n\n'.join('[' + u['id'] + ']\n' + lf(u['text']) for u in packet['units'])
        supplied = (directory / 'sources' / (name + '.txt')).read_text()
        assert assembled == supplied
        inp = (directory / 'inputs' / (name + '.txt')).read_text()
        assert inp.split('\n\nFULL SELECTED SOURCE PACKET\n', 1)[1] == supplied
        expected_ids = [q['id'] for q in case['questions']]
        for mode in case['order']:
            dest = directory / 'predictions' / (name + '.' + mode)
            result = read(dest / 'result.json')
            assert result['state'] == 'SAVED_CONTROLLED_ANSWER'
            answer = read(dest / 'answer.txt')
            assert [a['id'] for a in answer['answers']] == expected_ids
            refs = {r['id']: r for r in reference['cases'][name]}
            usage = result['turn_completed_events'][0]['usage']
            costs[name + '.' + mode] = {'input_tokens': usage['input_tokens'], 'output_tokens': usage['output_tokens'], 'cached_input_tokens': usage.get('cached_input_tokens'), 'elapsed_seconds': result['elapsed_seconds']}
            for a in answer['answers']:
                defects = []
                for i, evidence in enumerate(a['evidence']):
                    quote = evidence['quote']
                    if not quote or evidence['source_id'] not in units or quote not in units[evidence['source_id']]:
                        defects.append({'anchor_index': i, 'source_id': evidence['source_id'], 'quote': quote})
                row = {'case': name, 'mode': mode, 'id': a['id'], 'decision': a['decision'], 'reference_decision': refs[a['id']]['decision'], 'exact_decision_match': a['decision'] == refs[a['id']]['decision'], 'prospective_acceptable_decision': a['decision'] in refs[a['id']]['acceptable_decisions'], 'literal_quotes': len(a['evidence']), 'literal_defects': defects, 'semantic_evaluation': 'author readback is separate'}
                rows.append(row)
                failures.extend([{'case': name, 'mode': mode, 'id': a['id'], **d} for d in defects])
    return {'state': 'MECHANICAL_SOURCE_INPUT_AND_FIRST_OUTPUT_REPLAY_COMPLETE', 'manifest_files_checked': checked, 'source_packets_reconstructed': 3, 'source_identical_paired_inputs': True, 'planned_calls': 6, 'returned_first_calls': len(costs), 'query_obligations': 18, 'dependency_components': 3, 'output_obligation_cells': len(rows), 'literal_quotes_checked': sum(r['literal_quotes'] for r in rows), 'literal_defects': failures, 'rows': rows, 'costs': costs, 'model_calls_for_replay': 0, 'expert_gold': False, 'semantic_accuracy_certified': False}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('directory', type=Path); parser.add_argument('--output', type=Path); args = parser.parse_args()
    result = verify(args.directory)
    if args.output:
        with args.output.open('x') as f: json.dump(result, f, ensure_ascii=False, indent=2); f.write('\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('rows', 'costs')}, ensure_ascii=False))
