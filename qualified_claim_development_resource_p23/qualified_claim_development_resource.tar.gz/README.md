# Qualified-claim diagnostic development resource

Run `python3 -B verify.py .` in this extracted directory (Python 3.10+,
standard library only). No repository, network, model, package installation
or original absolute path is needed. `python3 -B -O verify.py .` performs
the same checks: validation does not use removable assert statements.

Three records expose the distinction between retained PC2 context withheld
by selection, supplied CR0002 scheduling scope omitted from substantive
fields, and TS38.351 CR0042r2 capacity versus allocation. Requirements,
first answers, development author assessments and adverse observations are
copied from their original frozen files. No semantic labels are newly judged.
The CR1484 carrier-power omissions, false audit criticism and unnecessary
followups remain in the included author assessments; generic recovery and
its lower costs remain in the unchanged coverage measurements.

The full current coverage lineage contains 26 saved physical returns; the
fixed/probe native lineage contains seven, giving 33 central returns.
Three additional historical PC2 observations are distinct from that central
lineage. All saved input/answer/provider-result/dispatch records are included.
Logical workflows charge reused physical calls, with cache already contained
in input and reasoning already contained in output. Summed request durations
are not pipeline elapsed time or monetary operating cost. Existing equal
character budgets are not provider-token or sampling parity.

The parameterized verifier checks source occurrence AND body inside the
actual supplied-unit section, not metadata mentions. It binds copied raw
question fields/actions, frozen author interpretations, provider usage and
full declared logical charges. It does not certify semantic entailment,
every supplemental assertion, independent expert gold, native rendering,
approval/incorporation, causal performance or particular deployed behavior.

`dependency_inventory.json` distinguishes byte-exact included scientific
dependencies from opaque original locators (native archives, prior reviews,
strategy/handoff controls and protected/raw email). Excluded bodies are not
opened or needed for this replay. Original producers are attributed source
code for inspection and are never executed by verify.py. A historical code
hash differing from its current working file is an explicit opaque locator;
the current file never impersonates that original revision. This is a reusable
development diagnostic resource, not a complete independent semantic benchmark.

Source roles/versions/occurrences and official 3GPP original provenance are
preserved in the pools and projections. Original rights remain with their
owners. Clause/version/rationale links and review/edit alignment build on
DeepSpecs, CR-Eval and ARIES; the unchanged original bibliography is included.
The joint diagnostic record is not claimed to invent these links.

This immutable candidate reports LOCAL PREPARATION ONLY. Root must execute
normal/optimized replay, integrity tests and archive-member checks separately.
Public upload, anonymous same-host download and independent external use are
different states. No DOI, external users, new research calls, or integrated
policy benefit is claimed by this preparation. A later matched-policy
experiment must be published with its own actual first-return provenance.
