#!/usr/bin/env python3
"""Portable, parameterized mechanical validation of qualified-claim records.

This program accepts arbitrary record/call counts. It never judges semantic
coverage: frozen requirements and authored assessments are copied references.
It has no network, model, repository or third-party dependency.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath, PureWindowsPath


def require(condition, message):
    if not condition:
        raise ValueError(message)


def pairs(items):
    value = {}
    for key, item in items:
        require(key not in value, 'Duplicate JSON key: ' + key)
        value[key] = item
    return value


def loads(value):
    def nonfinite(number):
        raise ValueError('Non-finite JSON constant: ' + number)
    return json.loads(value, object_pairs_hook=pairs, parse_constant=nonfinite)


def read(path):
    return loads(path.read_text(encoding='utf-8'))


def digest(path):
    measured, size = hashlib.sha256(), 0
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            measured.update(block)
            size += len(block)
    return {'bytes': size, 'sha256': measured.hexdigest()}


def safe(root, name):
    require(isinstance(name, str) and name, 'Empty or non-string member')
    rel = PurePosixPath(name)
    require(not rel.is_absolute() and not PureWindowsPath(name).drive
            and '\\' not in name and '..' not in rel.parts
            and rel.as_posix() == name and name != '.', 'Escaping/noncanonical member')
    path = root.joinpath(*rel.parts)
    require(path.is_file() and path.resolve().is_relative_to(root.resolve())
            and not any(p.is_symlink() for p in (path, *path.parents)),
            'Missing/linked/escaped member: ' + name)
    return path


def pointer(value, expression):
    require(isinstance(expression, str) and (expression == '' or expression.startswith('/')),
            'Invalid JSON pointer')
    if not expression:
        return value
    for part in expression[1:].split('/'):
        part = part.replace('~1', '/').replace('~0', '~')
        if isinstance(value, list):
            require(part.isdigit() and str(int(part)) == part, 'Noncanonical list index')
            value = value[int(part)]
        else:
            require(isinstance(value, dict) and part in value, 'Absent JSON pointer field')
            value = value[part]
    return value


def supplied_units(text, marker):
    """Metadata occurrence mentions are deliberately outside the unit section."""
    require(isinstance(marker, str) and marker and text.count(marker) == 1,
            'Exactly one declared supplied-unit marker required')
    rows = []
    for line in text.split(marker, 1)[1].splitlines():
        if not line.strip().startswith('{'):
            continue
        try:
            value = loads(line)
        except (ValueError, json.JSONDecodeError):
            continue
        if isinstance(value, dict) and isinstance(value.get('text'), str) \
                and isinstance(value.get('occurrences'), list):
            rows.append(value)
    require(rows, 'No JSON-lines source units in declared section')
    return rows


def validate(root):
    root = root.resolve()
    manifest = read(safe(root, 'manifest.json'))
    require(manifest['schema'] == 'MATCHED_POLICY_REUSE_PACKAGE_MANIFEST_V1',
            'Manifest schema differs')
    entries = manifest['files']
    expected = {x['path']: {k: x[k] for k in ('bytes', 'sha256')} for x in entries}
    require(len(expected) == len(entries) and 'manifest.json' not in expected,
            'Duplicate/self-referential manifest entry')
    observed = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(observed == set(expected) | {'manifest.json'}, 'Missing/extra package member')
    for name, binding in expected.items():
        require(digest(safe(root, name)) == binding, 'Package byte identity differs: ' + name)
    provenance = {x['original']['path']: x for x in manifest['original_provenance']}
    require(len(provenance) == len(manifest['original_provenance']), 'Duplicate original path')
    for original in provenance.values():
        require(expected[original['member']] ==
                {k: original['original'][k] for k in ('bytes', 'sha256')},
                'Original-to-member byte identity differs')

    def bound(binding):
        path = safe(root, binding['path'])
        require(digest(path) == {k: binding[k] for k in ('bytes', 'sha256')},
                'Record binding differs: ' + binding['path'])
        return path

    def frozen(reference):
        value = pointer(read(bound(reference['file'])), reference['pointer'])
        require(value == reference['value'], 'Copied requirement/assessment/field differs')
        return value

    ledger = read(safe(root, manifest['physical_call_ledger']))
    require(ledger['schema'] == 'OBSERVED_PHYSICAL_CALL_LEDGER_V1', 'Call ledger schema differs')
    calls, actual_results = {}, set()
    for row in ledger['calls']:
        require(row['call_id'] not in calls and row['original_result_path'] not in actual_results,
                'Duplicate physical-call identity; reused logical charge is separate')
        result = read(bound(row['result']))
        answer_path = bound(row['answer'])
        answer = answer_path.read_text(encoding='utf-8')
        bound(row['input'])
        require(result['returncode'] == 0 and result['timed_out'] is False,
                'Call was not a completed first return')
        saved_answer = result['answer']
        if isinstance(saved_answer, dict):
            require(provenance[saved_answer['path']]['member'] == row['answer']['path']
                    and digest(answer_path) == {k: saved_answer[k] for k in ('bytes', 'sha256')},
                    'Provider result answer binding differs')
        else:
            require(isinstance(saved_answer, str) and saved_answer == answer,
                    'Provider result answer text differs')
        turns = result['turn_completed_events']
        require(len(turns) == 1 and turns[0]['usage'] == row['raw_provider_usage'],
                'Raw provider usage differs')
        usage = row['raw_provider_usage']
        require(all(type(n) is int and n >= 0 for n in usage.values())
                and {'input_tokens', 'output_tokens'} <= set(usage), 'Invalid usage quantity')
        require(usage.get('cached_input_tokens', 0) <= usage['input_tokens']
                and usage.get('reasoning_output_tokens', 0) <= usage['output_tokens'],
                'Cache/reasoning subset exceeds parent usage')
        require(type(row['request_seconds']) in (int, float)
                and math.isfinite(row['request_seconds']) and row['request_seconds'] >= 0
                and result['elapsed_seconds'] == row['request_seconds'], 'Request duration differs')
        dispatch = read(bound(row['dispatch']))
        require(digest(bound(row['input'])) ==
                {k: dispatch['input'][k] for k in ('bytes', 'sha256')},
                'Actual dispatched input differs')
        require(row['original_result_path'] in provenance
                and provenance[row['original_result_path']]['member'] == row['result']['path'],
                'Actual result origin differs')
        calls[row['call_id']] = row
        actual_results.add(row['original_result_path'])

    def charges(ids):
        require(isinstance(ids, list) and ids and len(ids) == len(set(ids)),
                'Duplicate call within one logical workflow')
        members = [calls[name] for name in ids]
        keys = set().union(*(row['raw_provider_usage'] for row in members))
        return {'calls': len(members), 'provider_usage_sum': {
                    key: sum(row['raw_provider_usage'].get(key, 0) for row in members)
                    for key in sorted(keys)},
                'request_seconds_sum': sum(row['request_seconds'] for row in members)}

    def workflow(row):
        value = charges(row['call_ids'])
        require(value['calls'] == row['calls'] and value['provider_usage_sum'] == row['provider_usage_sum']
                and abs(value['request_seconds_sum'] - row['request_seconds_sum']) < 1e-8,
                'Logical full-workflow charges differ: ' + row['workflow_id'])
        if 'original_accounting' in row:
            original = frozen(row['original_accounting'])
            require(original['request_count'] == value['calls']
                    and original['actual_result_paths'] == [calls[x]['original_result_path'] for x in row['call_ids']],
                    'Historical logical membership differs')
            for key, count in value['provider_usage_sum'].items():
                require(original[key] == count, 'Historical logical usage differs')
            require(abs(original['request_seconds'] - value['request_seconds_sum']) < 1e-8,
                    'Historical logical duration differs')
        return value

    ledger_workflows = {x['workflow_id']: workflow(x) for x in ledger['logical_workflows']}
    require(len(ledger_workflows) == len(ledger['logical_workflows']), 'Duplicate workflow ID')
    lineage = []
    for group in ledger['lineage_groups']:
        totals = charges(group['call_ids'])
        require(totals == group['observed_totals'], 'Fixture lineage totals differ')
        if 'original_flat_accounting' in group:
            original = frozen(group['original_flat_accounting'])
            require(original['request_count'] == totals['calls']
                    and len(original['actual_result_paths']) == totals['calls']
                    and set(original['actual_result_paths']) ==
                    {calls[x]['original_result_path'] for x in group['call_ids']},
                    'Original physical lineage membership differs')
            require(all(original[key] == count for key, count in totals['provider_usage_sum'].items())
                    and abs(original['request_seconds'] - totals['request_seconds_sum']) < 1e-8,
                    'Original physical lineage charges differ')
        lineage.append({'group_id': group['group_id'], **totals})
    record_reports = []
    for name in manifest['records']:
        record = read(safe(root, name))
        require(record['schema'] == 'QUALIFIED_CLAIM_DIAGNOSTIC_RECORD_V2', 'Record schema differs')
        require(record['semantic_labels_rejudged'] is False and record['independent_expert_gold'] is False
                and record['whole_response_support_certified'] is False,
                'Mechanical replay cannot certify authored semantic judgments')
        for reference in record['qualified_claim']['frozen_requirements']:
            frozen(reference)
        for reference in record['qualified_claim'].get('original_qualified_record_fields', []):
            frozen(reference)
        for reference in record['substantive_coverage']['authored_assessments']:
            frozen(reference)
        for reference in record['substantive_coverage']['actual_answer_fields']:
            frozen(reference)
        for reference in record['action_and_charge']['observed_action_fields']:
            frozen(reference)
        selected = []
        for witness in record['source_inventory']['selected_witnesses']:
            source_unit = frozen(witness['source_reference'])
            require(source_unit['id'] == witness['source_id'] and source_unit == witness['source_unit']
                    and witness['available'] is True, 'Available source identity differs')
            states = []
            for state in witness['saved_input_states']:
                require(state['call_id'] in calls and type(state['supplied']) is bool,
                        'Invalid saved-input supply state')
                rows = supplied_units(bound(calls[state['call_id']]['input']).read_text(encoding='utf-8'),
                                      state['unit_section_marker'])
                matching = [unit for unit in rows if any(
                    x.get('id') == witness['source_id'] for x in unit['occurrences'])]
                actual = bool(matching)
                require(actual == state['supplied'], 'Supplied/withheld state differs')
                require(not matching or all(x['text'] == source_unit['text'] for x in matching),
                        'Supplied source body differs from available witness')
                states.append({'call_id': state['call_id'], 'supplied': actual})
            selected.append({'source_id': witness['source_id'], 'available': True,
                             'saved_input_states': states})
        record_workflows = {x['workflow_id']: workflow(x) for x in
                            record['action_and_charge']['logical_workflows']}
        require(len(record_workflows) == len(record['action_and_charge']['logical_workflows']),
                'Duplicate record workflow ID')
        record_reports.append({'record_id': record['record_id'], 'selected_witnesses': selected,
                               'logical_workflows': record_workflows,
                               'copied_author_assessment_only': True})
    return {'state': 'PARAMETERIZED_DIAGNOSTIC_IDENTITY_SUPPLY_FIELD_AND_CHARGE_PASS',
            'files_hashed': len(expected), 'record_count': len(record_reports),
            'unique_saved_physical_returns': len(calls), 'lineage_groups': lineage,
            'historical_logical_workflows': ledger_workflows, 'records': record_reports,
            'new_research_model_calls': 0, 'semantic_labels_rejudged': False,
            'independent_expert_gold': False, 'whole_response_support_certified': False,
            'native_rendering_certified': False, 'public_upload_certified': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('package', type=Path)
    print(json.dumps(validate(parser.parse_args().package), ensure_ascii=False, indent=2))
