#!/usr/bin/env python3
"""Enforce the frozen P10 first-failure stop across sequential processes.

Wrap the unchanged protocol-bound producer's dispatcher. No question, source,
instruction, allocation, recommendation, returned answer or retry is changed.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import compare_followup_actions as experiment


def check_history(destination):
    records = []
    predictions = experiment.OUT / 'predictions'
    for prior in sorted(predictions.iterdir()) if predictions.exists() else []:
        if not prior.is_dir():
            continue
        result_path = prior / 'result.json'
        if not result_path.exists():
            raise RuntimeError('Unfinished first dispatch prevents subsequent calls: ' + str(prior))
        result = experiment.executor.read(result_path)
        if result['state'] != 'SAVED_CONTROLLED_ANSWER' or (prior / 'schema_failure.json').exists():
            raise RuntimeError('Preserved first failure prevents subsequent calls: ' + str(prior))
        if prior.name.endswith('.initial') and not (prior / 'mechanical_check.json').exists():
            raise RuntimeError('Unchecked initial first output prevents subsequent calls: ' + str(prior))
        records.append(experiment.executor.bind(result_path))
    if destination.exists():
        raise RuntimeError('Existing first-call destination cannot be rerun: ' + str(destination))
    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('initial', 'followups'))
    parser.add_argument('--case', required=True, choices=tuple(experiment.REQUESTS))
    args = parser.parse_args()
    original_turn = experiment.executor.turn

    def admitted_turn(plan, destination, binding, policy_name):
        history = check_history(destination)
        admissions = experiment.OUT / 'dispatch_admissions'
        admissions.mkdir(exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        experiment.executor.save(admissions / (stamp + '.json'), {
            'state': 'NO_PRIOR_INCOMPLETE_UNCONTROLLED_OR_SCHEMA_FAILURE',
            'producer': experiment.executor.bind(Path(experiment.__file__)),
            'admission_wrapper': experiment.executor.bind(Path(__file__)),
            'protocol': experiment.executor.bind(experiment.OUT / 'protocol.json'),
            'prior_results': history, 'next_input': binding,
            'next_destination': str(destination.relative_to(experiment.ROOT)),
            'scientific_inputs_or_policy_modified': False, 'retry_authorized': False})
        return original_turn(plan, destination, binding, policy_name)

    experiment.executor.turn = admitted_turn
    (experiment.run_initial if args.action == 'initial' else experiment.run_followups)(args.case)


if __name__ == '__main__':
    main()
