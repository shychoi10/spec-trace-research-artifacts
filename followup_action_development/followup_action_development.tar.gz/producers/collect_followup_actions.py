#!/usr/bin/env python3
"""Replay P10 citations and count unique calls versus logical policy cost.

No model dispatch, reference comparison or semantic correctness judgment.
The original sharing flag is retained and independently checked using actual
result bindings. STOP is charged once for its shared initial call.
"""
from collections import Counter, defaultdict
from pathlib import Path

import compare_followup_actions as experiment

OUT = experiment.OUT
e = experiment.executor
FIELDS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens',
          'output_tokens', 'reasoning_output_tokens')


def cost(binding):
    result = e.read(e.verify(binding))
    assert result['state'] == 'SAVED_CONTROLLED_ANSWER'
    assert len(result['turn_completed_events']) == 1
    usage = result['turn_completed_events'][0]['usage']
    return {'model_calls': 1, **{k: usage.get(k, 0) for k in FIELDS},
            'observed_seconds': result['elapsed_seconds']}


def sum_costs(rows):
    return {key: sum(row[key] for row in rows)
            for key in ('model_calls', *FIELDS, 'observed_seconds')}


def replay(answer_binding, input_binding):
    body = e.read(e.verify(input_binding))
    answer = experiment.validate_answer(e.verify(answer_binding), body['supplied_sources'])
    return answer, sum(len(a['evidence']) for a in answer['answers'])


def main():
    plan = e.read(OUT / 'protocol.json')
    for binding in plan['dependencies'] + list(plan['policies'].values()):
        e.verify(binding)
    unique_calls, unique_answers = {}, {}
    workflows, sharing_errata = [], []
    by_variant = defaultdict(list)
    by_allocation_variant = defaultdict(list)
    for job in plan['jobs']:
        initial_path = OUT / 'predictions' / (job['id'] + '.initial')
        initial_binding = e.bind(initial_path / 'result.json')
        initial = e.read(e.verify(initial_binding))
        initial_answer, _ = replay(initial['answer'], job['input'])
        unique_calls[initial_binding['path']] = initial_binding
        unique_answers[initial['answer']['path']] = (initial['answer'], job['input'])
        op_path = OUT / 'predictions' / (job['id'] + '.operations.json')
        operations = e.read(op_path)
        assert operations['initial'] == initial_binding
        assert operations['recommended_actions'] == [a['next_action'] for a in initial_answer['answers']]
        assert [o['variant'] for o in operations['operations']] == list(experiment.VARIANTS)
        shared = Counter(o['result']['path'] for o in operations['operations'] if o['additional_calls'])
        assert operations['physical_followup_calls'] == len(shared)
        for op in operations['operations']:
            charges = [cost(initial_binding)]
            if op['additional_calls'] == 0:
                assert op['action'] == 'STOP' and op['result'] == initial_binding
                assert op['answer'] == initial['answer'] and op['acquired_source_characters'] == 0
                final_answer, quotes = replay(op['answer'], job['input'])
                actual_shared = False
            else:
                assert op['additional_calls'] == 1 and op['action'] in ('ASK', 'ACQUIRE')
                result = e.read(e.verify(op['result']))
                assert result['answer'] == op['answer']
                final_answer, quotes = replay(op['answer'], op['input'])
                charges.append(cost(op['result']))
                unique_calls[op['result']['path']] = op['result']
                unique_answers[op['answer']['path']] = (op['answer'], op['input'])
                actual_shared = shared[op['result']['path']] > 1
                if actual_shared != op['physical_call_shared_by_identical_input']:
                    sharing_errata.append({'job': job['id'], 'variant': op['variant'],
                        'original_flag': op['physical_call_shared_by_identical_input'],
                        'actual_shared_by_result_binding': actual_shared, 'result': op['result']})
            workflow_cost = sum_costs(charges)
            by_variant[op['variant']].append(workflow_cost)
            by_allocation_variant[(job['allocation'], op['variant'])].append(workflow_cost)
            workflows.append({'job': job['id'], 'case': job['case'],
                'allocation': job['allocation'], 'variant': op['variant'], 'action': op['action'],
                'initial_recommendations': operations['recommended_actions'],
                'initial_result': initial_binding, 'final_answer': op['answer'],
                'final_result': op['result'], 'cost': workflow_cost,
                'additional_calls': op['additional_calls'],
                'acquired_source_characters': op['acquired_source_characters'],
                'actual_physical_followup_shared': actual_shared,
                'literal_quotes': quotes, 'final_actions': [a['next_action'] for a in final_answer['answers']],
                'semantic_assessment': 'ROOT_READBACK_REQUIRED'})
    citations = sum(replay(answer, inp)[1] for answer, inp in unique_answers.values())
    call_bindings = [unique_calls[key] for key in sorted(unique_calls)]
    output = {'state': 'ALL_FIXED_FIRST_RETURNS_COLLECTED_AND_LITERAL_REPLAYED',
        'collector': e.bind(Path(__file__)), 'protocol': e.bind(OUT / 'protocol.json'),
        'operation_bindings': [e.bind(OUT / 'predictions' / (j['id'] + '.operations.json')) for j in plan['jobs']],
        'initial_allocations': len(plan['jobs']), 'logical_policy_workflows': len(workflows),
        'physical_unique_calls': sum_costs([cost(b) for b in call_bindings]),
        'physical_call_bindings': call_bindings,
        'physical_unique_answers': len(unique_answers), 'physical_unique_literal_quotes': citations,
        'literal_defects': 0, 'semantic_accuracy_or_gold_certified': False,
        'logical_policy_cost': {v: sum_costs(by_variant[v]) for v in experiment.VARIANTS},
        'logical_allocation_policy_cost': [{'allocation': a, 'variant': v,
            'cost': sum_costs(by_allocation_variant[(a, v)])}
            for a in ('withheld_target', 'intact') for v in experiment.VARIANTS],
        'sharing_metadata_errata': sharing_errata,
        'workflows': workflows, 'automatic_retries': 0,
        'cost_interpretation': 'Initial answer and diagnosis charged to every logical workflow. A stopped policy incurs no second charge. Identical follow-up inputs physically share one answer, allocated once per logical workflow. Observed seconds are reported, not causal latency/TCO. Source preparation and author review are outside these model costs.'}
    e.save(OUT / 'completed_first_call_accounting.json', output)
    print(__import__('json').dumps({key: output[key] for key in
        ('state', 'initial_allocations', 'logical_policy_workflows', 'physical_unique_calls',
         'physical_unique_answers', 'physical_unique_literal_quotes', 'literal_defects', 'logical_policy_cost')}, indent=2))


if __name__ == '__main__':
    main()
