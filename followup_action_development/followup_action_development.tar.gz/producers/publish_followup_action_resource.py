#!/usr/bin/env python3
"""Prepare, publish and anonymously replay the bounded P10 action experiment."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

import compare_followup_actions as method
import publish_codex_relation_resource as publisher
import verify_followup_action_resource as verifier
import verify_source_decision_resource as provenance

e, OUT = method.executor, method.OUT
PUB = OUT / 'publication'
DIRECTORY = 'followup_action_development'
ARCHIVE = DIRECTORY + '.tar.gz'
NAMES = ['README.md', 'resource.json', ARCHIVE, 'checksums.sha256']


def prepare():
    e.guarded()
    assessment = e.read(OUT / 'author_answer_readback.json')
    provenance.require(assessment['physical_unique_answers_directly_read'] == 15, 'Root readback required')
    PUB.mkdir()
    package = PUB / 'package'
    package.mkdir()
    locators = {}

    def copy(source, relative):
        target = package / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        provenance.require(not target.exists(), 'Do not overwrite a package member')
        shutil.copyfile(source, target)
        locators[e.bind(source)['path']] = relative

    for name in ('selection.json', 'metadata_eligibility.json', 'dependency_audit.json',
                 'primary_recomparison.json', 'author_reference.json', 'protocol.json',
                 'answer_and_action_policy.txt', 'technical_errata.json',
                 'admission_provenance_erratum.json', 'completed_first_call_accounting.json',
                 'author_answer_readback.json'):
        copy(OUT / name, name)
    for folder in ('cases', 'inputs', 'predictions', 'dispatch_admissions'):
        for source in sorted((OUT / folder).rglob('*')):
            if source.is_file():
                copy(source, str(source.relative_to(OUT)))
    for guard in sorted(OUT.glob('*-guard')):
        for name in ('admission.json', 'result.json', 'child.log'):
            if (guard / name).exists():
                copy(guard / name, guard.name + '/' + name)
    script_names = ('compare_followup_actions.py', 'prepare_followup_action_sources.py',
                    'audit_followup_sources.py', 'admit_followup_dispatch.py',
                    'admit_verified_followup_dispatch.py', 'collect_followup_actions.py',
                    'publish_followup_action_resource.py')
    for name in script_names:
        copy(Path(__file__).with_name(name), 'producers/' + name)
    copy(Path(verifier.__file__), 'verify.py')
    copy(Path(provenance.__file__), 'verify_source_decision_resource.py')
    plan = e.read(OUT / 'protocol.json')
    for index, binding in enumerate(plan['dependencies'] + list(plan['policies'].values())):
        if binding['path'] not in locators:
            copy(e.verify(binding), 'dependencies/' + str(index) + '-' + Path(binding['path']).name)
    e.save(package / 'source_locators.json', locators)
    readme = '''# Source-aware follow-up action development resource

Three new-specification RAN2 cases were selected by frozen metadata order before
technical source reading. The initial questions, author source references,
source inventory and protocol precede every model answer. All cases are kept,
including an editorial-only change. Native CRs, observed base/target files and
saved text projections retain their distinct roles. No protected email bodies.
Native/package/literal-reference overlap checks do not certify independence:
some specification references lead to previously exposed sources.

Each case has a deliberately withheld-target and an intact source allocation.
These are controlled source ablations, not natural retrieval-failure samples.
All three policies share each initial answer and diagnosis. Source-aware uses
the first recommended actions without an author override; always-ask rechecks
the supplied text; always-acquire obtains any remaining target excerpts.
All use the same three explicit questions and answer allowance. Already
successful initial answers and unsupported authority/device unknowns remain.
The author readback is not expert gold or general model accuracy. Acquisition
uses a prepared question-scoped catalogue, not an end-to-end search evaluation.

Run python3 -B verify.py . and python3 -O -B verify.py . with the standard library.
Replay checks every distributed file, frozen protocol dependencies, source-scope
selection, initial allocations, first-recommendation routing, actual follow-up
inputs, literal quotes, raw event/answer/usage and closed CLI dispatch provenance.
It independently recomputes logical policy costs and physical unique-call costs.
Initial diagnosis costs are charged to every logical workflow; STOP adds no
second call. Identical follow-up inputs physically share a returned answer.
Recorded sharing metadata errors and one transient on-disk versus process-loaded
admission-wrapper binding discrepancy are retained with separate errata. No
scientific input or returned answer is replaced, and there is no reroll.

Replay does not execute inference, rerender native Word files, certify semantics,
independence, past empty directories or absence of unobserved executions. Native
files and saved projections are distributed; prior-art PDFs, historical source
libraries, host CLI/authentication and external-memory files are not. Binding
checks cover distributed protocol/input/operation/native files, not every external
historical audit dependency. Local preparation, upload and credential-free
same-host download are separate states. No DOI or observed external users.
'''
    e.text_new(package / 'README.md', readme)
    files = [{'path': str(f.relative_to(package)), **provenance.digest(f)}
             for f in sorted(package.rglob('*')) if f.is_file()]
    e.save(package / 'manifest.json', {'files': files, 'development_only': True, 'expert_gold': False})
    replay = verifier.verify(package)
    e.save(PUB / 'local_replay.json', replay)
    optimized = subprocess.run([sys.executable, '-O', '-B', str(package / 'verify.py'), str(package)],
                               capture_output=True, text=True)
    e.text_new(PUB / 'optimized_replay.stdout.txt', optimized.stdout)
    e.text_new(PUB / 'optimized_replay.stderr.txt', optimized.stderr)
    provenance.require(optimized.returncode == 0, 'Inspect first optimized replay failure')
    provenance.require(json.loads(optimized.stdout) == replay, 'Normal and optimized replay differ')
    with tarfile.open(PUB / ARCHIVE, 'w:gz') as archive:
        for source in sorted(package.rglob('*')):
            if source.is_file():
                archive.add(source, arcname=str(source.relative_to(package)))
    shutil.copyfile(package / 'README.md', PUB / 'README.md')
    e.save(PUB / 'resource.json', {'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'created_utc': e.now(),
        'producer': e.bind(Path(__file__)), 'archive': provenance.digest(PUB / ARCHIVE),
        'files': len(files) + 1, 'unique_first_model_calls': 15, 'logical_workflows': 18,
        'source_cases': 3, 'uploaded': False, 'anonymous_download_verified': False,
        'normal_and_optimized_replay_match': True, 'expert_gold': False,
        'doi': None, 'external_users_observed': 0})
    e.text_new(PUB / 'checksums.sha256', '\n'.join(provenance.digest(PUB / n)['sha256'] + '  ' + n for n in NAMES[:-1]) + '\n')
    print(json.dumps({'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'replay': replay}), flush=True)


def check():
    e.guarded()
    record = e.read(PUB / 'upload.json')
    provenance.require(not (PUB / 'publication.json').exists(), 'Do not repeat completed public verification')
    outside = Path(tempfile.mkdtemp(prefix='followup-action-anonymous-replay-'))
    download = outside / 'download'
    download.mkdir()

    def fetch(name):
        url = 'https://raw.githubusercontent.com/' + publisher.REPO + '/' + record['commit'] + '/' + DIRECTORY + '/' + name
        request = urllib.request.Request(url, headers={'User-Agent': 'source-aware-action-replay'})
        provenance.require(not any(k.lower() in ('authorization', 'cookie') for k, _ in request.header_items()), 'Credentials in anonymous request')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=180) as response:
            raw, status = response.read(), response.status
        target = download / name
        target.write_bytes(raw)
        provenance.require(provenance.digest(target) == record['files'][name], 'Downloaded hash mismatch')
        return name, {'url': url, 'http_status': status, **provenance.digest(target),
                      'authorization_header_sent': False, 'cookie_header_sent': False}

    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            downloads = dict(pool.map(fetch, NAMES))
        unpacked = outside / 'unpacked'
        unpacked.mkdir()
        with tarfile.open(download / ARCHIVE) as archive:
            archive.extractall(unpacked, filter='data')
        runs = []
        for mode in ('normal', 'optimized'):
            argv = [sys.executable] + (['-O'] if mode == 'optimized' else []) + ['-B', str(unpacked / 'verify.py'), str(unpacked)]
            result = subprocess.run(argv, cwd=unpacked, capture_output=True, text=True)
            e.text_new(PUB / ('anonymous_' + mode + '.stdout.txt'), result.stdout)
            e.text_new(PUB / ('anonymous_' + mode + '.stderr.txt'), result.stderr)
            provenance.require(result.returncode == 0, 'Inspect first anonymous replay failure')
            runs.append(json.loads(result.stdout))
        provenance.require(runs[0] == runs[1], 'Anonymous replay modes differ')
        e.save(PUB / 'publication.json', {'status': 'PUBLIC_UPLOAD_AND_ANONYMOUS_ACTION_PROVENANCE_REPLAY_VERIFIED',
            'observed_utc': e.now(), 'repository': record['repository'], 'commit': record['commit'],
            'directory': DIRECTORY, 'snapshot_url': record['repository'] + '/tree/' + record['commit'] + '/' + DIRECTORY,
            'downloaded_files': downloads, 'anonymous_replay': runs[0], 'normal_and_optimized_replay_match': True,
            'outside_repository_workspace': str(outside),
            'external_download_scope': 'Credential-free same-host replay outside checkout, not an independent user or machine.',
            'native_projection_rerun': False, 'meaning_certified': False, 'expert_gold': False,
            'external_users_observed': 0, 'doi': None, 'model_calls_for_replay': 0})
        print(json.dumps({'status': 'PUBLIC_UPLOAD_AND_ANONYMOUS_ACTION_PROVENANCE_REPLAY_VERIFIED', 'replay': runs[0]}), flush=True)
    except BaseException as error:
        e.save(PUB / 'publication_download_failure.json', {'error': repr(error), 'workspace': str(outside)})
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'upload', 'check'))
    args = parser.parse_args()
    if args.action == 'upload':
        e.guarded()
        publisher.OUT, publisher.DIRECTORY, publisher.ARCHIVE, publisher.NAMES = PUB, DIRECTORY, ARCHIVE, NAMES
        publisher.upload()
    else:
        globals()[args.action]()
