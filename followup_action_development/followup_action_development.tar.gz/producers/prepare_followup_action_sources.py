#!/usr/bin/env python3
"""Freeze a bounded source-first action study before technical reading or answers.

Existing source producers are reused without changing their preserved runs.
The three distinct specifications bound sequential development work; they are
neither a statistical threshold nor a claim of independent held-out sampling.
"""
import argparse
import csv
import json
from pathlib import Path

import assemble_standards_tsg_inputs as archive_names
import prepare_new_component_diagnostic as cr_sources
import prepare_new_component_endpoints as endpoint_sources
import run_codex_relation_comparison as executor
from select_new_component_diagnostic import METADATA_KEYS

ROOT = executor.ROOT
BASE = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research'
AREA = BASE / 'experiments/relation_annotation'
OUT = AREA / 'priority10-followup-action-utility'
LIBRARY = AREA / 'standards_changes/transition_library'
CASE_BUDGET = 3


def select():
    executor.guarded()
    OUT.mkdir(parents=True, exist_ok=True)
    assert not (OUT / 'selection.json').exists(), 'Preserve the prospective population'
    p5_path = AREA / 'priority5-evidence-acquisition/selection.json'
    p7_path = AREA / 'priority7-new-component-diagnostic/selection.json'
    p5, p7 = executor.read(p5_path), executor.read(p7_path)
    excluded = sorted(set(p5['excluded_specifications']) |
                      {r['transition'][0] for r in p5['selected']} |
                      {p7['selected']['spec_number']})
    old_rows = executor.read(executor.verify(p5['metadata']))
    components_path = LIBRARY / 'source_dependencies/components.json'
    components = executor.read(components_path)['plus_literal_references']
    component_exclusions = []
    for i, component in enumerate(components):
        specifications = sorted({old_rows[r]['transition'][0] for r in component['row_ids']})
        overlap = sorted(set(specifications) & set(excluded))
        component_exclusions.append({'component_index': i,
                                     'row_ids': component['row_ids'],
                                     'specifications': specifications,
                                     'known_exposed_specification_overlap': overlap,
                                     'excluded': bool(overlap)})
    assert all(c['excluded'] for c in component_exclusions), 'Reassess existing unused components first'
    allocation = executor.read(LIBRARY / 'allocation.json')
    protected = set(executor.read(executor.verify(allocation['protected_scope']))['protected_record_families'])
    protected |= {json.loads(line)['record'] for line in executor.verify(allocation['protected_inventory']).open()}
    metadata = ROOT / 'data/corpus/tsg/RAN/formal/change-requests/RAN2/source/Rel-19/metadata/cr_list.csv'
    with metadata.open(encoding='utf-8-sig') as stream:
        rows = [{k: r[k] for k in METADATA_KEYS} for r in csv.DictReader(stream)]
    inventory_path = LIBRARY.parent / 'ts_inventory.jsonl'
    endpoints = {}
    for line in inventory_path.open():
        r = json.loads(line)
        if r['wg'] == 'RAN2' and r['cover_status'] == 'matched':
            endpoints.setdefault(tuple(r['cover_identity']), []).append(r)
    eligibility = []
    folder = metadata.parent.parent
    for r in rows:
        reasons = []
        if r['spec_number'] in excluded:
            reasons.append('known_exposed_specification')
        if {r['wg_tdoc'], r['tsg_tdoc']} & protected:
            reasons.append('protected_identifier')
        for role, subdir, key in (('WG', 'wg_docs', 'wg_tdoc'), ('TSG', 'TSG', 'tsg_tdoc')):
            if not (folder / subdir / (r[key] + '.zip')).is_file():
                reasons.append('missing_local_' + role + '_archive')
        if not endpoints.get((r['spec_number'], r['new_version'])):
            reasons.append('missing_cover_verified_exact_local_target')
        if not r['impacted_version'] or not r['new_version']:
            reasons.append('missing_version_identifier')
        eligibility.append({'metadata': r, 'eligible': not reasons, 'excluded_reasons': reasons})
    order = sorted((r['metadata'] for r in eligibility if r['eligible']),
                   key=lambda r: (r['spec_number'], int(r['cr_number']),
                                  int(r['revision']) if r['revision'].isdigit() else -1,
                                  r['wg_tdoc'], r['tsg_tdoc']))
    executor.save(OUT / 'metadata_eligibility.json', {
        'state': 'CURRENT_METADATA_ONLY_ELIGIBILITY_BEFORE_TECHNICAL_READBACK',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
        'metadata': executor.bind(metadata), 'inventory': executor.bind(inventory_path),
        'excluded_specifications': excluded, 'rows': eligibility, 'eligible_order': order,
        'discarded_fields': 'Titles, rationale, descriptions, collected approval/status fields',
        'source_bodies_read_for_selection': 0, 'model_calls': 0})
    selected, seen = [], set()
    for r in order:
        if r['spec_number'] not in seen:
            selected.append(r)
            seen.add(r['spec_number'])
        if len(selected) == CASE_BUDGET:
            break
    assert selected, 'Preserve empty availability; do not substitute an exposed success'
    cases = []
    for r in selected:
        case_id = 'spec' + r['spec_number'].replace('.', '_') + '_CR' + r['cr_number']
        case = OUT / 'cases' / case_id
        case.mkdir(parents=True)
        archives = {role: folder / subdir / (r[key] + '.zip')
                    for role, subdir, key in (('wg', 'wg_docs', 'wg_tdoc'), ('tsg', 'TSG', 'tsg_tdoc'))}
        names = {role: archive_names.members(path.read_bytes(), [], protected)
                 for role, path in archives.items()}
        target = sorted(endpoints[(r['spec_number'], r['new_version'])],
                        key=lambda t: (not t['path'].endswith('.zip'), t['path']))[0]
        executor.save(case / 'selection.json', {
            'state': 'CASE_METADATA_SELECTION_FROZEN_BEFORE_TECHNICAL_READBACK',
            'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
            'selected': r, 'archives': {role: executor.bind(path) for role, path in archives.items()},
            'archive_member_names_only': names,
            'target': {k: target[k] for k in ('path', 'bytes', 'sha256', 'cover_identity')},
            'exact_local_base_available': bool(endpoints.get((r['spec_number'], r['impacted_version']))),
            'protected_scope': allocation['protected_scope'], 'protected_inventory': allocation['protected_inventory'],
            'independent_components_certified': False, 'evaluation_split_created': False,
            'model_calls': 0, 'source_bodies_read_for_selection': 0,
            'protected_email_family_bodies_opened': 0})
        cases.append({'id': case_id, 'selected': r, 'selection': executor.bind(case / 'selection.json')})
    executor.save(OUT / 'selection.json', {
        'state': 'THREE_SPECIFICATION_DEVELOPMENT_POPULATION_FROZEN_BEFORE_BODIES_OR_OUTPUTS',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
        'parent_review_analysis': executor.bind(BASE / 'reviews/priority-sequence/priority-9/analysis.json'),
        'metadata_eligibility': executor.bind(OUT / 'metadata_eligibility.json'),
        'exposure_sources': [executor.bind(p5_path), executor.bind(p7_path), executor.bind(components_path)],
        'prior_library_component_exclusions': component_exclusions,
        'excluded_specifications': excluded, 'cases': cases,
        'selection_rule': 'First three distinct specification IDs in current eligible order: specification string, numeric CR, numeric revision (- first), WG TDoc, TSG TDoc. No title, technical body, answer, success or review outcome used.',
        'case_budget': CASE_BUDGET,
        'budget_reason': 'Bound the initial sequential source-first development batch to three specifications before technical reading. This is an operational batch, not a power calculation, statistical cutoff or independent test set. Retain all selected failures and unavailable sources; no outcome-based replacements.',
        'existing_library_unused_conservative_components': 0,
        'available_new_specifications': len({r['spec_number'] for r in order}),
        'remaining_metadata_rows_not_selected': [r for r in order if r not in selected],
        'planned_measurement': 'Source-aware next action versus always ask, always acquire and intact-context reference, with identical explicit predicates, allowed metadata, answer allowance and one-action limit. Freeze reference after root source reading and before model outputs. Keep information-addition effects separate from action-policy effects.',
        'controlled_withholding_if_used': 'Explicit source ablation; never presented as naturally missing evidence.',
        'reference_status': 'Not yet authored; source preparation and root direct reading required.',
        'source_bodies_read_for_selection': 0, 'model_calls': 0,
        'independent_components_certified': False, 'evaluation_split_created': False,
        'protected_email_family_bodies_opened': 0})
    print(json.dumps({'state': 'P10_POPULATION_FROZEN', 'cases': selected,
                      'eligible_rows': len(order), 'available_specifications': len({r['spec_number'] for r in order}),
                      'model_calls': 0}), flush=True)


def materialize(action, case_id):
    executor.guarded()
    selection = executor.read(OUT / 'selection.json')
    record = next(c for c in selection['cases'] if c['id'] == case_id)
    case = executor.verify(record['selection']).parent
    producer = cr_sources if action in ('cr', 'fetch_base') else endpoint_sources
    producer.OUT = case
    executor.save(case / (action + '_invocation.json'), {
        'created_utc': executor.now(), 'root_producer': executor.bind(Path(__file__)),
        'reused_producer': executor.bind(Path(producer.__file__)), 'case_selection': record['selection'],
        'action': action, 'source_outputs_are_not_semantic_validation': True})
    if action == 'endpoints':
        endpoint_sources.main()
    else:
        getattr(cr_sources, action)()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=('select', 'cr', 'fetch_base', 'endpoints'))
    parser.add_argument('--case')
    args = parser.parse_args()
    if args.action == 'select':
        select()
    else:
        assert args.case, 'Case identity required'
        materialize(args.action, args.case)
