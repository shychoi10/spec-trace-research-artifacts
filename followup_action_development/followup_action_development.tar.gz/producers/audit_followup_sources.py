#!/usr/bin/env python3
"""Record byte, package and literal-reference dependencies before new answers.

Historical metadata is inspected without reopening previous native bodies or
protected email families. This audit does not certify independence or meaning.
"""
import json
from pathlib import Path
import re

import run_codex_relation_comparison as executor

ROOT = executor.ROOT
AREA = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
OUT = AREA / 'priority10-followup-action-utility'
LIB = AREA / 'standards_changes/transition_library/source_dependencies'
TDOC = re.compile(r'(?<![A-Za-z0-9])R[1-5P]-\d{6,7}(?:r\d+)?(?!\d)', re.I)
SPEC = re.compile(r'\b(?:TS|TR)\s*(\d{2}\.\d{3}(?:-\d+)?)', re.I)


def main():
    executor.guarded()
    selection = executor.read(OUT / 'selection.json')
    rows = executor.read(LIB / 'rows.json')
    docs = executor.read(LIB / 'documents.json')
    p7 = executor.read(AREA / 'priority7-new-component-diagnostic/selection.json')
    p7_cr = executor.read(AREA / 'priority7-new-component-diagnostic/cr_preparation.json')
    prior_natives = {i['native']['sha256'] for r in rows for i in r['inputs']}
    prior_natives |= {o['native']['sha256'] for o in p7_cr['origins']}
    prior_packages = {r['tsg_packet']['sha256'] for r in rows if r['tsg_packet']}
    prior_packages.add(p7['archives']['tsg']['sha256'])
    prior_families = {r[k].upper() for r in rows for k in ('wg_tdoc', 'tsg_tdoc')}
    prior_families |= {ref['family'].upper() for d in docs for ref in d['references']}
    prior_families |= {p7['selected']['wg_tdoc'], p7['selected']['tsg_tdoc']}
    allocation = executor.read(LIB.parent / 'allocation.json')
    protected = set(executor.read(executor.verify(allocation['protected_scope']))['protected_record_families'])
    protected |= {json.loads(line)['record'] for line in executor.verify(allocation['protected_inventory']).open()}
    audit = []
    for c in selection['cases']:
        case = executor.verify(c['selection']).parent
        s = executor.read(case / 'selection.json')
        cr = executor.read(case / 'sources/CR.rows.json')
        preparation = executor.read(case / 'source_preparation.json')
        literal_occurrences = []
        for u in cr['units']:
            for m in TDOC.finditer(u['text']):
                family = re.sub(r'r\d+$', '', m.group(), flags=re.I).upper()
                literal_occurrences.append({'source_id': u['id'], 'literal': m.group(), 'family': family,
                                            'span': [m.start(), m.end()], 'protected_family': family in protected})
        referenced = sorted({f for u in cr['units'] for f in SPEC.findall(u['text'])})
        matches = sorted({o['family'] for o in literal_occurrences} & prior_families)
        audit.append({'case': c['id'], 'selection': c['selection'],
                      'CR_native': cr['native'], 'WG_TSG_native_byte_identity': cr['WG_TSG_native_byte_identity'],
                      'prior_CR_native_byte_match': cr['native']['sha256'] in prior_natives,
                      'prior_TSG_package_byte_match': s['archives']['tsg']['sha256'] in prior_packages,
                      'literal_tdoc_occurrences': literal_occurrences,
                      'prior_library_literal_family_overlap': matches,
                      'referenced_specifications_in_CR_text': referenced,
                      'known_exposed_specification_references': sorted(set(referenced) & set(selection['excluded_specifications'])),
                      'protected_literal_families': sorted({o['family'] for o in literal_occurrences if o['protected_family']}),
                      'source_preparation': executor.bind(case / 'source_preparation.json'),
                      'covers': [{'role': e['role'], 'version': e['version'], 'identity': e['cover_identity']} for e in preparation['endpoints']],
                      'independent_component_certified': False,
                      'implicit_semantic_or_training_dependencies_certified': False})
    executor.save(OUT / 'dependency_audit.json', {
        'state': 'ACTUAL_CR_PACKAGE_AND_LITERAL_DEPENDENCIES_AUDITED_BEFORE_OUTPUTS',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
        'selection': executor.bind(OUT / 'selection.json'),
        'historical_metadata': [executor.bind(LIB / n) for n in ('rows.json', 'documents.json')],
        'prior_extra_CR': executor.bind(AREA / 'priority7-new-component-diagnostic/cr_preparation.json'),
        'cases': audit, 'evaluation_split_created': False, 'independent_components_certified': False,
        'scope': 'Native and TSG package hashes compared to the648-row library plus P7; original reference-family metadata and new CR literal text scanned. No protected email body opened. Shared general specification references and unobserved semantic/training dependencies are not ruled out.',
        'model_calls': 0, 'protected_email_family_bodies_opened': 0})
    primary = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/reviews/priority-sequence/priority-9/packet/primary'
    executor.save(OUT / 'primary_recomparison.json', {
        'state': 'ROOT_PRIMARY_ORIGINALS_RECOMPARED_AT_ACTION_STUDY_ADOPTION',
        'created_utc': executor.now(),
        'papers': [
            {'title': 'DeepSpecs', 'url': 'https://aclanthology.org/2026.findings-acl.1343/',
             'original': executor.bind(primary / 'deepspecs.pdf'), 'root_direct_read': 'PDF pages4–5, sections3.2–3.5 and Figures1–2',
             'common': 'Native clause/version indexing, observed line changes and CR rationale linking already exist.',
             'difference_to_test': 'Source presence and proposal-versus-observed authority govern a subsequent action, including retained conditions.',
             'unverified': 'No faithful reproduction, general superiority or new version-linking principle.'},
            {'title': 'CR-Eval', 'url': 'https://arxiv.org/html/2507.04214v2',
             'original': executor.bind(primary / 'cr_eval.pdf'), 'root_direct_read': 'PDF pages3–4, sections3.1–3.5',
             'common': 'CR original/revised statements, rationale and structured requests/references are established.',
             'difference_to_test': 'Source-supported decision completion and appropriate action under observed input allocation, including editorial cases and justified unknowns.',
             'unverified': 'No expert-gold equivalence or reproduction of weakness discovery and human-validated judging.'},
            {'title': 'RAGonite', 'url': 'https://arxiv.org/html/2412.10571v2',
             'root_direct_read': 'Original HTML sections4–5, lines90–142',
             'common': 'Table/neighbor contextualization and evidence removal with redundancy controls are established.',
             'difference_to_test': 'Observed version and conditional decision preservation, then action utility rather than answer-similarity attribution.',
             'unverified': 'No new evidence-ablation/attribution principle or causal generalization.'},
            {'title': 'FLARE', 'url': 'https://arxiv.org/html/2305.06983',
             'root_direct_read': 'Original HTML sections2.3–3.2.1, lines106–130',
             'common': 'Choosing retrieval and regeneration from information need is established.',
             'difference_to_test': 'Automatic recommendations from actual scoped source roles/presence distinguish acquisition, reconsideration, retention and catalogue-absent evidence.',
             'unverified': 'No faithful FLARE reproduction or new general adaptive retrieval principle.'},
            {'title': 'Self-RAG', 'url': 'https://arxiv.org/html/2310.11511',
             'root_direct_read': 'Original HTML section3.3, lines249–254',
             'common': 'Adaptive retrieval and support/utility critique are established.',
             'difference_to_test': 'A frozen one-action development workflow with source-scoped conditions and literal provenance, without training reflection tokens.',
             'unverified': 'No learned-reflection novelty or faithful Self-RAG comparison.'}
        ],
        'adopted_scope': 'A controlled operational test of source-scoped next-action value, not a claim that adaptive retrieval itself is new.',
        'falsifiers': ['All intact explicit requests already succeed; preserve that ceiling.',
                       'Always ask resolves the withheld target observations without supplied observed target evidence.',
                       'Source-aware recommendations choose inappropriate actions or fail to preserve conditions.',
                       'Any apparent benefit disappears when shared initial/diagnosis and source costs are included.'],
        'model_calls': 0})
    print(json.dumps({'state': 'P10_PRE_OUTPUT_DEPENDENCY_AND_PRIOR_AUDIT_READY',
                      'cases': [{k: c[k] for k in ('case', 'prior_CR_native_byte_match', 'prior_TSG_package_byte_match', 'prior_library_literal_family_overlap', 'known_exposed_specification_references', 'protected_literal_families')} for c in audit]}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
