#!/usr/bin/env python3
"""Portable saved-input, first-call, recommendation and cost replay; no inference.

Uses the unchanged standard-library P9 provenance helpers. Does not rerender
native documents, judge semantics, certify independent cases or historical
absence of unseen executions. Normal and optimized Python use explicit checks.
"""
from collections import Counter, defaultdict
import json
from pathlib import Path
import sys

import verify_source_decision_resource as provenance

require, read, digest = provenance.require, provenance.read, provenance.digest
VARIANTS = ('source_aware', 'always_ask', 'always_acquire')
FIELDS = ('input_tokens', 'cached_input_tokens', 'cache_write_input_tokens',
          'output_tokens', 'reasoning_output_tokens')


def verify(package):
    package = Path(package).resolve()
    manifest = read(package / 'manifest.json')
    listed = set()
    for record in manifest['files']:
        require(record['path'] not in listed, 'Duplicate manifest member')
        listed.add(record['path'])
        path = provenance.safe_path(package, record['path'])
        require(digest(path) == {k: record[k] for k in ('bytes', 'sha256')}, 'Manifest mismatch')
    actual = {str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}
    require(actual == listed | {'manifest.json'}, 'Unlisted or missing package member')
    locators = read(package / 'source_locators.json')

    def bound(binding):
        require(binding['path'] in locators, 'Missing distributed binding: ' + binding['path'])
        path = provenance.safe_path(package, locators[binding['path']])
        require(digest(path) == provenance._hash_fields(binding), 'Bound artifact mismatch')
        return path

    def check_answer(binding, body):
        answer = read(bound(binding))
        require([a['id'] for a in answer['answers']] == ['Q1', 'Q2', 'Q3'], 'Answer ID/order differs')
        sources = {u['id']: u['text'] for u in body['supplied_sources']}
        quotes = 0
        for a in answer['answers']:
            require(isinstance(a['answer'], str) and bool(a['answer'].strip()), 'Empty answer')
            require(a['next_action'] in ('ACQUIRE', 'ASK', 'RETAIN', 'KEEP_UNKNOWN'), 'Invalid action')
            require(isinstance(a['action_reason'], str), 'Invalid action reason')
            require(isinstance(a['established_facts'], list) and isinstance(a['missing_information'], list), 'Invalid answer fields')
            for cite in a['evidence']:
                require(cite['source_id'] in sources and bool(cite['quote'])
                        and cite['quote'] in sources[cite['source_id']], 'Literal quote defect')
                quotes += 1
        return answer, quotes

    def inspect_call(binding, input_binding, plan):
        result_path = bound(binding)
        result = read(result_path)
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER' and result['returncode'] == 0
                and result['timed_out'] is False, 'Incomplete or uncontrolled first turn')
        audit = provenance.inspect_events(bound(result['events']), bound(result['answer']))
        for key, value in audit.items():
            require(result[key] == value, 'Saved result differs from raw event provenance')
        dispatch = read(result_path.parent / 'dispatch.json')
        provenance.inspect_dispatch(dispatch, plan, {'input': input_binding}, plan['policies']['answer'], result['answer'])
        usage = audit['turn_completed_events'][0]['usage']
        return result, {'model_calls': 1, **{k: usage.get(k, 0) for k in FIELDS},
                        'observed_seconds': result['elapsed_seconds']}

    def add_cost(rows):
        return {key: sum(r[key] for r in rows) for key in ('model_calls', *FIELDS, 'observed_seconds')}

    plan = read(package / 'protocol.json')
    for binding in plan['dependencies'] + list(plan['policies'].values()):
        bound(binding)
    accounting = read(package / 'completed_first_call_accounting.json')
    require(accounting['protocol'] == {'path': next(k for k, v in locators.items() if v == 'protocol.json'),
                                     **digest(package / 'protocol.json')}, 'Accounting protocol differs')
    all_calls, all_answers, policy_costs = {}, {}, defaultdict(list)
    workflow_index = {(w['job'], w['variant']): w for w in accounting['workflows']}
    require(len(workflow_index) == len(plan['jobs']) * len(VARIANTS), 'Duplicated or missing workflows')
    workflow_count = 0
    for job in plan['jobs']:
        body = read(bound(job['input']))
        require(set(body) == {'questions', 'source_inventory', 'supplied_sources', 'phase'}, 'Undeclared initial input field')
        require(body['phase'] == 'initial' and [q['id'] for q in body['questions']] == ['Q1', 'Q2', 'Q3'], 'Initial phase/questions differ')
        scope = read(bound(job['scope']))
        pool = read(bound(scope['parent_pool']))
        expected_scope = []
        for u in pool['units']:
            if u['role'] == 'CR' and u['clause'] is None:
                expected_scope.append(u)
            elif u['clause'] == scope['request_clause']:
                if not scope['entry_labels'] or u['kind'] == 'paragraph':
                    expected_scope.append(u)
                elif u.get('cells'):
                    lines = (u['cells'][0]['after'] or u['cells'][0]['before']).splitlines()
                    key = lines[0].strip() if lines else ''
                    if key in scope['entry_labels'] or u['row'] == 0:
                        expected_scope.append(u)
        require(scope['units'] == expected_scope, 'Question-scope source projection differs')
        full = [{k: u[k] for k in ('id', 'role', 'version', 'clause', 'text')} for u in expected_scope]
        available = full if job['allocation'] == 'intact' else [u for u in full if u['role'] != 'target']
        require(body['supplied_sources'] == available, 'Initial source allocation differs')
        require(sum(len(u['text']) for u in available) == job['source_characters'], 'Source characters differ')
        ops_locator = next(k for k in locators if k.endswith('/predictions/' + job['id'] + '.operations.json'))
        operations = read(provenance.safe_path(package, locators[ops_locator]))
        initial, initial_cost = inspect_call(operations['initial'], job['input'], plan)
        answer, _ = check_answer(initial['answer'], body)
        all_calls[operations['initial']['path']] = initial_cost
        all_answers[initial['answer']['path']] = (initial['answer'], body)
        actions = [a['next_action'] for a in answer['answers']]
        require(operations['recommended_actions'] == actions, 'Recommendations differ from first answer')
        source_action = 'ACQUIRE' if 'ACQUIRE' in actions else 'ASK' if 'ASK' in actions else 'STOP'
        require([o['variant'] for o in operations['operations']] == list(VARIANTS), 'Policy order differs')
        shared = Counter(o['result']['path'] for o in operations['operations'] if o['additional_calls'])
        require(operations['physical_followup_calls'] == len(shared), 'Unique physical call count differs')
        for op in operations['operations']:
            require(op['action'] == {'source_aware': source_action, 'always_ask': 'ASK', 'always_acquire': 'ACQUIRE'}[op['variant']], 'Frozen recommendation not applied')
            charges = [initial_cost]
            if op['action'] == 'STOP':
                require(op['additional_calls'] == 0 and op['result'] == operations['initial']
                        and op['answer'] == initial['answer'] and op['acquired_source_characters'] == 0, 'STOP changed or double charged')
                actual_shared = False
            else:
                require(op['additional_calls'] == 1, 'More than one follow-up action')
                later = read(bound(op['input']))
                expected_units = full if op['action'] == 'ACQUIRE' else available
                expected_body = {**body, 'supplied_sources': expected_units, 'phase': 'follow-up',
                    'prior_answer': answer,
                    'instruction': 'Reassess the same explicit Q1,Q2,Q3 against the supplied sources. Preserve supported facts and correct any missing detail or scope promotion. Prior answer is not evidence.'}
                require(later == expected_body, 'Follow-up input or information differs')
                result, charge = inspect_call(op['result'], op['input'], plan)
                require(result['answer'] == op['answer'], 'Follow-up answer binding differs')
                check_answer(op['answer'], later)
                all_calls[op['result']['path']] = charge
                all_answers[op['answer']['path']] = (op['answer'], later)
                charges.append(charge)
                have = {u['id'] for u in available}
                acquired = sum(len(u['text']) for u in expected_units if u['id'] not in have)
                require(op['acquired_source_characters'] == acquired, 'Acquired source volume differs')
                actual_shared = shared[op['result']['path']] > 1
            cost = add_cost(charges)
            workflow = workflow_index[(job['id'], op['variant'])]
            require(workflow['cost'] == cost and workflow['actual_physical_followup_shared'] == actual_shared
                    and workflow['final_result'] == op['result'] and workflow['final_answer'] == op['answer'], 'Workflow cost/sharing/output differs')
            policy_costs[op['variant']].append(cost)
            workflow_count += 1
    quotes = sum(check_answer(binding, body)[1] for binding, body in all_answers.values())
    require(accounting['physical_unique_calls'] == add_cost(list(all_calls.values())), 'Physical total differs')
    require(accounting['logical_policy_cost'] == {v: add_cost(policy_costs[v]) for v in VARIANTS}, 'Logical total differs')
    require(accounting['physical_unique_literal_quotes'] == quotes, 'Literal quote count differs')
    return {'state': 'OFFLINE_FIRST_RETURN_INPUT_ACTION_COST_AND_LITERAL_PROVENANCE_PASS',
        'manifest_files': len(listed) + 1, 'initial_allocations': len(plan['jobs']),
        'logical_workflows': workflow_count, 'unique_model_calls': len(all_calls),
        'literal_quotes': quotes, 'literal_defects': 0, 'model_calls_during_replay': 0,
        'native_projection_rerun': False, 'meaning_certified': False,
        'independent_semantic_gold': False, 'unobserved_execution_absence_certified': False}


if __name__ == '__main__':
    print(json.dumps(verify(sys.argv[1] if len(sys.argv) > 1 else '.'), indent=2))
