#!/usr/bin/env python3
"""Offline mechanical replay. Semantic coverage labels are author interpretations."""
import hashlib
import json
from pathlib import Path
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def safe(root, name):
    p = Path(name)
    require(not p.is_absolute() and '..' not in p.parts and p.as_posix() == name,
            'Noncanonical relative member')
    path = root / p
    require(path.is_file() and not any(x.is_symlink() for x in (path, *path.parents))
            and path.resolve().is_relative_to(root), 'Missing, linked or escaped member')
    return path


def verify(root):
    root = root.resolve()
    manifest = read(safe(root, 'manifest.json'))
    expected = {x['path']: {k: x[k] for k in ('bytes', 'sha256')} for x in manifest['files']}
    require(len(expected) == len(manifest['files']) and 'manifest.json' not in expected,
            'Duplicate/self-referential member')
    observed = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    require(observed == set(expected) | {'manifest.json'}, 'Unexpected or missing members')
    for name, binding in expected.items():
        require(digest(safe(root, name)) == binding, 'Changed file: ' + name)
    record = read(safe(root, 'record.json'))
    spec = read(safe(root, 'specification.json'))
    require(record['schema'] == spec['schema_id'] == 'QUALIFIED_CLAIM_DIAGNOSTIC_RECORD_V1',
            'Record/specification identity differs')
    pool = read(safe(root, 'sources/pool.json'))
    units = {x['id']: x for x in pool['units']}
    require(len(units) == len(pool['units']), 'Duplicate occurrence IDs')
    requirement = record['qualified_claim']['frozen_requirement']
    original = read(safe(root, 'sources/author_reference.json'))
    matched = [x for x in original['requirements'] if x['key'] == requirement['key']]
    require(len(matched) == 1 and matched[0] == requirement, 'Frozen requirement changed')
    checks = []
    inputs = [record['source_inventory']['first_input']] + [
        x['input_path'] for x in record['physical_calls'] if x['stage'] != 'first']
    for witness in record['source_inventory']['selected_witnesses']:
        unit = units[witness['source_id']]
        require(unit == witness['source_unit'], 'Source unit changed')
        require(unit['id'] in requirement['source_occurrences'], 'Witness outside frozen requirement')
        require(all(unit['id'] in safe(root, name).read_text(encoding='utf-8')
                    and unit['text'] in safe(root, name).read_text(encoding='utf-8')
                    for name in inputs), 'Witness not supplied to a saved call')
        checks.append({'source_id': unit['id'], 'available': True,
                       'supplied_to_all_six_saved_calls': True})
    calls = {}
    for row in record['physical_calls']:
        result = read(safe(root, row['result_path']))
        answer = safe(root, row['answer_path']).read_text(encoding='utf-8')
        require(result['returncode'] == 0 and not result['timed_out']
                and {k: result['answer'][k] for k in ('bytes', 'sha256')} == digest(safe(root, row['answer_path'])), 'Saved result/answer mismatch')
        turns = result['turn_completed_events']
        require(len(turns) == 1 and turns[0]['usage'] == row['raw_provider_usage'],
                'Provider usage differs')
        require(result['elapsed_seconds'] == row['request_seconds'], 'Request time differs')
        calls[row['stage']] = row
    sums = {}
    for workflow in record['action_and_charge']['logical_workflows']:
        members = [calls[s] for s in workflow['stages']]
        total = {k: sum(x['raw_provider_usage'][k] for x in members)
                 for k in ('input_tokens', 'output_tokens', 'cached_input_tokens',
                           'reasoning_output_tokens')}
        seconds = sum(x['request_seconds'] for x in members)
        require(total == workflow['provider_usage_sum'] and abs(seconds - workflow['request_seconds_sum']) < 1e-8,
                'Full workflow charges differ')
        require(workflow['calls'] == len(members), 'Logical call count differs')
        sums[workflow['policy']] = {'calls': len(members), **total,
                                   'request_seconds_sum': seconds}
    require(len(calls) == 6 and sum(x['calls'] for x in sums.values()) == 9,
            'Physical/logical denominators differ')
    for stage, action in [('triage', 'Retain'), ('audit', 'Ask explicitly')]:
        answer = read(safe(root, calls[stage]['answer_path']))
        q2 = [x for x in answer['decisions'] if x['id'] == 'Q2']
        require(len(q2) == 1 and q2[0]['action'] == action
                and q2[0] == record['action_and_charge'][stage + '_Q2'], 'Actual Q2 action differs')
    for stage, statement in record['substantive_coverage']['returns'].items():
        answer = read(safe(root, calls[stage]['answer_path']))
        q2 = [x for x in answer['answers'] if x['id'] == 'Q2']
        require(len(q2) == 1 and q2[0] == statement['Q2_raw'], 'Substantive Q2 fields differ')
    return {'state': 'OFFLINE_DIAGNOSTIC_BINDING_SUPPLY_ACTION_COST_REPLAY_PASS',
            'files_hashed': len(expected), 'source_pool_occurrences': len(units),
            'selected_condition_witnesses': checks, 'physical_calls': len(calls),
            'dependent_logical_charges': 9, 'logical_workflows': sums,
            'new_model_calls': 0, 'semantic_labels_rejudged': False,
            'whole_response_support_certified': False,
            'native_document_rendering_certified': False,
            'independent_expert_gold': False}


if __name__ == '__main__':
    require(len(sys.argv) == 2, 'Usage: python3 -B verify.py PACKAGE_DIRECTORY')
    print(json.dumps(verify(Path(sys.argv[1])), ensure_ascii=False, indent=2))
