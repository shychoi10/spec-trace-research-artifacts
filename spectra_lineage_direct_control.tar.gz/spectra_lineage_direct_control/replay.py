"""Package/replay completed direct-control evidence; standard library, no inference."""
import argparse
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import tempfile

IDS = [f'LQ{i:02}' for i in range(1, 15)]
DATA = Path('logs/publication/paper/ongoing/kdd-2027-research/codex/rebuild/issue_lineage_generation')
DOCS = Path('docs/publication/paper/ongoing/kdd-2027-research/codex/rebuild')
SCRIPTS = Path('scripts/publication/paper/ongoing/kdd-2027-research/codex/rebuild')
CITATION_RECORD = 'direct_control_citation_mechanics_LQ01_LQ14'
COST_RECORD = 'completed_request_cost_readout_LQ01_LQ14'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_text())


def verify(folder):
    manifest = read(folder / 'manifest.json')
    require(manifest['kind'] == 'completed_direct_control_saved_artifact_replay', 'Wrong package kind')
    actual = {str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file()}
    require(actual == set(manifest['files']) | {'manifest.json'}, 'Package file set differs')
    for name, binding in manifest['files'].items():
        pure = PurePosixPath(name)
        require(not pure.is_absolute() and '..' not in pure.parts, 'Unsafe member path')
        path = folder / name
        require(not path.is_symlink(), 'Symlink is not a packaged regular file')
        raw = path.read_bytes()
        require(len(raw) == binding['bytes'] and digest(raw) == binding['sha256'], 'File differs: ' + name)
    frozen = read(folder / 'frozen_inputs.json')
    completed = read(folder / 'completion.json')
    require(completed['status'] == 'GENERATIONS_COMPLETE_NOT_SEMANTIC_EVALUATION', 'Control incomplete')
    require(completed['frozen_inputs_sha256'] == digest((folder / 'frozen_inputs.json').read_bytes()), 'Freeze differs')
    for field, name in [('source_units_sha256', 'source_units.json'),
                        ('producer_sha256', 'provenance/run_issue_lineage_generation.py'),
                        ('protocol_sha256', 'provenance/issue_lineage_generation_protocol.md'),
                        ('runtime_verification_sha256', 'runtime_verification.json'),
                        ('runtime_launch_sha256', 'runtime_launch.json'),
                        ('synthetic_smoke_sha256', 'synthetic_smoke.json')]:
        require(frozen[field] == digest((folder / name).read_bytes()), 'Frozen binding differs: ' + field)
    require([r['id'] for r in frozen['inputs']] == IDS, 'Must retain all fourteen questions')
    require([r['id'] for r in completed['responses']] == IDS, 'Response denominator differs')
    response_hashes = {r['id']: r['sha256'] for r in completed['responses']}
    source_units = read(folder / 'source_units.json')
    units = {u['id']: u for u in source_units}
    require(len(units) == len(source_units), 'Duplicate source unit')
    reviews = [json.loads(line) for line in (folder / 'development_reviews.jsonl').read_text().splitlines()]
    citation = [r for r in reviews if r.get('record_id') == CITATION_RECORD]
    costs = [r for r in reviews if r.get('record_id') == COST_RECORD]
    require(len(citation) == len(costs) == 1, 'Missing or duplicate saved readout')
    rows = []
    cost = dict(prompt_ms=0.0, decode_ms=0.0, request_wall_seconds=0.0, input_tokens=0, generated_tokens=0)
    for entry in frozen['inputs']:
        qid = entry['id']
        require(entry['path'] == f'inputs/{qid}.json', 'Unexpected input path')
        inp = read(folder / entry['path'])
        ip_sha = digest((folder / entry['path']).read_bytes())
        rp_sha = digest((folder / f'responses/{qid}.json').read_bytes())
        request_raw = (folder / f'requests/{qid}.json').read_bytes()
        request = json.loads(request_raw)
        wrapper = read(folder / f'responses/{qid}.json')
        response = wrapper['response']
        saved = read(folder / f'checks/{qid}.json')
        require(ip_sha == entry['sha256'] == request['input_sha256'] == saved['input_sha256'], qid + ': input binding')
        require(rp_sha == response_hashes[qid] == saved['response_sha256'], qid + ': response binding')
        require(digest(request_raw) == wrapper['request_sha256'], qid + ': request binding')
        require(request['request']['prompt'] == inp['prompt_tokens'], qid + ': consumed tokens differ')
        require(all(request['request'][k] == v for k, v in frozen['settings'].items()), qid + ': settings differ')
        require(len(inp['prompt_tokens']) == entry['tokens'] == response['tokens_evaluated'], qid + ': token count')
        require(response['stop_type'] == 'eos' and response['truncated'] is False, qid + ': abnormal termination')
        selected = {g['occurrence_ids'][0]: g['occurrence_ids'] for g in inp['ranking'][:inp['selected_groups']]}
        require([u for group in selected.values() for u in group] == inp['selected_occurrence_ids'], qid + ': occurrences differ')
        answer = json.loads(response['content'])
        evidence, claims = answer['evidence'], answer['claims']
        literal = []
        for item in evidence:
            quote = item.get('quote')
            occurrence_ids = selected.get(item.get('chunk_id'), [])
            literal.append(bool(isinstance(quote, str) and quote and any(
                quote in part['text'] for uid in occurrence_ids for part in units[uid]['parts'])))
        prior = {b['evidence_index']: bool(b['matches']) for b in saved['literal_bindings']}
        require(literal == [prior.get(i, False) for i in range(len(evidence))], qid + ': literal replay differs')
        valid, bound = [], []
        for claim in claims:
            refs = claim.get('evidence_indices')
            ok = isinstance(refs, list) and bool(refs) and all(type(i) is int and 0 <= i < len(evidence) for i in refs)
            valid.append(ok)
            bound.append(bool(ok and all(literal[i] for i in refs)))
        rows.append(dict(id=qid, input_sha256=ip_sha, response_sha256=rp_sha,
            check_sha256=digest((folder / f'checks/{qid}.json').read_bytes()),
            claims=len(claims), claims_with_valid_indices=sum(valid),
            claims_with_valid_indices_and_all_exact_quotes=sum(bound), evidence_entries=len(evidence),
            evidence_entries_exact_in_named_selected_group=sum(literal),
            invalid_index_claim_positions=[i for i, v in enumerate(valid) if not v],
            nonliteral_evidence_positions=[i for i, v in enumerate(literal) if not v]))
        timing = response['timings']
        require(timing['prompt_n'] == response['tokens_evaluated'] and timing['predicted_n'] == response['tokens_predicted'], qid + ': timing count')
        cost['prompt_ms'] += timing['prompt_ms']
        cost['decode_ms'] += timing['predicted_ms']
        cost['request_wall_seconds'] += (datetime.datetime.fromisoformat(wrapper['completed_utc']) - datetime.datetime.fromisoformat(request['started_utc'])).total_seconds()
        cost['input_tokens'] += response['tokens_evaluated']
        cost['generated_tokens'] += response['tokens_predicted']
    require(rows == citation[0]['question_rows'], 'Citation readout differs')
    totals = {k: sum(r[k] for r in rows) for k in ('claims', 'claims_with_valid_indices',
        'claims_with_valid_indices_and_all_exact_quotes', 'evidence_entries', 'evidence_entries_exact_in_named_selected_group')}
    totals.update(questions=len(rows), questions_with_any_invalid_claim_indices=sum(bool(r['invalid_index_claim_positions']) for r in rows),
                  questions_with_any_nonliteral_evidence=sum(bool(r['nonliteral_evidence_positions']) for r in rows))
    require(totals == citation[0]['totals'], 'Citation totals differ')
    for key, value in cost.items():
        require(abs(value - costs[0]['completed_request_totals'][key]) < 0.000001, 'Cost readout differs: ' + key)
    cost = {k: round(v, 6) if isinstance(v, float) else v for k, v in cost.items()}
    return dict(status='PASS_SAVED_ARTIFACT_REPLAY', files=len(manifest['files']), questions=len(rows),
        citation_mechanics=totals, completed_request_cost=cost, new_model_requests=0,
        semantic_accuracy=None, independent_human_labels=0,
        scope='Packaged bytes, frozen input/request/response bindings, literal/index checks and stored request costs. '
              'No retokenization, reranking, fresh inference, raw-source projection or semantic adjudication. '
              'UTC request duration is not a controlled throughput benchmark.')


def package(root, target, report):
    require(not target.exists() and not report.exists(), 'Preserve completed release artifacts')
    source = root / DATA
    files = {}
    paths = ['frozen_inputs.json', 'completion.json', 'source_units.json', 'development_reviews.jsonl',
             'runtime_launch.json', 'runtime_verification.json', 'synthetic_smoke.json',
             'model_source_metadata.json', 'runtime_source_metadata.json']
    paths += [f'{kind}/{qid}.json' for kind in ('inputs', 'requests', 'responses', 'checks') for qid in IDS]
    origins = {name: source / name for name in paths}
    origins['provenance/run_issue_lineage_generation.py'] = root / SCRIPTS / 'run_issue_lineage_generation.py'
    origins['provenance/issue_lineage_generation_protocol.md'] = root / DOCS / 'issue_lineage_generation_protocol.md'
    origins['replay.py'] = Path(__file__).resolve()
    for name, path in origins.items():
        files[name] = path.read_bytes()
    files['README.md'] = b'''# Completed direct-control replay

Local release candidate, not an uploaded benchmark. From this extracted directory run:

    python3 -B replay.py verify --bundle .

Python 3.11+ standard library only; no model, GPU, network or repository is required.
The command verifies every included file, all fourteen frozen input/request/response
bindings, consumed token IDs, generation settings, saved literal/index checks and costs.
It reproduces the recorded mechanical citation readout, including errors. PASS denotes
faithful replay, not correct generated answers. It does not verify semantic entailment.

Included are 1,506 derived text units from the exposed development family, all fourteen
consumed prompts/token lists, requests, responses and checks, the development review
ledger snapshot, model/runtime identities, and the frozen generation code/protocol.
The code under provenance retains its repository paths and is not a standalone runner.
The replay command does not execute it. Model weights, runtime binaries, raw email/DOCX
sources, retrieval preparation and source-informed question construction are not bundled
or rerun. Provenance paths outside this package are identities, not included files.

These fourteen questions share one exposed source family. Reviews/references are assistant
development interpretations, not independent human labels. The 38 generated claim objects
and 71 evidence entries are not the 35 requested components or independent samples.
Exact text and valid indices do not certify a claim's scope, speaker, condition or truth.
Nonliteral quotations include formatting and attribution errors, not only invented text.
Costs exclude download/build/load, preparation, review and the later extraction experiment.
Wall times use saved UTC timestamps, not controlled-load monotonic benchmarking.

No candidate extraction/comparison outputs or reserved-family source contents are included.
No method advantage, independent evaluation, fresh inference, public upload or external
download verification is claimed. Source identities are retained for attribution; this
package does not invent a license over third-party records. The original experiment used
Qwen3-8B Q4_K_M and llama.cpp at the revisions and hashes recorded in the protocol/metadata.
'''
    manifest = dict(kind='completed_direct_control_saved_artifact_replay', public_upload=False,
        external_download_tested=False, independent_human_labels=0,
        files={name: dict(bytes=len(raw), sha256=digest(raw)) for name, raw in sorted(files.items())})
    files['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    with tempfile.TemporaryDirectory(prefix='kdd-lineage-release-') as temporary:
        temp = Path(temporary)
        archive_path = temp / 'candidate.tar.gz'
        with archive_path.open('xb') as stream:
            with gzip.GzipFile(fileobj=stream, filename='', mode='wb', mtime=0) as zipped:
                with tarfile.open(fileobj=zipped, mode='w') as archive:
                    for name, raw in sorted(files.items()):
                        info = tarfile.TarInfo('spectra_lineage_direct_control/' + name)
                        info.size, info.mode, info.mtime = len(raw), 0o644, 0
                        archive.addfile(info, io.BytesIO(raw))
        with tarfile.open(archive_path) as archive:
            archive.extractall(temp / 'unpacked', filter='data')
        folder = temp / 'unpacked/spectra_lineage_direct_control'
        run = subprocess.run([sys.executable, '-B', 'replay.py', 'verify', '--bundle', '.'],
                             cwd=folder, capture_output=True, text=True, check=True)
        result = json.loads(run.stdout)
        require(all(path.read_bytes() == files[name] for name, path in origins.items()), 'Source changed during packaging')
        archive_bytes = archive_path.read_bytes()
        with target.open('xb') as stream:
            stream.write(archive_bytes)
        record = dict(archive=str(target), sha256=digest(archive_bytes), bytes=len(archive_bytes),
            archive_members=len(files), outside_repository_replay=result,
            producer_sha256=digest(Path(__file__).read_bytes()), public_upload=False,
            external_download_tested=False, fresh_inference_rerun=False)
        with report.open('x') as stream:
            json.dump(record, stream, indent=2)
            stream.write('\n')
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    check = commands.add_parser('verify')
    check.add_argument('--bundle', type=Path, default=Path('.'))
    pack = commands.add_parser('package')
    pack.add_argument('--root', type=Path, required=True)
    pack.add_argument('--output', type=Path, required=True)
    pack.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    result = verify(args.bundle.resolve()) if args.command == 'verify' else package(args.root.resolve(), args.output, args.report)
    print(json.dumps(result, sort_keys=True))


if __name__ == '__main__':
    main()
