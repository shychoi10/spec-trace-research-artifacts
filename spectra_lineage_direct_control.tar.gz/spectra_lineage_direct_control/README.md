# Completed direct-control replay

Local release candidate, not an uploaded benchmark. From this extracted directory run:

    python3 -B replay.py verify --bundle .

Python 3.11+ standard library only; no model, GPU, network or repository is required.
The command verifies every included file, all fourteen frozen input/request/response
bindings, consumed token IDs, generation settings, saved literal/index checks and costs.
It reproduces the recorded mechanical citation readout, including errors. PASS denotes
faithful replay, not correct generated answers. It does not verify semantic entailment.

Included are 1,506 derived text units from the exposed development family, all fourteen
consumed prompts/token lists, requests, responses and checks, the development review
ledger snapshot, model/runtime identities, and the frozen generation code/protocol.
The code under provenance retains its repository paths and is not a standalone runner.
The replay command does not execute it. Model weights, runtime binaries, raw email/DOCX
sources, retrieval preparation and source-informed question construction are not bundled
or rerun. Provenance paths outside this package are identities, not included files.

These fourteen questions share one exposed source family. Reviews/references are assistant
development interpretations, not independent human labels. The 38 generated claim objects
and 71 evidence entries are not the 35 requested components or independent samples.
Exact text and valid indices do not certify a claim's scope, speaker, condition or truth.
Nonliteral quotations include formatting and attribution errors, not only invented text.
Costs exclude download/build/load, preparation, review and the later extraction experiment.
Wall times use saved UTC timestamps, not controlled-load monotonic benchmarking.

No candidate extraction/comparison outputs or reserved-family source contents are included.
No method advantage, independent evaluation, fresh inference, public upload or external
download verification is claimed. Source identities are retained for attribution; this
package does not invent a license over third-party records. The original experiment used
Qwen3-8B Q4_K_M and llama.cpp at the revisions and hashes recorded in the protocol/metadata.
