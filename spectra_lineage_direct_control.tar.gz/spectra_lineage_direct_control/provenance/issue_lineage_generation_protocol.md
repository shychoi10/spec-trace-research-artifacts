# Local generative control for the exposed issue-lineage questions

This is an existing-model control, not a proposed method or a new evaluation
cohort. It answers all 14 already exposed development questions from the
[source-bound review packet](issue_lineage_findings.md). All questions concern
one family, `RAN4/0554f42f62e86d6c`, and were authored after source inspection.
The 87 reserved families remain closed. Human annotations remain zero; model
outputs must not be placed in the independent human annotation packet.

The concrete gap is a joint answer that preserves subject, conditions, speaker,
record role and evidence across the supplied records. Completed BM25/BGE/DYLE
retrieval, LEDA dialogue-act transfer and the constructed NLI checks do not
provide that control. This experiment introduces no new research direction,
novelty claim, independent test, relation-accuracy estimate or result of a
comparison with our own method. It does not tune the earlier 27 questions or
20 NLI claims. Close task comparisons remain in [prior_art.md](prior_art.md).

## Model and execution fixed before target outputs

Use the official [Qwen3-8B GGUF](https://huggingface.co/Qwen/Qwen3-8B-GGUF)
`Q4_K_M` file at revision `7c41481f57cb95916b40956ab2f0b139b296d974`.
Its expected size is 5,027,783,488 bytes and its official LFS SHA-256 is
`d98cdcbd03e17ce47681435b5150e34c1417f50b5c0019dd560e4882c5745785`.
Quantization and CPU execution make this an available local comparator; they
do not justify calling it the strongest current model. Pretraining exposure to
these public records is unknown. No external inference or embedding API is used.

Use [llama.cpp source](https://github.com/ggml-org/llama.cpp/tree/0c1e57098bba43ac29e6e3b677cdceebdd22334f)
at that exact commit, a local CPU build, four inference/prefill threads and
niceness 15. Bind only to loopback, disable GPU offload and context shifting,
and use one slot. The context is 24,576 tokens, prompt limit 16,384 and maximum
answer 4,096; the remaining space is deliberate headroom. Never silently
truncate an input. The native chat template disables thinking. Sampling is one
draw with seed 42, temperature 0.7, top-p 0.8, top-k 20, min-p 0, presence
penalty 1.5, frequency penalty 0 and repetition multiplier 1. These non-thinking
settings follow the official model card; presence penalties use the whole
available context using `repeat_last_n=24576`, matching the fixed context size.
JSON-object grammar
constrains syntax, not the truth of answers. Prompt cache reuse is disabled.
Save actual runtime settings, input token IDs, raw responses and stop reasons.

The pinned server documentation and implementation were checked for template
application, tokenization, sampling, context limits and response accounting.
The archive build's version banner inherited the enclosing SPECTRA Git metadata;
it is not the runtime source identity. `runtime_verification.json` discloses this
and binds the official source archive/commit and actual binary hashes separately.
A neutral arithmetic request verifies template/JSON transport before consuming
any real question. It is not a research result or a prompt-selection exercise.

## Source and retrieval contract

The answer-free packet manifest SHA-256 is
`32fd115716d46926c971ff9cf489b19782e252ba5da69efd85e83f18e1b55353`.
Verify every packet file against that manifest. Consume its original email
bodies and native paragraph projection only, without assistant observations.
For each question, filter to its allowed message indices and formal record IDs
before ranking or rendering. These are explicit source restrictions, not a
claim about historical availability.

Split decoded email bodies losslessly into nonoverlapping chunks of at most
1,200 Unicode characters, preferring blank lines, then physical line breaks in
the latter half of a chunk. Preserve exact text and absolute character offsets,
including quoted history. Email sender metadata names the containing message;
it does not identify every quoted speaker. Keep all paragraphs of a native
formal table row together and retain table/row/cell coordinates. Outside a
table, use one paragraph. Preserve ordinary and deleted text as distinct
channels; this is not a final Word rendering or merged-cell interpretation.

Deduplicate only exact sequences of channel/text pairs within the permitted
source set, retaining every source occurrence and location. Rank these text
groups with ordinary BM25 (`k1=1.2`, `b=0.75`), using the complete unmodified
question and lowercase alphanumeric tokens with internal dot/hyphen/underscore
identifiers. There is no learned retriever, query expansion, gold-based source
selection or fitted threshold. Ties use the first stable occurrence ID.

Supply the largest prefix of that ranking fitting the fixed prompt limit,
including instructions, question, all provenance metadata and the chat template.
Actual tokenizer counts determine the boundary before any real answer. Preserve
the complete ranking, selected occurrence IDs and omitted-group counts.
No selected text is clipped. This is a bounded retrieval condition, not full
source consumption. A later method comparison must receive precisely the same
selected evidence and input budget; a larger source set is a separate condition.

Freeze all 14 prompts and token sequences together before the first target
request. The producer, protocol, model, runtime binaries, launch command, source
units and every input file are hash-bound. One completion is allowed per question.
Save an outbound request before execution. An existing request with no saved
response is an uncertain execution, and must not be retried automatically.
Malformed JSON, missing fields, citation errors and length-limited outputs stay
in the results; do not repair them by resampling or tuning the prompt.

## Verification and reporting boundary

The model returns an answer, scoped claims, indexed evidence and explicit
unestablished/ambiguous points. Automatically check cited chunk membership,
exact literal matches, all matching source offsets, channels and claim-reference
indices. Repeated literal matches stay ambiguous; the verifier does not select
an original speaker or establish entailment. The saved consumption count must
equal the frozen prompt token count, with no context truncation.

Synthetic tests exercise out-of-scope messages/formal records, Unicode offsets,
quote mismatch, repeated-text provenance, ordinary/deleted channels, native
table rows, malformed output and refusal to overwrite. These are software
checks only. Semantic correctness, completeness, correct interpretation of
record roles and genuine abstention require source review and independent
annotation; exact quoting alone cannot certify them. No accuracy or human
agreement score is available from this protocol.

### Separate source-loss accounting

`audit_issue_lineage_inputs.py` independently reconstructs every admitted email
body and every nonempty native paragraph/channel from the producer's chunks.
It checks exact offsets, table-row assignments and the full permitted occurrence
set before ranking truncation. The executed projection check covers 32 emails
(590,339 Unicode characters) and 2,792 nonempty formal channels (170,461
characters), in 1,506 units. The 3,231 native paragraphs also contain 3,670 empty
ordinary/deleted channels, which are explicitly omitted. This certifies the
packet-text projection, not complete original attachments or rendered layout.
The result is `source_projection_audit.json`; nine deliberately corrupted
in-memory inputs were rejected in `input_audit_checks.json`.

After prompt freezing, the same auditor records retained and omitted characters
and units for every allowed source in `input_coverage.json`. Counts distinguish
source occurrences from deduplicated text groups. It verifies the selected
ranking prefix, serialized source payload and recorded token-budget count.
It does not independently retokenize the template or measure relevance recall.
The frozen-stage result is pending until that file actually exists. This keeps
retrieval omission distinct from answer interpretation without turning text
coverage into an accuracy score or changing the fixed retrieval condition.

## Artifacts and actual status

Producer: `scripts/publication/paper/ongoing/kdd-2027-research/codex/rebuild/run_issue_lineage_generation.py`.
Tests: adjacent `test_issue_lineage_generation.py`.
Artifacts: `logs/publication/paper/ongoing/kdd-2027-research/codex/rebuild/issue_lineage_generation/`.
`execution_status.json` and the saved files, not this planning text, determine
whether acquisition, prompt freezing, generation or verification has completed.
Acquisition errors and incomplete downloads are retained in the event/log files.
The CPU runtime has built and 16 synthetic source/citation/budget checks have passed.
The initial model stream timed out. A subsequent curl connection reset exposed
another transport problem: its internal retry returned the output to the
invocation's starting offset, discarding newly received bytes. This behavior is
documented under [curl retry-all-errors](https://curl.se/docs/manpage.html#--retry-all-errors).
Both failures and the interrupted downloader are recorded in
`acquisition_events.jsonl` and `model_download.log`.

The adjacent `download_issue_lineage_model.py` resumes the retained prefix using
four concurrent 64-MiB byte-range transfers. Each response must have the exact
requested Content-Range, identity encoding and expected length. A connection
failure preserves received bytes; a new request starts at that segment's actual
end. Completed segments are appended in order and removed after incorporation.
Only the official full-file size and SHA-256 can produce `model_acquisition.json`.
Five synthetic local HTTP checks cover prefix reuse, interrupted transfer,
ignored/incorrect ranges and complete ordered assembly. They do not establish
real model readiness. Actual model acquisition is recorded separately in
`model_acquisition.json`; transport checks are not research results.

### Runtime compatibility correction before target execution

The initial neutral request failed with HTTP 400: the pinned server requires
`repeat_last_n` to be nonnegative and rejected the originally specified `-1`.
The source is `tools/server/server-schema.cpp` lines 126–128 of the pinned
archive. `src/llama-sampler.cpp` retains the last configured number of accepted
tokens for penalties. The correction explicitly supplies the context size,
24,576, which covers the maximum 16,384 prompt plus 4,096 answer tokens.
This implements the intended whole-context penalty window; the rejected
setting produced no target answers. `n_keep=-1` is separately supported by
the server schema and remains unchanged. HTTP error bodies are now retained
in the pipeline exception instead of reporting only the status code.

`runtime_diagnostic/rejection.json` preserves the exact neutral rejection.
`runtime_diagnostic/initial_pipeline_failure.tar.gz` preserves the preceding
producer, auditor, tests, protocol, launch settings and failure logs with an
embedded file-hash manifest. All target input/request/response paths were absent
before this correction. Questions, source packet, retrieval, prompt, model,
seed and all other sampling settings remain fixed. This is a compatibility
repair before target execution, not selection among generated answers.
