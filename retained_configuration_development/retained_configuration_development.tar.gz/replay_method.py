# Exact function exports from the frozen producer.
import json


def serialized(questions, inventory, units):
    return ('QUESTIONS\n' + json.dumps(questions, ensure_ascii=False) +
            '\n\nSOURCE INVENTORY\n' + json.dumps(inventory, ensure_ascii=False) +
            '\n\nSUPPLIED UNITS WITH OCCURRENCES\n' +
            '\n'.join(json.dumps(u, ensure_ascii=False, separators=(',', ':'))
                      for u in units))


def retained_blocks(original, inventory, aliases, contexts):
    """One shared candidate representation for both new allocation rules.

    All labels and rows are supplied native-derived configuration blocks.
    A caption is the last preceding same-clause Table paragraph, not an
    inferred PC2 label. Explicit endpoint occurrences remain in exact-text
    deduplication. We do not certify native layout or configuration semantics.
    """
    units = {u['id']: u for u in original}
    positions = {u['id']: i for i, u in enumerate(original)}
    blocks = []
    for block in inventory['CR_configuration_blocks']:
        rows = [units[r] for r in block['rows'] if r in units]
        if not rows:
            continue
        clauses = {u['clause'] for u in rows}
        tables = {u['table'] for u in rows}
        if len(clauses) != 1 or len(tables) != 1:
            raise ValueError('Ambiguous supplied configuration block')
        clause, table = next(iter(clauses)), next(iter(tables))
        indexes = set().union(*(contexts[aliases[u['id']]] for u in rows))
        first = min(positions[u['id']] for u in rows)
        captions = [u for u in original[:first]
                    if u['document_id'] == rows[0]['document_id'] and
                    u['clause'] == clause and u['kind'] == 'paragraph' and
                    u['text'].lstrip().startswith('Table ')]
        caption = captions[-1] if captions else None
        if caption:
            indexes.add(aliases[caption['id']])
        blocks.append({'first': block['first'], 'clause': clause,
                       'table': table, 'labels': sorted(set(block['configuration_labels'])),
                       'changed': any(u['changed'] for u in rows),
                       'rows': [u['id'] for u in rows],
                       'caption': caption['id'] if caption else None,
                       'bundle': sorted(indexes)})
    edited_clauses = {u['clause'] for u in original
                      if u['role'] == 'CR' and u['changed']}
    retained = [b for b in blocks if not b['changed'] and b['clause'] in edited_clauses]
    alternative = []
    for block in retained:
        matched = [b['first'] for b in blocks if b['changed'] and
                   b['clause'] == block['clause'] and b['table'] != block['table'] and
                   set(b['labels']).intersection(block['labels'])]
        if matched:
            alternative.append({**block, 'matched_changed_blocks': matched})
    return retained, alternative
