#!/usr/bin/env python3
"""Offline retained-configuration allocation and unique saved-answer replay."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True


def read(path):
    return json.loads(path.read_text())


def digest(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def verify(directory):
    manifest = read(directory / 'manifest.json')
    for entry in manifest['files']:
        if digest(directory / entry['path']) != {k: entry[k] for k in ('bytes', 'sha256')}:
            raise ValueError('Package hash differs: ' + entry['path'])
    prior_dir = directory / 'prior'
    prior_verifier = module('prior_resource_verifier', prior_dir / 'verify.py')
    prior_replay = prior_verifier.verify(prior_dir)
    prior = module('prior_allocation_replay', prior_dir / 'replay_method.py')
    prior.executor = prior.PackageReader(prior_dir)
    method = module('retained_allocation_replay', directory / 'replay_method.py')
    formats = read(prior_dir / 'native_run_formats.json')
    unique_answers, conditions, defects = {}, [], []

    def resolve(binding):
        path = binding['path']
        if '/priority5-evidence-acquisition/' in path:
            relative = path.split('/priority5-evidence-acquisition/', 1)[1]
            relative = relative.replace('sources/scoped/', 'sources/').replace('endpoints/scoped/', 'endpoints/')
            result = prior_dir / relative
        else:
            result = directory / path.split('/priority6-retained-configuration-acquisition/', 1)[1]
        if digest(result) != {k: binding[k] for k in ('bytes', 'sha256')}:
            raise ValueError('Observation binding differs: ' + path)
        return result

    for cid in ('row1', 'row23', 'row25'):
        pool = read(prior_dir / 'sources' / (cid + '.pool.json'))
        acquisition = read(directory / 'acquisition' / (cid + '.json'))
        original = pool['units']
        for unit in original:
            unit['explicit_native_run_formats'] = formats['cases'][cid]['units'].get(unit['id'], [])
        unique, aliases = prior.unique_units(original)
        contexts = prior.context_bundles(original, aliases, pool['inventory'])
        baseline, scores, index = prior.ranked_bundles(unique, contexts, acquisition['questions'])
        closure = prior.closure_bundles(original, unique, aliases, contexts, index, baseline)
        retained, alternatives = method.retained_blocks(original, pool['inventory'], aliases, contexts)
        if retained != acquisition['retained_blocks'] or alternatives != acquisition['alternative_blocks']:
            raise ValueError('Structural candidates differ')
        lexical = sorted(retained, key=lambda b: (-max(sum(s[i] for i in b['bundle']) for s in scores), b['first']))
        alternative_order = sorted(alternatives, key=lambda b: b['first'])
        schedules = {'preserved_edit_version': closure,
            'contextual_retained_first': [closure[0]] + [b['bundle'] for b in lexical] + closure[1:],
            'configuration_alternative_first': [closure[0]] + [b['bundle'] for b in alternative_order] + closure[1:]}
        for mode, record in acquisition['modes'].items():
            chosen, used, skipped = prior.pack(schedules[mode], unique, 12000)
            supplied = [unique[i] for i in chosen]
            if [u['id'] for u in supplied] != record['selected_unique_ids'] or used != record['source_characters'] or skipped != record['skipped_bundles']:
                raise ValueError('Allocated source subset differs')
            actual = directory / 'inputs' / (cid + '.' + mode + '.txt')
            if method.serialized(acquisition['questions'], pool['inventory'], supplied) != actual.read_text():
                raise ValueError('Actual input reconstruction differs')
            if digest(actual) != {k: record['input'][k] for k in ('bytes', 'sha256')}:
                raise ValueError('Actual input binding differs')
            if mode == 'preserved_edit_version' and actual.read_bytes() != (prior_dir / 'inputs' / (cid + '.scope_version_closure.txt')).read_bytes():
                raise ValueError('Preserved baseline input changed')
            observation = record['observation']
            if observation['kind'] == 'preserved_first_answer':
                if resolve(observation['input']).read_bytes() != actual.read_bytes():
                    raise ValueError('Inherited input identity differs')
                result_path = resolve(observation['result'])
            else:
                result_path = directory / 'predictions' / observation['job_id'] / 'result.json'
            result = read(result_path)
            if result['state'] != 'SAVED_CONTROLLED_ANSWER':
                raise ValueError('First answer was not controlled')
            answer_path = resolve(result['answer'])
            answer = read(answer_path)
            if [q['id'] for q in answer['answers']] != ['Q1', 'Q2', 'Q3', 'Q4']:
                raise ValueError('Answer question order differs')
            aliases_for_answer = {o['id']: u['text'] for u in supplied for o in u['occurrences']}
            quotes = 0
            for question in answer['answers']:
                for anchor in question['evidence']:
                    quotes += 1
                    if anchor['source_id'] not in aliases_for_answer or not anchor['quote'] or anchor['quote'] not in aliases_for_answer[anchor['source_id']]:
                        defects.append({'case': cid, 'mode': mode, 'question': question['id'], 'anchor': anchor})
            unique_answers.setdefault(str(answer_path.relative_to(directory)), {'kind': observation['kind'], 'quotes': quotes})
            conditions.append({'case': cid, 'mode': mode, 'source_characters': used,
                'input_bytes': actual.stat().st_size, 'observation_kind': observation['kind']})
    if defects:
        raise ValueError('Preserved literal quote defect: ' + json.dumps(defects))
    new = sum(a['kind'] == 'new_first_answer' for a in unique_answers.values())
    if len(conditions) != 9 or len(unique_answers) != 5 or new != 2:
        raise ValueError('Unique first-observation denominator differs')
    if (directory / 'direct_policy.txt').read_bytes() != (prior_dir / 'direct_policy.txt').read_bytes():
        raise ValueError('Inherited policy identity differs')
    return {'state': 'RETAINED_CONFIGURATION_SELECTION_INPUT_AND_LITERAL_QUOTE_REPLAY_PASS',
        'files_checked': len(manifest['files']), 'conditions': conditions, 'new_first_calls': new,
        'unique_first_observations_including_inherited': len(unique_answers),
        'unique_observation_quotes': sum(a['quotes'] for a in unique_answers.values()),
        'literal_defects': [], 'prior_resource_replay': prior_replay,
        'model_calls_for_replay': 0, 'meaning_certified': False, 'native_projection_recomputed': False,
        'limit': 'File hashes, deterministic allocation, nine saved inputs and five unique first answer quote sets; no native rerendering, semantic truth, independent expert annotation or new inference.'}


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1])), ensure_ascii=False))
