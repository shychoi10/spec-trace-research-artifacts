#!/usr/bin/env python3
"""Publish the actual retained-configuration development intervention."""
import argparse
import inspect
import json
from pathlib import Path
import shutil
import tarfile
import compare_retained_configuration_acquisition as method
import run_codex_relation_comparison as executor
import publish_codex_relation_resource as publisher
import verify_retained_configuration_resource as verifier

OUT = method.OUT
PUB = OUT / 'publication'
DIRECTORY = 'retained_configuration_development'
ARCHIVE = DIRECTORY + '.tar.gz'


def prepare():
    executor.guarded()
    assert executor.read(OUT / 'completion.json')['state'] == 'ALL_NEW_UNIQUE_FIRST_ANSWERS_SAVED'
    assert executor.read(OUT / 'author_answer_readback.json')['new_actual_first_answers_directly_read'] == 2
    PUB.mkdir()
    package = PUB / 'package'
    package.mkdir()
    shutil.copytree(method.OLD / 'publication/package', package / 'prior')
    for name in ('preparation.json', 'protocol.json', 'direct_policy.txt', 'assessment_contract.json',
                 'inherited_author_reference.json', 'completion.json', 'mechanical_replay.json',
                 'completed_first_call_accounting.json', 'author_answer_readback.json'):
        shutil.copyfile(OUT / name, package / name)
    for name in ('inputs', 'acquisition'):
        shutil.copytree(OUT / name, package / name)
    for directory in sorted((OUT / 'predictions').iterdir()):
        dest = package / 'predictions' / directory.name
        dest.mkdir(parents=True)
        for name in ('answer.txt', 'result.json'):
            shutil.copyfile(directory / name, dest / name)
    (package / 'producers').mkdir()
    for name in ('compare_retained_configuration_acquisition.py', 'collect_retained_configuration_acquisition.py',
                 'publish_retained_configuration_resource.py'):
        shutil.copyfile(Path(__file__).with_name(name), package / 'producers' / name)
    shutil.copyfile(Path(verifier.__file__), package / 'verify.py')
    portable = '# Exact function exports from the frozen producer.\nimport json\n'
    for name in ('serialized', 'retained_blocks'):
        portable += '\n\n' + inspect.getsource(getattr(method, name))
    (package / 'replay_method.py').write_text(portable)
    readme = '''# Retained configuration development intervention

The exposed three-CR P5 source pool, original first answers and original
question-specific assessment are preserved in prior/. The new frozen rule
prioritizes unchanged blocks in a different table of an edited clause when
they share literal configuration labels with changed blocks. Caption,
endpoint occurrences, context bundles and deduplication are shared. The
contextual comparator sees all retained blocks, including the same alternative
block, but ranks them with the preserved BM25 scores. Cover context precedes
retained priority; edit/version closure and BM25 backfill follow. Atomic
packing uses the same 12,000 unique source-text-character cap. No reference,
PC2 constant, case ID or numerical answer is used to select evidence.

Nine condition inputs use five unique first observations: three inherited
P5 edit/version first responses and two new CR1484 first calls. Byte-identical
input plus policy is reused, never rerun. Both new inputs and first answers
recover the unchanged PC2 783 MHz/5 MHz/25 RB setting and all seven ordinary
changes. This is a repair on one exposed development case, not evidence of
relation-selector superiority or general accuracy. Added/displaced sources,
remaining reader omissions, boundaries and actual costs are explicit.

Contextual/table retrieval, version linking and contrastive retrieval are
established prior ideas, including DeepSpecs, RAGonite and CF-RAG. This is
neither a faithful reproduction nor a claim to invent those principles.
The source pool remains native-derived selected excerpts; full rendering,
structural revisions, equations and reference resolution are not certified.
There are no independent expert labels, held-out scores, DOI or observed users.

Run python3 verify.py . with the standard library. The verifier hashes every
listed file, replays the preserved P5 instrument, reconstructs both retained
rules and all nine actual inputs, and checks the five unique answer quote
sets. It neither calls a model nor rerenders native Word nor grades meaning.
Original repository paths and unused protocol bindings record provenance;
portable replay reads only this package. Upload and same-host credential-free
download/replay are separately logged outside the prepared package.
'''
    (package / 'README.md').write_text(readme)
    entries = [{'path': str(f.relative_to(package)), **verifier.digest(f)}
               for f in sorted(package.rglob('*')) if f.is_file()]
    executor.save(package / 'manifest.json', {'files': entries, 'development_only': True, 'expert_gold': False})
    replay = verifier.verify(package)
    executor.save(PUB / 'local_replay.json', replay)
    with tarfile.open(PUB / ARCHIVE, 'w:gz') as archive:
        for file in sorted(package.rglob('*')):
            if file.is_file():
                archive.add(file, arcname=str(file.relative_to(package)))
    shutil.copyfile(package / 'README.md', PUB / 'README.md')
    executor.save(PUB / 'resource.json', {'state': 'LOCALLY_PREPARED_AND_REPLAYED',
        'created_utc': executor.now(), 'archive': verifier.digest(PUB / ARCHIVE),
        'producer': executor.bind(Path(__file__)), 'files': len(entries) + 1,
        'new_unique_first_calls': 2, 'inherited_unique_first_observations': 3,
        'condition_inputs': 9, 'uploaded': False, 'anonymous_download_verified': False,
        'human_labels': 0, 'doi': None, 'external_users_observed': 0})
    (PUB / 'checksums.sha256').write_text('\n'.join(verifier.digest(PUB / n)['sha256'] + '  ' + n
        for n in ('README.md', 'resource.json', ARCHIVE)) + '\n')
    print(json.dumps({'files': len(entries) + 1, 'archive': verifier.digest(PUB / ARCHIVE),
        'new_unique_calls': 2, 'unique_observation_quotes': replay['unique_observation_quotes']}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['prepare', 'upload', 'check'])
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare()
    else:
        executor.guarded()
        publisher.OUT = PUB
        publisher.DIRECTORY = DIRECTORY
        publisher.ARCHIVE = ARCHIVE
        publisher.NAMES = ['README.md', 'resource.json', ARCHIVE, 'checksums.sha256']
        getattr(publisher, args.action)()
