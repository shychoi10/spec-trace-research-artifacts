#!/usr/bin/env python3
"""Replay saved inputs/quotes and count unique first observations, without grading."""
import json
from pathlib import Path
import compare_retained_configuration_acquisition as method
import run_codex_relation_comparison as executor


def main():
    executor.guarded()
    out = method.OUT
    plan = executor.read(out / 'protocol.json')
    assert executor.read(out / 'completion.json')['state'] == 'ALL_NEW_UNIQUE_FIRST_ANSWERS_SAVED'
    for binding in plan['dependencies'] + list(plan['policies'].values()):
        executor.verify(binding)
    reference = executor.read(executor.verify(plan['reference_not_supplied_to_predictions']))
    rows, unique = [], {}
    for case in plan['cases']:
        acquisition = executor.read(executor.verify(case['acquisition']))
        pool = executor.read(executor.verify(case['pool']))
        changed = [u['id'] for u in pool['units'] if u['role'] == 'CR' and u['changed']]
        for mode, record in acquisition['modes'].items():
            actual = executor.verify(record['input']).read_text()
            supplied = [json.loads(line) for line in actual.split('SUPPLIED UNITS WITH OCCURRENCES\n', 1)[1].splitlines()]
            aliases = {o['id']: u['text'] for u in supplied for o in u['occurrences']}
            assert list(aliases) == record['supplied_occurrence_ids']
            observation = record['observation']
            if observation['kind'] == 'preserved_first_answer':
                result_path = executor.verify(observation['result'])
                executor.verify(observation['input'])
                assert executor.verify(observation['input']).read_bytes() == executor.verify(record['input']).read_bytes()
            else:
                result_path = out / 'predictions' / observation['job_id'] / 'result.json'
            result = executor.read(result_path)
            assert result['state'] == 'SAVED_CONTROLLED_ANSWER'
            answer_path = executor.verify(result['answer'])
            answer = json.loads(answer_path.read_text())
            assert [a['id'] for a in answer['answers']] == ['Q1', 'Q2', 'Q3', 'Q4']
            defects, quotes = [], 0
            for response in answer['answers']:
                for anchor in response['evidence']:
                    quotes += 1
                    if anchor['source_id'] not in aliases or not anchor['quote'] or anchor['quote'] not in aliases[anchor['source_id']]:
                        defects.append({'question': response['id'], 'anchor': anchor})
            coverage = []
            for ref in reference['cases'][case['id']]:
                ids = list(dict.fromkeys(e['source_id'] for e in ref['evidence']))
                coverage.append({'id': ref['id'], 'supplied': [i for i in ids if i in aliases],
                                 'withheld': [i for i in ids if i not in aliases]})
            key = str(result_path.relative_to(executor.ROOT))
            unique.setdefault(key, {'kind': observation['kind'], 'result': executor.bind(result_path),
                'answer': result['answer'], 'usage': result['turn_completed_events'][0]['usage'],
                'request_seconds': result['elapsed_seconds'], 'quotes': quotes, 'literal_defects': defects})
            rows.append({'case': case['id'], 'mode': mode, 'input': record['input'],
                'observation_key': key, 'observation_kind': observation['kind'], 'answer': result['answer'],
                'source_characters': record['source_characters'], 'input_characters': record['input_characters'],
                'changed_CR_units': len(changed), 'changed_CR_units_supplied': [i for i in changed if i in aliases],
                'changed_CR_units_withheld': [i for i in changed if i not in aliases],
                'known_reference_unit_coverage': coverage, 'quotes': quotes, 'literal_defects': defects,
                'added_occurrence_ids': record.get('added_occurrence_ids', []),
                'displaced_occurrence_ids': record.get('displaced_occurrence_ids', []),
                'meaning_checked_by_this_code': False})
    totals = {}
    for kind in ('new_first_answer', 'preserved_first_answer'):
        selected = [u for u in unique.values() if u['kind'] == kind]
        totals[kind] = {'unique_observations': len(selected),
            **{key: sum(u['usage'][key] for u in selected) for key in
               ('input_tokens', 'output_tokens', 'cached_input_tokens', 'reasoning_output_tokens')},
            'request_seconds': sum(u['request_seconds'] for u in selected),
            'quotes': sum(u['quotes'] for u in selected),
            'literal_defects': sum(len(u['literal_defects']) for u in selected)}
    assert totals['new_first_answer']['unique_observations'] == len(plan['jobs']) == 2
    executor.save(out / 'mechanical_replay.json', {'state': 'NINE_CONDITION_INPUTS_FIVE_UNIQUE_FIRST_OBSERVATIONS_REPLAYED',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)), 'conditions': rows,
        'unique_observations': list(unique.values()), 'meaning_certified': False,
        'limit': 'Source-ID/quote availability for exposed author witnesses is not semantic gold, exhaustive recall or correctness. Nine condition slots share five preserved/new first observations.'})
    executor.save(out / 'completed_first_call_accounting.json', {'state': 'TWO_NEW_UNIQUE_FIRST_CALLS_COUNTED',
        'created_utc': executor.now(), 'totals': totals, 'new_attempted_calls': 2, 'new_returned_controlled_calls': 2,
        'new_answer_cells': 8, 'condition_slots': 9, 'unique_observations_including_inherited': 5,
        'model_judge_calls': 0, 'retries': 0,
        'limit': 'Inherited costs are historical costs, never new calls or independent replicated answers. Equal source cap does not imply equal metadata/token/cache/output compute; no causal latency, financial cost or TCO.'})
    print(json.dumps(totals), flush=True)


if __name__ == '__main__':
    main()
