#!/usr/bin/env python3
"""Prospective retained-table allocation on the preserved, exposed P5 pool.

Context, version joins and contrastive retrieval are prior ideas. This small
development intervention tests source availability and its opportunity cost.
It neither reads assessment references to select evidence nor resamples an
already measured identical input/policy pair.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import time

import compare_evidence_acquisition as prior
import run_codex_relation_comparison as executor

ROOT = executor.ROOT
OLD = prior.OUT
OUT = OLD.parent / 'priority6-retained-configuration-acquisition'
MODES = ('preserved_edit_version', 'contextual_retained_first',
         'configuration_alternative_first')
BUDGET = 12000


def serialized(questions, inventory, units):
    return ('QUESTIONS\n' + json.dumps(questions, ensure_ascii=False) +
            '\n\nSOURCE INVENTORY\n' + json.dumps(inventory, ensure_ascii=False) +
            '\n\nSUPPLIED UNITS WITH OCCURRENCES\n' +
            '\n'.join(json.dumps(u, ensure_ascii=False, separators=(',', ':'))
                      for u in units))


def retained_blocks(original, inventory, aliases, contexts):
    """One shared candidate representation for both new allocation rules.

    All labels and rows are supplied native-derived configuration blocks.
    A caption is the last preceding same-clause Table paragraph, not an
    inferred PC2 label. Explicit endpoint occurrences remain in exact-text
    deduplication. We do not certify native layout or configuration semantics.
    """
    units = {u['id']: u for u in original}
    positions = {u['id']: i for i, u in enumerate(original)}
    blocks = []
    for block in inventory['CR_configuration_blocks']:
        rows = [units[r] for r in block['rows'] if r in units]
        if not rows:
            continue
        clauses = {u['clause'] for u in rows}
        tables = {u['table'] for u in rows}
        if len(clauses) != 1 or len(tables) != 1:
            raise ValueError('Ambiguous supplied configuration block')
        clause, table = next(iter(clauses)), next(iter(tables))
        indexes = set().union(*(contexts[aliases[u['id']]] for u in rows))
        first = min(positions[u['id']] for u in rows)
        captions = [u for u in original[:first]
                    if u['document_id'] == rows[0]['document_id'] and
                    u['clause'] == clause and u['kind'] == 'paragraph' and
                    u['text'].lstrip().startswith('Table ')]
        caption = captions[-1] if captions else None
        if caption:
            indexes.add(aliases[caption['id']])
        blocks.append({'first': block['first'], 'clause': clause,
                       'table': table, 'labels': sorted(set(block['configuration_labels'])),
                       'changed': any(u['changed'] for u in rows),
                       'rows': [u['id'] for u in rows],
                       'caption': caption['id'] if caption else None,
                       'bundle': sorted(indexes)})
    edited_clauses = {u['clause'] for u in original
                      if u['role'] == 'CR' and u['changed']}
    retained = [b for b in blocks if not b['changed'] and b['clause'] in edited_clauses]
    alternative = []
    for block in retained:
        matched = [b['first'] for b in blocks if b['changed'] and
                   b['clause'] == block['clause'] and b['table'] != block['table'] and
                   set(b['labels']).intersection(block['labels'])]
        if matched:
            alternative.append({**block, 'matched_changed_blocks': matched})
    return retained, alternative


def prepare():
    executor.guarded()
    assert not (OUT / 'preparation.json').exists()
    old_plan = executor.read(OLD / 'protocol.json')
    for binding in old_plan['dependencies'] + [old_plan['reference_not_supplied_to_predictions']]:
        executor.verify(binding)
    formats = executor.read(OLD / 'native_run_formats.json')
    (OUT / 'inputs').mkdir()
    (OUT / 'acquisition').mkdir()
    executor.text_new(OUT / 'direct_policy.txt', (OLD / 'direct_policy.txt').read_text())
    records, jobs, identities = [], [], {}
    # Old observations enter the lookup only as byte-identical input+policy.
    for case in old_plan['cases']:
        for old_mode, binding in case['modes'].items():
            answer_root = OLD / 'predictions' / (case['id'] + '.' + old_mode)
            result = executor.read(answer_root / 'result.json')
            assert result['state'] == 'SAVED_CONTROLLED_ANSWER'
            executor.verify(binding)
            identities[binding['sha256']] = {'kind': 'preserved_first_answer',
                'input': binding, 'answer': result['answer'],
                'result': executor.bind(answer_root / 'result.json'),
                'dispatch': executor.bind(answer_root / 'dispatch.json')}
    for ci, old_case in enumerate(old_plan['cases']):
        start, cpu = time.perf_counter(), time.process_time()
        cid = old_case['id']
        pool_path = executor.verify(old_case['pool'])
        packet = executor.read(pool_path)
        original = packet['units']
        for u in original:
            u['explicit_native_run_formats'] = formats['cases'][cid]['units'].get(u['id'], [])
        unique, aliases = prior.unique_units(original)
        contexts = prior.context_bundles(original, aliases, packet['inventory'])
        baseline, scores, index = prior.ranked_bundles(unique, contexts, old_case['questions'])
        closure = prior.closure_bundles(original, unique, aliases, contexts, index, baseline)
        retained, alternatives = retained_blocks(original, packet['inventory'], aliases, contexts)
        # The contextual comparator sees every retained block, including
        # alternatives. It ranks them without the cross-table label relation.
        lexical = sorted(retained, key=lambda b: (
            -max(sum(s[i] for i in b['bundle']) for s in scores), b['first']))
        alternative_order = sorted(alternatives, key=lambda b: b['first'])
        cover = closure[0]
        schedules = {
            MODES[0]: closure,
            MODES[1]: [cover] + [b['bundle'] for b in lexical] + closure[1:],
            MODES[2]: [cover] + [b['bundle'] for b in alternative_order] + closure[1:]}
        mode_records = {}
        for mode in MODES:
            chosen, used, skipped = prior.pack(schedules[mode], unique, BUDGET)
            supplied = [unique[i] for i in chosen]
            body = serialized(old_case['questions'], packet['inventory'], supplied)
            file = OUT / 'inputs' / (cid + '.' + mode + '.txt')
            executor.text_new(file, body)
            if mode == MODES[0]:
                assert file.read_bytes() == executor.verify(old_case['modes']['scope_version_closure']).read_bytes()
            mode_records[mode] = {'input': executor.bind(file), 'source_characters': used,
                'input_characters': len(body), 'unique_units': len(supplied),
                'supplied_occurrence_ids': [o['id'] for u in supplied for o in u['occurrences']],
                'selected_unique_ids': [u['id'] for u in supplied], 'skipped_bundles': skipped}
        # Fixed rotation chooses the first representative of identical new
        # inputs. The other condition binds to it rather than making a retry.
        order = list(MODES[ci:] + MODES[:ci])
        for mode in order:
            binding = mode_records[mode]['input']
            identity = binding['sha256']
            observation = identities.get(identity)
            if observation is None:
                job = {'id': cid + '.' + mode, 'case': cid, 'mode': mode, 'input': binding}
                jobs.append(job)
                observation = {'kind': 'new_first_answer', 'job_id': job['id']}
                identities[identity] = observation
            mode_records[mode]['observation'] = observation
        old_ids = set(mode_records[MODES[0]]['supplied_occurrence_ids'])
        for mode in MODES[1:]:
            new_ids = set(mode_records[mode]['supplied_occurrence_ids'])
            mode_records[mode]['added_occurrence_ids'] = sorted(new_ids - old_ids)
            mode_records[mode]['displaced_occurrence_ids'] = sorted(old_ids - new_ids)
        acquisition = OUT / 'acquisition' / (cid + '.json')
        executor.save(acquisition, {'case': cid, 'pool': executor.bind(pool_path),
            'questions': old_case['questions'], 'retained_blocks': retained,
            'alternative_blocks': alternatives, 'modes': mode_records,
            'source_budget': BUDGET, 'shared_metadata_and_serialization': True,
            'acquisition_seconds': time.perf_counter() - start,
            'preparation_cpu_seconds': time.process_time() - cpu})
        records.append({'id': cid, 'acquisition': executor.bind(acquisition), 'pool': executor.bind(pool_path)})
    executor.save(OUT / 'preparation.json', {'state': 'INPUTS_PREPARED_BEFORE_NEW_FIRST_PREDICTIONS',
        'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)),
        'cases': records, 'jobs': jobs, 'model_calls': 0,
        'reference_used_by_selectors': False, 'source_budget': BUDGET,
        'identical_inputs_reused_not_resampled': True})
    print(json.dumps({'cases': len(records), 'new_unique_input_jobs': len(jobs),
                      'budget': BUDGET}), flush=True)


def freeze():
    executor.guarded()
    prepared = executor.read(OUT / 'preparation.json')
    old = executor.read(OLD / 'protocol.json')
    reference = OUT / 'inherited_author_reference.json'
    with reference.open('xb') as stream:
        stream.write(executor.verify(old['reference_not_supplied_to_predictions']).read_bytes())
    for case in prepared['cases']:
        acquisition = executor.read(executor.verify(case['acquisition']))
        for mode in acquisition['modes'].values():
            executor.verify(mode['input'])
            observation = mode['observation']
            if observation['kind'] == 'preserved_first_answer':
                for key in ('input', 'answer', 'result', 'dispatch'):
                    executor.verify(observation[key])
    binary = executor.verify(old['cli_binary'])
    auth = subprocess.run([str(binary), 'login', 'status'], capture_output=True, text=True, timeout=30)
    assert auth.returncode == 0 and 'ChatGPT' in auth.stdout + auth.stderr
    policy = executor.bind(OUT / 'direct_policy.txt')
    assert policy['sha256'] == executor.bind(OLD / 'direct_policy.txt')['sha256']
    dependencies = [Path(__file__), Path(prior.__file__), Path(executor.__file__),
        Path(executor.collector.__file__), Path(executor.collector.control.__file__),
        Path(prior.__file__).with_name('declared_clause_retrieval.py'),
        OLD / 'protocol.json', OLD / 'native_run_formats.json',
        OLD / 'root_source_readback.json', OUT / 'preparation.json',
        OUT / 'strategy_adoption.json', OUT / 'assessment_contract.json']
    executor.save(OUT / 'protocol.json', {'state': 'FROZEN_BEFORE_NEW_UNIQUE_FIRST_PREDICTIONS',
        'created_utc': executor.now(), 'dependencies': [executor.bind(p) for p in dependencies],
        'cases': prepared['cases'], 'jobs': prepared['jobs'], 'cli_binary': old['cli_binary'],
        'config_overrides': old['config_overrides'], 'cli_version': old['cli_version'],
        'policies': {mode: policy for mode in MODES},
        'reference_not_supplied_to_predictions': executor.bind(reference),
        'per_turn_wall_limit_seconds': 900, 'attempts_per_unique_input': 1,
        'new_prediction_calls': len(prepared['jobs']), 'retries': 0,
        'sampling': old['sampling'], 'exposure': 'All three P5 cases, references and first answers exposed to author; no independent expert/heldout accuracy',
        'comparison': 'Same pool, dedup, metadata, contextual bundles, answer policy, serialization and 12000 source-text-character cap. Actual input/cache/output differ; not compute-matched causality.',
        'failure': 'Stop further dispatch after first incomplete/uncontrolled call; preserve every attempt. Identical input/policy reuses one first observation.',
        'protected_bodies_opened': 0})
    print('FROZEN_BEFORE_NEW_UNIQUE_FIRST_PREDICTIONS', flush=True)


def run():
    executor.guarded()
    plan = executor.read(OUT / 'protocol.json')
    for binding in plan['dependencies'] + list(plan['policies'].values()) + [plan['reference_not_supplied_to_predictions']]:
        executor.verify(binding)
    executor.OUT = OUT
    (OUT / 'predictions').mkdir()
    attempted = []
    try:
        for job in plan['jobs']:
            attempted.append(job['id'])
            executor.turn(plan, OUT / 'predictions' / job['id'], job['input'], job['mode'])
    except Exception as error:
        executor.save(OUT / 'completion.json', {'state': 'STOPPED_FIRST_FAILED_OR_UNCONTROLLED_CALL',
            'finished_utc': executor.now(), 'attempted': attempted, 'error': repr(error), 'retries': 0})
        raise
    executor.save(OUT / 'completion.json', {'state': 'ALL_NEW_UNIQUE_FIRST_ANSWERS_SAVED',
        'finished_utc': executor.now(), 'attempted': attempted, 'retries': 0})


if __name__ == '__main__':
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('action', choices=['prepare', 'freeze', 'run'])
    args = ap.parse_args()
    {'prepare': prepare, 'freeze': freeze, 'run': run}[args.action]()
