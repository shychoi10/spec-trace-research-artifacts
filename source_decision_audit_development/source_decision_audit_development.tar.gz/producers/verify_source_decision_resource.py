#!/usr/bin/env python3
"""Offline byte, source-availability and saved-call provenance replay.

The preserved prior verifier is not executed. This checks the whole package's
manifest and the declared new requests, not native rendering, answer meaning,
independent annotation, historical empty directories or unrecorded executions.
"""
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path, PurePosixPath, PureWindowsPath
import re
import sys

sys.dont_write_bytecode = True

SOURCE_SEPARATOR = b'\n\nSOURCE INVENTORY\n'
UNITS_SEPARATOR = b'\n\nSUPPLIED UNITS WITH OCCURRENCES\n'
MODES = ('configuration_alternative_first', 'contextual_retained_first')
WARNING_PREFIXES = (
    'Under-development features enabled: skip_host_skill_discovery.',
    'Code Mode is unavailable because code-mode host is disabled.',
)
CLOSED_FEATURES = (
    'shell_tool', 'unified_exec', 'multi_agent', 'apps', 'plugins',
    'remote_plugin', 'memories', 'hooks', 'goals', 'browser_use',
    'browser_use_external', 'computer_use', 'image_generation', 'view_image',
    'sleep_tool', 'shell_snapshot', 'code_mode_host', 'context_management',
    'workspace_dependencies', 'skill_search',
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = path.read_bytes()
    return {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}


def _object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, 'Duplicate JSON key: ' + key)
        value[key] = item
    return value


def _constant(value):
    raise ValueError('Non-finite JSON constant: ' + value)


def loads(value):
    return json.loads(value, object_pairs_hook=_object, parse_constant=_constant)


def read(path):
    return loads(path.read_text(encoding='utf-8'))


def safe_path(package, locator):
    require(isinstance(locator, str) and bool(locator), 'Empty/non-string package locator')
    relative = PurePosixPath(locator)
    require(not relative.is_absolute() and not PureWindowsPath(locator).drive
            and '\\' not in locator and '..' not in relative.parts
            and locator == relative.as_posix() and locator != '.',
            'Non-canonical or escaping package locator: ' + locator)
    path = package.joinpath(*relative.parts)
    resolved = path.resolve()
    require(package in resolved.parents, 'Resolved path escapes package: ' + locator)
    require(path.is_file(), 'Missing package file: ' + locator)
    return path


def _hash_fields(binding):
    require(isinstance(binding, dict), 'Invalid artifact binding')
    require(type(binding.get('bytes')) is int and binding['bytes'] >= 0,
            'Invalid bound byte count')
    require(isinstance(binding.get('sha256'), str)
            and re.fullmatch(r'[0-9a-f]{64}', binding['sha256']) is not None,
            'Invalid bound SHA256')
    return {key: binding[key] for key in ('bytes', 'sha256')}


def bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'}.issubset(value):
            yield value
        else:
            for item in value.values():
                yield from bindings(item)
    elif isinstance(value, list):
        for item in value:
            yield from bindings(item)


def supplied_units(body):
    require(body.count(SOURCE_SEPARATOR) == 1 and body.count(UNITS_SEPARATOR) == 1,
            'Input separators must occur exactly once')
    inventory_bytes, units_bytes = body.split(SOURCE_SEPARATOR, 1)[1].split(UNITS_SEPARATOR, 1)
    inventory = loads(inventory_bytes.decode('utf-8'))
    lines = units_bytes.decode('utf-8').splitlines()
    require(bool(lines) and all(line.strip() for line in lines), 'Empty supplied-unit record')
    units, aliases, texts = [], {}, set()
    for line in lines:
        unit = loads(line)
        require(isinstance(unit, dict) and isinstance(unit.get('text'), str), 'Invalid supplied unit')
        require(unit['text'] not in texts, 'Supplied texts must be exactly deduplicated')
        texts.add(unit['text'])
        require(isinstance(unit.get('occurrences'), list) and bool(unit['occurrences']),
                'Missing supplied occurrence metadata')
        for occurrence in unit['occurrences']:
            identifier = occurrence.get('id') if isinstance(occurrence, dict) else None
            require(isinstance(identifier, str) and identifier and identifier not in aliases,
                    'Missing or duplicate supplied occurrence ID')
            aliases[identifier] = unit['text']
        units.append(unit)
    return inventory, units, aliases


def inspect_events(path, answer_path):
    lines = path.read_text(encoding='utf-8').splitlines()
    require(bool(lines) and all(line.strip() for line in lines), 'Empty raw event record')
    events = [loads(line) for line in lines]
    warnings, unexpected, errors, completed, messages = [], [], [], [], []
    for event in events:
        require(isinstance(event, dict) and isinstance(event.get('type'), str), 'Invalid raw event')
        kind = event['type']
        if kind in ('error', 'turn.failed'):
            errors.append(event)
        elif kind == 'turn.completed':
            completed.append(event)
        elif kind in ('thread.started', 'turn.started'):
            continue
        elif kind in ('item.started', 'item.updated', 'item.completed'):
            item = event.get('item')
            require(isinstance(item, dict), 'Invalid item event')
            if item.get('type') in ('agent_message', 'reasoning'):
                if kind == 'item.completed' and item['type'] == 'agent_message':
                    messages.append(item)
            elif (item.get('type') == 'error' and isinstance(item.get('message'), str)
                  and item['message'].startswith(WARNING_PREFIXES)):
                warnings.append(event)
            else:
                unexpected.append(event)
        else:
            unexpected.append(event)
    require(not errors and not unexpected, 'Raw events contain errors, tools or unknown events')
    require(len(completed) == 1, 'Expected exactly one raw completed turn')
    require(len(messages) == 1 and isinstance(messages[0].get('text'), str),
            'Expected exactly one completed assistant message')
    require(messages[0]['text'].encode('utf-8') == answer_path.read_bytes(),
            'Completed assistant message differs from saved answer bytes')
    usage = completed[0].get('usage')
    require(isinstance(usage, dict) and {'input_tokens', 'output_tokens', 'cached_input_tokens'}.issubset(usage),
            'Missing raw completed usage')
    require(all(type(value) is int and value >= 0 for value in usage.values()), 'Invalid raw usage count')
    return {'event_count': len(events), 'startup_warnings': warnings,
            'unexpected_tool_or_item_events': unexpected, 'turn_completed_events': completed,
            'errors': errors}


def _recorded_prefix(recorded, locator):
    require(isinstance(recorded, str) and isinstance(locator, str), 'Invalid recorded CLI path')
    if PurePosixPath(locator).is_absolute():
        require(recorded == locator, 'Recorded absolute CLI path differs from binding')
        return None
    require(recorded == locator or recorded.endswith('/' + locator),
            'Recorded CLI path differs from bound artifact: ' + locator)
    return recorded[:-len(locator)]


def inspect_dispatch(dispatch, protocol, job, policy, answer_binding):
    require(dispatch.get('input') == job['input'] and dispatch.get('policy') == policy,
            'Dispatch input/policy binding differs from protocol')
    require(dispatch.get('empty_cwd_at_dispatch') is True,
            'Dispatch does not record an empty working directory')
    argv = dispatch.get('argv')
    require(isinstance(argv, list) and len(argv) >= 3 and all(isinstance(v, str) for v in argv),
            'Invalid saved CLI argv')
    require(argv[0] == protocol['cli_binary']['path'] and argv[1] == 'exec' and argv[-1] == '-',
            'CLI executable/exec/stdin dispatch differs')
    switches, options, overrides = [], {}, []
    standalone = {'--ignore-user-config', '--ignore-rules', '--strict-config', '--ephemeral',
                  '--skip-git-repo-check', '--json'}
    paired = {'--sandbox', '--cd', '--color', '--output-last-message'}
    position = 2
    while position < len(argv) - 1:
        flag = argv[position]
        if flag in standalone:
            require(flag not in switches, 'Duplicate CLI switch: ' + flag)
            switches.append(flag)
            position += 1
        elif flag in paired or flag == '-c':
            require(position + 1 < len(argv) - 1, 'Missing CLI option value')
            value = argv[position + 1]
            if flag == '-c':
                overrides.append(value)
            else:
                require(flag not in options, 'Duplicate CLI option: ' + flag)
                options[flag] = value
            position += 2
        else:
            raise ValueError('Undeclared CLI argument: ' + flag)
    require(set(switches) == standalone and set(options) == paired,
            'Missing closed-execution CLI options')
    require(options['--sandbox'] == 'read-only' and options['--color'] == 'never',
            'CLI sandbox/color differs')
    require(bool(options['--cd']) and PurePosixPath(options['--cd']).is_absolute(),
            'Missing recorded working directory')
    require(len(overrides) == len(protocol['config_overrides']) + 1
            and overrides[:-1] == protocol['config_overrides'], 'CLI configuration differs from protocol')
    configuration = {}
    for override in overrides:
        require('=' in override, 'Invalid CLI configuration override')
        key, value = override.split('=', 1)
        require(key not in configuration, 'Duplicate CLI configuration key: ' + key)
        configuration[key] = value
    required = {'project_doc_max_bytes': '0', 'web_search': '"disabled"', 'mcp_servers': '{}',
                'features.skip_host_skill_discovery': 'true', 'approval_policy': '"never"'}
    required.update({'features.' + feature: 'false' for feature in CLOSED_FEATURES})
    require(all(configuration.get(key) == value for key, value in required.items()),
            'CLI configuration does not disable declared external tools/context')
    require('model' in configuration and 'model_reasoning_effort' in configuration,
            'Missing declared model configuration')
    require(overrides[-1].startswith('model_instructions_file='), 'Missing final policy-file override')
    policy_name = loads(configuration['model_instructions_file'])
    prefix = _recorded_prefix(policy_name, policy['path'])
    output_prefix = _recorded_prefix(options['--output-last-message'], answer_binding['path'])
    require(prefix == output_prefix, 'Policy and answer paths record different checkout roots')
    return {'input_and_policy_bindings_match': True, 'argv_matches_closed_protocol': True,
            'recorded_empty_cwd_marker': True,
            'historical_empty_cwd_reobserved': False,
            'declared_model': loads(configuration['model']),
            'declared_reasoning_effort': loads(configuration['model_reasoning_effort'])}


def _time(value):
    require(isinstance(value, str), 'Missing recorded timestamp')
    parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(parsed.tzinfo is not None, 'Timestamp lacks timezone')
    return parsed


def _verify(package):
    package = Path(package).resolve()
    manifest = read(safe_path(package, 'manifest.json'))
    entries = manifest.get('files')
    require(isinstance(entries, list) and bool(entries), 'Missing manifest files')
    manifest_paths = set()
    for entry in entries:
        require(isinstance(entry, dict) and isinstance(entry.get('path'), str), 'Invalid manifest entry')
        locator = entry['path']
        require(locator != 'manifest.json' and locator not in manifest_paths, 'Duplicate/self manifest entry')
        require(digest(safe_path(package, locator)) == _hash_fields(entry), 'Package hash differs: ' + locator)
        manifest_paths.add(locator)
    actual = {p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file()}
    require(actual == manifest_paths | {'manifest.json'}, 'Manifest omits or invents package files')
    mappings = read(safe_path(package, 'source_locators.json'))
    require(isinstance(mappings, dict), 'Invalid source locator mapping')
    for original, locator in mappings.items():
        require(isinstance(original, str) and original and isinstance(locator, str)
                and locator in manifest_paths,
                'Locator target is not a manifested file')
        safe_path(package, locator)

    checked_bindings = set()

    def bound(binding):
        require(isinstance(binding, dict) and isinstance(binding.get('path'), str), 'Invalid source binding')
        require(binding['path'] in mappings, 'Binding has no portable locator: ' + binding['path'])
        path = safe_path(package, mappings[binding['path']])
        require(digest(path) == _hash_fields(binding), 'Frozen binding differs: ' + binding['path'])
        checked_bindings.add((binding['path'], binding['bytes'], binding['sha256']))
        return path

    protocol = read(safe_path(package, 'protocol.json'))
    prepared = read(safe_path(package, 'preparation.json'))
    question_record = read(safe_path(package, 'questions.json'))
    reference = read(safe_path(package, 'author_reference.json'))
    ledger = read(safe_path(package, 'source_decision_ledger_before_outputs.json'))
    cli_binding = protocol['cli_binary']
    _hash_fields(cli_binding)
    require(isinstance(cli_binding.get('path'), str) and bool(cli_binding['path'])
            and isinstance(protocol.get('cli_version'), str) and bool(protocol['cli_version']),
            'Missing recorded CLI binary locator/version')
    for value in (protocol, prepared, reference, ledger):
        for binding in bindings(value):
            if binding is not cli_binding:
                bound(binding)
    require(bound(protocol['reference_not_supplied_to_predictions']).resolve()
            == safe_path(package, 'author_reference.json').resolve(), 'Reference binding points to another file')
    questions = question_record['questions']
    require(isinstance(questions, list) and bool(questions), 'Missing declared questions')
    ids = [q['id'] for q in questions]
    require(all(isinstance(i, str) and i for i in ids) and len(set(ids)) == len(ids), 'Invalid question IDs')
    require([r['id'] for r in reference['requirements']] == ids, 'Question/reference order differs')
    require(protocol['jobs'] == prepared['jobs'], 'Protocol and preparation jobs differ')
    jobs = protocol['jobs']
    require([job['mode'] for job in jobs] == list(MODES)
            and [job['id'] for job in jobs] == ['row25.' + mode for mode in MODES], 'Declared job identities differ')
    require(protocol.get('planned_unique_first_calls') == prepared.get('unique_first_jobs') == len(jobs)
            and protocol.get('answer_cells') == prepared.get('answer_cells') == len(jobs) * len(ids),
            'Declared observation denominators differ')
    require(protocol.get('retries') == 0 and protocol.get('attempts_per_unique_input_and_policy') == 1,
            'Protocol does not preserve one recorded attempt per declared request')
    policy_bytes = [bound(protocol['policies'][mode]).read_bytes() for mode in MODES]
    require(policy_bytes[0] == policy_bytes[1] == bound(prepared['policy']).read_bytes(), 'Decision policies differ')
    prior_policy = safe_path(package, 'prior/direct_policy.txt').read_text(encoding='utf-8')
    old_budget = ('Answer every Q in\norder, with up to 250 words each; Q2 may use up to 400 words if the technical\nchanges need it.')
    require(old_budget in prior_policy, 'Prior summary policy budget not found')
    policy = prior_policy.replace(old_budget, 'Answer every declared decision request in order, with up to 250 words each.')
    policy = policy.replace('"id":"Q1"', '"id":"C01"').replace('Include Q1–Q4.', 'Include all eight declared IDs C01–C08.')
    require(policy_bytes[0] == policy.encode('utf-8'), 'Declared policy transformation differs')
    pool = read(bound(reference['pool']))
    require(ledger['source_pool'] == reference['pool'], 'Ledger/source pool binding differs')
    full_units = {}
    for unit in pool['units']:
        require(isinstance(unit.get('id'), str) and isinstance(unit.get('text'), str)
                and unit['id'] not in full_units, 'Invalid/duplicate source pool occurrence')
        full_units[unit['id']] = unit['text']
    reference_quotes = 0
    for requirement in reference['requirements']:
        require(isinstance(requirement['source_groups'], list), 'Invalid source groups')
        for group in requirement['source_groups']:
            require(isinstance(group, list) and bool(group) and all(i in full_units for i in group), 'Unknown scoped alias group')
            require(len({full_units[i] for i in group}) == 1, 'Scoped aliases do not share complete text')
        for anchor in requirement['anchors']:
            require(isinstance(anchor.get('quote'), str) and bool(anchor['quote'])
                    and anchor['source_id'] in full_units
                    and anchor['quote'] in full_units[anchor['source_id']], 'Reference quote is not in full source pool')
            reference_quotes += 1
        require(all(t in pool['inventory']['absent_evidence_types'] for t in requirement['inventory_absent_evidence_types']),
                'Reference missing-evidence type is not declared in inventory')
    ledger_rows = ledger['rows']
    require(len(ledger_rows) == len(jobs) * len(ids), 'Ledger row denominator differs')
    require(len({(r['mode'], r['id']) for r in ledger_rows}) == len(ledger_rows), 'Duplicate ledger row')
    ledger_index = {(r['mode'], r['id']): r for r in ledger_rows}
    require(_time(ledger['created_utc']) <= _time(protocol['created_utc'])
            and _time(prepared['created_utc']) <= _time(protocol['created_utc']), 'Recorded freeze chronology differs')
    rows, quote_count = [], 0
    for job in jobs:
        mode = job['mode']
        actual_input = bound(job['input']).read_bytes()
        old_input = bound(job['prior_input']).read_bytes()
        require(old_input.count(SOURCE_SEPARATOR) == 1, 'Prior input source separator differs')
        suffix = SOURCE_SEPARATOR + old_input.split(SOURCE_SEPARATOR, 1)[1]
        expected_input = b'QUESTIONS\n' + json.dumps(questions, ensure_ascii=False).encode('utf-8') + suffix
        require(actual_input == expected_input and actual_input != old_input, 'Changed request/input reconstruction differs')
        require(hashlib.sha256(suffix).hexdigest() == job['source_suffix_sha256'], 'Source suffix hash differs')
        inventory, supplied, aliases = supplied_units(actual_input)
        require(inventory == pool['inventory'], 'Supplied inventory differs from bound pool')
        require(all(i in full_units and text == full_units[i] for i, text in aliases.items()),
                'Supplied occurrence text differs from full source pool')
        require(sum(len(u['text']) for u in supplied) == job['source_characters']
                and len(supplied) == job['unique_texts'] and len(aliases) == job['source_occurrences'],
                'Recomputed supplied-source counts differ')
        availability = []
        for requirement in reference['requirements']:
            present = [[i for i in group if i in aliases] for group in requirement['source_groups']]
            available = all(present) if present else None
            expected = requirement['expected_input_presence'][mode]
            require(expected is None or type(expected) is bool, 'Invalid declared presence value')
            require(available is expected, 'Predeclared source availability differs: ' + requirement['id'])
            row = ledger_index.get((mode, requirement['id']))
            require(row is not None and row['source_groups'] == requirement['source_groups']
                    and row['present_occurrences_by_group'] == present
                    and row['scoped_technical_source_available'] is available
                    and row['inventory_absent_evidence_types'] == requirement['inventory_absent_evidence_types']
                    and row['expected_action'] == requirement['expected_actions'][mode]
                    and row['prior_summary_readback'] == requirement['prior_summary_readback'][mode],
                    'Frozen ledger row differs: ' + requirement['id'])
            availability.append({'id': requirement['id'], 'present_occurrences_by_group': present,
                                 'scoped_technical_source_available': available})
        directory = 'predictions/' + job['id'] + '/'
        result = read(safe_path(package, directory + 'result.json'))
        dispatch = read(safe_path(package, directory + 'dispatch.json'))
        for name in ('answer', 'events', 'stderr'):
            expected_name = 'events.jsonl' if name == 'events' else name + '.txt'
            require(bound(result[name]).resolve() == safe_path(package, directory + expected_name).resolve(),
                    'Result points outside declared job: ' + name)
        require(result.get('state') == 'SAVED_CONTROLLED_ANSWER' and result.get('returncode') == 0
                and result.get('timed_out') is False, 'Saved request is not recorded as controlled/completed')
        event_audit = inspect_events(bound(result['events']), bound(result['answer']))
        require(all(result.get(key) == value for key, value in event_audit.items()), 'Saved/raw event audit differs')
        dispatch_audit = inspect_dispatch(dispatch, protocol, job, protocol['policies'][mode], result['answer'])
        require(_time(protocol['created_utc']) <= _time(dispatch['started_utc']) <= _time(result['finished_utc']),
                'Recorded protocol/dispatch/completion chronology differs')
        duration = result['elapsed_seconds']
        require(type(duration) in (int, float) and math.isfinite(duration) and duration >= 0, 'Invalid recorded request time')
        answer = read(bound(result['answer']))
        require(isinstance(answer.get('answers'), list) and [a['id'] for a in answer['answers']] == ids,
                'Decision answer IDs/order differ')
        quotes = 0
        for cell in answer['answers']:
            require(isinstance(cell.get('answer'), str) and bool(cell['answer'].strip()), 'Empty decision text')
            for field in ('established_facts', 'missing_information'):
                require(isinstance(cell.get(field), list) and all(isinstance(v, str) for v in cell[field]), 'Invalid answer field: ' + field)
            require(isinstance(cell.get('evidence'), list) and bool(cell['evidence']), 'Missing decision evidence')
            for anchor in cell['evidence']:
                require(isinstance(anchor, dict) and isinstance(anchor.get('quote'), str) and bool(anchor['quote'])
                        and anchor.get('source_id') in aliases and anchor['quote'] in aliases[anchor['source_id']],
                        'Answer quote is not in this request input')
                quotes += 1
        quote_count += quotes
        rows.append({'id': job['id'], 'mode': mode, 'source_suffix_unchanged': True,
                     'source_suffix_sha256': job['source_suffix_sha256'], 'source_characters': job['source_characters'],
                     'unique_texts': len(supplied), 'source_occurrences': len(aliases), 'availability': availability,
                     'answer_cells': len(ids), 'quote_objects': quotes, 'dispatch': dispatch_audit,
                     'raw_event_count': event_audit['event_count'], 'raw_completed_turns': 1,
                     'startup_warnings': event_audit['startup_warnings'], 'unexpected_tools_or_events': 0,
                     'non_warning_errors': 0, 'assistant_message_matches_answer_bytes': True,
                     'usage': event_audit['turn_completed_events'][0]['usage'],
                     'recorded_request_seconds': duration})
    completion_path = package / 'completion.json'
    if completion_path.exists():
        completion = read(safe_path(package, 'completion.json'))
        require(completion.get('attempts') == [j['id'] for j in jobs] and completion.get('retries') == 0,
                'Preserved attempt/completion record differs')
    return {'state': 'PASS_PACKAGE_BYTES_DECLARED_SOURCE_AVAILABILITY_INPUTS_QUOTES_AND_SAVED_CALL_PROVENANCE',
            'hashed_files': len(manifest_paths), 'checked_unique_binding_records': len(checked_bindings),
            'manifest_digest': digest(package / 'manifest.json'), 'reference_quote_objects': reference_quotes,
            'recorded_first_call_observations': len(jobs), 'answer_cells': len(jobs) * len(ids),
            'answer_quote_objects': quote_count, 'rows': rows,
            'same_questions_and_policy_between_modes': True, 'source_suffix_unchanged_per_mode': True,
            'recorded_cli_binary_binding': cli_binding, 'recorded_cli_version': protocol['cli_version'],
            'dispatch_argv_matches_recorded_cli_binary': True, 'cli_binary_rehashed_on_replay': False,
            'prior_selector_rerun': False, 'prior_verifier_executed': False,
            'historical_empty_cwd_reobserved': False, 'unrecorded_execution_absence_proven': False,
            'meaning_certified': False, 'independent_expert_gold': False, 'native_projection_rerun': False,
            'model_calls_for_replay': 0,
            'limit': 'Internal file/binding consistency, unchanged saved allocation suffixes, declared alias availability, literal quotes and saved CLI event/dispatch linkage. CLI binary hash/version describe the recorded host environment; that binary is not distributed or rehashed by replay. Counts describe preserved execution records; no proof of hidden-run absence, past directory contents, semantic truth, native rendering or independent annotation. Package authenticity requires an external archive digest or immutable commit pin.'}


def verify(package):
    try:
        return _verify(package)
    except (OSError, UnicodeError, KeyError, TypeError, AttributeError, IndexError) as error:
        raise ValueError('Invalid or incomplete source-decision package: ' + str(error)) from error


if __name__ == '__main__':
    require(len(sys.argv) == 2, 'Usage: python3 [-O] verify.py PACKAGE')
    print(json.dumps(verify(Path(sys.argv[1])), ensure_ascii=False))
