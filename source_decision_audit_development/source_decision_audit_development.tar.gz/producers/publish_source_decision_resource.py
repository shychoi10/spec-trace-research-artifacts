#!/usr/bin/env python3
"""Publish the frozen source-to-decision diagnostic with provenance replay."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile
import urllib.request

import compare_source_decision_audit as method
import publish_codex_relation_resource as publisher
import run_codex_relation_comparison as executor
import verify_source_decision_resource as verifier

OUT, PUB = method.OUT, method.OUT / 'publication'
DIRECTORY = 'source_decision_audit_development'
ARCHIVE = DIRECTORY + '.tar.gz'
NAMES = ['README.md', 'resource.json', ARCHIVE, 'checksums.sha256']


def prepare():
    executor.guarded()
    method.require(method.read(OUT / 'author_answer_readback.json')['answer_cells_directly_read'] == 16, 'Root semantic readback required')
    PUB.mkdir()
    package = PUB / 'package'
    shutil.copytree(method.PRIOR / 'publication/package', package / 'prior')
    prior_locators = package / 'prior/source_locators.json'
    prior = method.read(prior_locators) if prior_locators.exists() else {}
    locators = {k: 'prior/' + v for k, v in prior.items()}

    def copy(source, relative):
        target = package / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        locators[executor.bind(source)['path']] = relative

    for name in ('questions.json', 'author_reference.json', 'root_source_readback.json', 'primary_recomparison.json',
                 'selection.json', 'preparation.json', 'protocol.json', 'direct_policy.txt', 'completion.json',
                 'mechanical_replay.json', 'author_answer_readback.json', 'source_decision_ledger_before_outputs.json',
                 'source_decision_ledger_after_outputs.json'):
        copy(OUT / name, name)
    for folder in ('inputs', 'predictions'):
        for source in sorted((OUT / folder).rglob('*')):
            if source.is_file():
                copy(source, str(source.relative_to(OUT)))
    for folder in ('prepare-guard', 'freeze-guard', 'first-calls-guard', 'collect-guard'):
        for name in ('admission.json', 'result.json', 'child.log'):
            copy(OUT / folder / name, folder + '/' + name)
    for name in ('compare_source_decision_audit.py', 'publish_source_decision_resource.py', 'verify_source_decision_resource.py'):
        copy(Path(__file__).with_name(name), 'producers/' + name)
    copy(Path(verifier.__file__), 'verify.py')
    protocol = method.read(OUT / 'protocol.json')
    bindings = []
    for record in (protocol, method.read(OUT / 'preparation.json'), method.read(OUT / 'author_reference.json'),
                   method.read(OUT / 'source_decision_ledger_before_outputs.json')):
        bindings.extend(verifier.bindings(record))
    for index, binding in enumerate(bindings):
        if binding == protocol['cli_binary']:
            continue
        if binding['path'] not in locators:
            copy(executor.verify(binding), 'dependencies/' + str(index) + '-' + Path(binding['path']).name)
    method.save(package / 'source_locators.json', locators)
    readme = '''# Source-to-decision audit development resource

Eight requests connect a scoped claim to its source occurrences, actual input
presence, first answer and admissible action. Two already exposed retained
allocations from CR1484 are reused unchanged:11974/10932 source characters under
the same12000 cap. Questions and contextual direct policy are identical between
the two new first calls. Selectors are not rerun for these new questions.

Both explicit answers recover supplied PC2 power bounds. The relation input
also supplies ordinary SCell notes; its answer recovers those conditions.
The contextual input withholds those notes, and its answer correctly keeps
similarly worded PCell evidence separate. Both preserve positive changes,
unchanged alternatives, conditional test skipping and authority/device unknowns.
The author reads all16 dependent cells; these are not16 independent examples,
general accuracy, expert gold or isolated selector effects. Nonrequested old
summary details are not relabelled wrong explicit decisions. All prior labels,
failures, source bytes and first answers remain unchanged under prior/.

Run python3 -B verify.py . or python3 -O -B verify.py . using the standard library.
The new verifier uses explicit exceptions, UTF-8 and safe package paths. It
checks every manifest file, frozen bindings, unchanged source suffixes, request
and policy reconstruction, source-group presence, literal quotes, and new raw
events→answer/usage/dispatch provenance. Each call's two known closed-config
startup warnings are retained. It does not run the archived old verifier,
rerender Word, grade meaning, prove absence of hidden executions or certify a
past empty directory. The recorded CLI version/hash identifies execution;
host binaries and authentication are not distributed. No inference in replay.

Local preparation, upload and credential-free same-host download are separate
states. The root semantic readback is an author judgment, not an automated
quote certificate or independent user evaluation. No DOI or observed users.
'''
    method.text_new(package / 'README.md', readme)
    files = [{'path': str(f.relative_to(package)), **verifier.digest(f)} for f in sorted(package.rglob('*')) if f.is_file()]
    method.save(package / 'manifest.json', {'files': files, 'development_only': True, 'expert_gold': False})
    replay = verifier.verify(package)
    method.save(PUB / 'local_replay.json', replay)
    optimized = subprocess.run([sys.executable, '-O', '-B', str(package / 'verify.py'), str(package)], capture_output=True, text=True)
    method.text_new(PUB / 'optimized_replay.stdout.txt', optimized.stdout)
    method.text_new(PUB / 'optimized_replay.stderr.txt', optimized.stderr)
    method.require(optimized.returncode == 0, 'Inspect first optimized replay failure')
    optimized_replay = json.loads(optimized.stdout)
    method.require(optimized_replay == replay, 'Normal/optimized replay differs')
    method.save(PUB / 'optimized_replay.json', optimized_replay)
    with tarfile.open(PUB / ARCHIVE, 'w:gz') as archive:
        for source in sorted(package.rglob('*')):
            if source.is_file():
                archive.add(source, arcname=str(source.relative_to(package)))
    shutil.copyfile(package / 'README.md', PUB / 'README.md')
    method.save(PUB / 'resource.json', {'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'created_utc': executor.now(),
         'producer': executor.bind(Path(__file__)), 'archive': verifier.digest(PUB / ARCHIVE), 'files': len(files) + 1,
         'new_unique_first_calls': 2, 'answer_cells': 16, 'source_components': 1, 'uploaded': False,
         'anonymous_download_verified': False, 'normal_and_optimized_replay_match': True,
         'expert_gold': False, 'doi': None, 'external_users_observed': 0})
    method.text_new(PUB / 'checksums.sha256', '\n'.join(verifier.digest(PUB / n)['sha256'] + '  ' + n for n in NAMES[:-1]) + '\n')
    print(json.dumps({'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'replay': replay}), flush=True)


def check():
    executor.guarded()
    record = method.read(PUB / 'upload.json')
    method.require(not (PUB / 'publication.json').exists(), 'Never repeat completed download verification')
    outside = Path(tempfile.mkdtemp(prefix='source-decision-anonymous-replay-'))
    download = outside / 'download'
    download.mkdir()

    def fetch(name):
        url = 'https://raw.githubusercontent.com/' + publisher.REPO + '/' + record['commit'] + '/' + DIRECTORY + '/' + name
        request = urllib.request.Request(url, headers={'User-Agent': 'source-scoped-decision-replay'})
        method.require(not any(k.lower() in ('authorization', 'cookie') for k, _ in request.header_items()), 'Credentials in anonymous request')
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        with opener.open(request, timeout=180) as response:
            raw, status = response.read(), response.status
        target = download / name
        target.write_bytes(raw)
        method.require(verifier.digest(target) == record['files'][name], 'Downloaded bytes differ')
        return name, {'url': url, 'http_status': status, **verifier.digest(target), 'authorization_header_sent': False, 'cookie_header_sent': False}

    try:
        with ThreadPoolExecutor(max_workers=4) as pool:
            downloads = dict(pool.map(fetch, NAMES))
        unpacked = outside / 'unpacked'
        unpacked.mkdir()
        with tarfile.open(download / ARCHIVE) as archive:
            archive.extractall(unpacked, filter='data')
        runs = []
        for mode in ('normal', 'optimized'):
            argv = [sys.executable] + (['-O'] if mode == 'optimized' else []) + ['-B', str(unpacked / 'verify.py'), str(unpacked)]
            result = subprocess.run(argv, cwd=unpacked, capture_output=True, text=True)
            method.text_new(PUB / ('anonymous_' + mode + '.stdout.txt'), result.stdout)
            method.text_new(PUB / ('anonymous_' + mode + '.stderr.txt'), result.stderr)
            method.require(result.returncode == 0, 'Inspect first anonymous replay failure')
            runs.append(json.loads(result.stdout))
        method.require(runs[0] == runs[1], 'Anonymous normal/optimized replay differs')
        method.save(PUB / 'publication.json', {'status': 'PUBLIC_UPLOAD_AND_ANONYMOUS_SOURCE_DECISION_PROVENANCE_REPLAY_VERIFIED',
             'observed_utc': executor.now(), 'repository': record['repository'], 'commit': record['commit'], 'directory': DIRECTORY,
             'snapshot_url': record['repository'] + '/tree/' + record['commit'] + '/' + DIRECTORY,
             'downloaded_files': downloads, 'anonymous_replay': runs[0], 'normal_and_optimized_replay_match': True,
             'outside_repository_workspace': str(outside), 'external_download_scope': 'Credential-free same-host replay outside checkout, not an independent user or machine.',
             'native_projection_rerun': False, 'meaning_certified': False, 'expert_gold': False,
             'external_users_observed': 0, 'doi': None, 'model_calls_for_replay': 0})
        print(json.dumps({'status': 'PUBLIC_UPLOAD_AND_ANONYMOUS_SOURCE_DECISION_PROVENANCE_REPLAY_VERIFIED', 'replay': runs[0]}), flush=True)
    except BaseException as error:
        method.save(PUB / 'publication_download_failure.json', {'error': repr(error), 'workspace': str(outside)})
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'upload', 'check'])
    action = parser.parse_args().action
    if action == 'upload':
        executor.guarded()
        publisher.OUT, publisher.DIRECTORY, publisher.ARCHIVE, publisher.NAMES = PUB, DIRECTORY, ARCHIVE, NAMES
        publisher.upload()
    else:
        globals()[action]()
