#!/usr/bin/env python3
"""Two exposed decision requests over unchanged retained-context allocations.

This is a task/resource diagnostic, not a new selector or causal ablation.
Availability is replayed mechanically; semantic readback remains separate.
"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

import run_codex_relation_comparison as executor

ROOT = executor.ROOT
BASE = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
PRIOR = BASE / 'priority6-retained-configuration-acquisition'
OUT = BASE / 'priority9-source-decision-audit'
MODES = ('configuration_alternative_first', 'contextual_retained_first')
SEPARATOR = '\n\nSOURCE INVENTORY\n'
UNITS_SEPARATOR = '\n\nSUPPLIED UNITS WITH OCCURRENCES\n'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def text_new(path, value):
    with path.open('x', encoding='utf-8') as stream:
        stream.write(value)


def supplied(body):
    return [json.loads(line) for line in body.split(UNITS_SEPARATOR, 1)[1].splitlines()]


def prepare():
    executor.guarded()
    questions = read(OUT / 'questions.json')['questions']
    reference = read(OUT / 'author_reference.json')
    require([q['id'] for q in questions] == [r['id'] for r in reference['requirements']], 'Question/reference IDs differ')
    require([q['id'] for q in questions] == ['C' + str(i).zfill(2) for i in range(1, 9)], 'Expected eight declared requests')
    pool = read(executor.verify(reference['pool']))
    units = {u['id']: u for u in pool['units']}
    for item in reference['requirements']:
        for anchor in item['anchors']:
            require(anchor['quote'] and anchor['quote'] in units[anchor['source_id']]['text'], 'Invalid author source anchor')
        for group in item['source_groups']:
            require(group and all(i in units for i in group), 'Invalid scoped source group')
            require(len({units[i]['text'] for i in group}) == 1, 'Aliases must preserve the same complete unit text')
    previous = read(PRIOR / 'protocol.json')
    old_policy = executor.verify(previous['policies'][MODES[0]]).read_text(encoding='utf-8')
    old_budget = 'Answer every Q in\norder, with up to 250 words each; Q2 may use up to 400 words if the technical\nchanges need it.'
    require(old_budget in old_policy, 'Preserved policy budget not found')
    policy = old_policy.replace(old_budget, 'Answer every declared decision request in order, with up to 250 words each.')
    policy = policy.replace('"id":"Q1"', '"id":"C01"').replace('Include Q1–Q4.', 'Include all eight declared IDs C01–C08.')
    text_new(OUT / 'direct_policy.txt', policy)
    (OUT / 'inputs').mkdir()
    rows, jobs = [], []
    for mode in MODES:
        prior_job = next(j for j in previous['jobs'] if j['mode'] == mode)
        old_input = executor.verify(prior_job['input'])
        old_body = old_input.read_text(encoding='utf-8')
        suffix = SEPARATOR + old_body.split(SEPARATOR, 1)[1]
        body = 'QUESTIONS\n' + json.dumps(questions, ensure_ascii=False) + suffix
        require(body != old_body, 'This must be a new request, not a summary reroll')
        data = supplied(body)
        by_id = {o['id']: u['text'] for u in data for o in u['occurrences']}
        require(sum(len(u['text']) for u in data) <= 12000, 'Source-text cap exceeded')
        inp = OUT / 'inputs' / ('row25.' + mode + '.txt')
        text_new(inp, body)
        jobs.append({'id': 'row25.' + mode, 'mode': mode, 'input': executor.bind(inp), 'prior_input': prior_job['input'],
                     'source_suffix_sha256': hashlib.sha256(suffix.encode('utf-8')).hexdigest(),
                     'source_characters': sum(len(u['text']) for u in data), 'unique_texts': len(data), 'source_occurrences': len(by_id)})
        for item in reference['requirements']:
            present = [[i for i in group if i in by_id] for group in item['source_groups']]
            technical_available = all(present) if present else None
            require(technical_available == item['expected_input_presence'][mode], 'Predeclared input presence differs: ' + item['id'])
            rows.append({'id': item['id'], 'mode': mode, 'source_groups': item['source_groups'], 'present_occurrences_by_group': present,
                         'scoped_technical_source_available': technical_available,
                         'inventory_absent_evidence_types': item['inventory_absent_evidence_types'],
                         'expected_action': item['expected_actions'][mode], 'prior_summary_readback': item['prior_summary_readback'][mode],
                         'scope_is_author_verified_not_inferred_from_quote_overlap': True})
    save(OUT / 'source_decision_ledger_before_outputs.json', {'state': 'FROZEN_SOURCE_AVAILABILITY_AND_ACTIONS_BEFORE_OUTPUTS',
         'created_utc': executor.now(), 'producer': executor.bind(Path(__file__)), 'source_pool': reference['pool'], 'rows': rows,
         'task': 'Source-scoped technical decision and justified evidence boundary, not summary completeness or general model accuracy.',
         'semantic_assessment_performed_by_this_program': False, 'answer_calls': 0})
    save(OUT / 'preparation.json', {'state': 'TWO_BALANCED_EXPOSED_REQUESTS_PREPARED', 'created_utc': executor.now(),
         'producer': executor.bind(Path(__file__)), 'jobs': jobs, 'policy': executor.bind(OUT / 'direct_policy.txt'),
         'same_questions_and_policy_between_modes': True, 'unchanged_source_suffix_per_mode': True,
         'selectors_rerun_for_new_questions': False, 'prior_summary_or_author_reference_supplied': False,
         'same_total_output_allowance_as_prior_summary': False, 'unique_first_jobs': 2, 'answer_cells': 16})
    print('TWO_BALANCED_EXPOSED_REQUESTS_PREPARED', flush=True)


def freeze():
    executor.guarded()
    previous = read(PRIOR / 'protocol.json')
    for binding in previous['dependencies'] + list(previous['policies'].values()):
        executor.verify(binding)
    preparation = read(OUT / 'preparation.json')
    for job in preparation['jobs']:
        executor.verify(job['input'])
        executor.verify(job['prior_input'])
    binary = executor.verify(previous['cli_binary'])
    auth = subprocess.run([str(binary), 'login', 'status'], capture_output=True, text=True, timeout=30)
    require(auth.returncode == 0 and 'ChatGPT' in auth.stdout + auth.stderr, 'Existing ChatGPT login unavailable')
    names = ['selection.json', 'primary_recomparison.json', 'root_source_readback.json', 'questions.json',
             'author_reference.json', 'source_decision_ledger_before_outputs.json', 'preparation.json']
    dependencies = previous['dependencies'] + [executor.bind(PRIOR / 'protocol.json')]
    dependencies += [executor.bind(OUT / n) for n in names] + [executor.bind(Path(__file__))]
    dependencies += [j['input'] for j in preparation['jobs']]
    save(OUT / 'protocol.json', {'state': 'FROZEN_BEFORE_TWO_FIRST_DECISION_RESPONSES', 'created_utc': executor.now(),
         'producer': executor.bind(Path(__file__)), 'dependencies': dependencies,
         'reference_not_supplied_to_predictions': executor.bind(OUT / 'author_reference.json'),
         'cli_binary': previous['cli_binary'], 'cli_version': subprocess.check_output([str(binary), '--version'], text=True).strip(),
         'config_overrides': previous['config_overrides'], 'sampling': previous['sampling'],
         'policies': {m: preparation['policy'] for m in MODES}, 'jobs': preparation['jobs'],
         'per_turn_wall_limit_seconds': 900, 'attempts_per_unique_input_and_policy': 1, 'retries': 0,
         'planned_unique_first_calls': 2, 'answer_cells': 16, 'independent_source_components': 1,
         'failure': 'Stop on incomplete/uncontrolled first call; preserve raw failure and do not dispatch subsequent calls or retry.',
         'exposure': 'Existing row25 component, allocation success, withheld SCell notes and summary power omissions are known to the author. Diagnostic questions/references/actions precede new outputs.',
         'comparison': 'Identical questions, answer policy and model configuration; different previously frozen source allocations. Selectors are not rerun for these questions. Different source information is not an isolated algorithm effect.',
         'claim_scope': 'Reusable source-to-request audit and exposed first-call decisions; no new selector, population accuracy, expert gold, causal output-budget effect, normative conformance certification or deployment utility.',
         'cost': 'Report actual usage/cache/request times of each first call separately. Sixteen cells share one component and two calls.',
         'protected_email_family_bodies_opened': 0})
    print('FROZEN_BEFORE_TWO_FIRST_DECISION_RESPONSES', flush=True)


def run():
    executor.guarded()
    plan = read(OUT / 'protocol.json')
    for binding in plan['dependencies'] + list(plan['policies'].values()):
        executor.verify(binding)
    executor.OUT = OUT
    (OUT / 'predictions').mkdir()
    attempts = []
    try:
        for job in plan['jobs']:
            attempts.append(job['id'])
            executor.turn(plan, OUT / 'predictions' / job['id'], job['input'], job['mode'])
    except Exception as error:
        save(OUT / 'completion.json', {'state': 'STOPPED_FIRST_FAILED_OR_UNCONTROLLED_CALL', 'finished_utc': executor.now(),
             'attempts': attempts, 'error': repr(error), 'retries': 0})
        raise
    save(OUT / 'completion.json', {'state': 'TWO_FIRST_DECISION_ANSWERS_SAVED', 'finished_utc': executor.now(), 'attempts': attempts, 'retries': 0})


def collect():
    executor.guarded()
    plan = read(OUT / 'protocol.json')
    ids = [q['id'] for q in read(OUT / 'questions.json')['questions']]
    rows = []
    for job in plan['jobs']:
        result = read(OUT / 'predictions' / job['id'] / 'result.json')
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER', 'Incomplete/uncontrolled first answer')
        answer = read(executor.verify(result['answer']))
        require([a['id'] for a in answer['answers']] == ids, 'Wrong answer IDs/order')
        input_body = executor.verify(job['input']).read_text(encoding='utf-8')
        units = {o['id']: u['text'] for u in supplied(input_body) for o in u['occurrences']}
        quotes = []
        for cell in answer['answers']:
            require(isinstance(cell['answer'], str) and cell['answer'].strip(), 'Empty decision')
            for field in ('established_facts', 'missing_information'):
                require(isinstance(cell[field], list) and all(isinstance(v, str) for v in cell[field]), 'Invalid decision field')
            require(isinstance(cell['evidence'], list) and bool(cell['evidence']), 'Evidence required for established contextual facts')
            for anchor in cell['evidence']:
                require(anchor['source_id'] in units and anchor['quote'] and anchor['quote'] in units[anchor['source_id']], 'Quote is not in actual supplied input')
                quotes.append({'answer_id': cell['id'], **anchor})
        rows.append({'mode': job['mode'], 'answer': result['answer'], 'result': executor.bind(OUT / 'predictions' / job['id'] / 'result.json'),
                     'quote_objects': len(quotes), 'quote_defects': 0, 'quotes': quotes,
                     'usage': result['turn_completed_events'][0]['usage'], 'observed_request_seconds': result['elapsed_seconds']})
    save(OUT / 'mechanical_replay.json', {'state': 'PASS_TWO_FIRST_ANSWERS_SIXTEEN_CELLS_LITERAL_QUOTES', 'created_utc': executor.now(),
         'producer': executor.bind(Path(__file__)), 'protocol': executor.bind(OUT / 'protocol.json'), 'rows': rows,
         'semantic_assessment_performed': False, 'native_projection_rerun': False, 'expert_gold': False, 'model_calls_for_verification': 0})
    print(json.dumps({'state': 'PASS_TWO_FIRST_ANSWERS_SIXTEEN_CELLS_LITERAL_QUOTES', 'quote_objects': sum(r['quote_objects'] for r in rows)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'freeze', 'run', 'collect'])
    globals()[parser.parse_args().action]()
