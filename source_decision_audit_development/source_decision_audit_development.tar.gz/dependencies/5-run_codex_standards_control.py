#!/usr/bin/env python3
"""Run fixed full-source development questions through the installed Codex CLI.

This is a measured answer-generation control, not a research delegation or
independent reference annotation. The local process contains no model weights.
Preserve every attempted turn, including failures, without automatic retries.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


ROOT = Path(__file__).resolve().parents[6]
SOURCE = ROOT / ('logs/publication/paper/ongoing/kdd-2027-research/experiments/'
                 'relation_annotation/standards_changes/development/'
                 'full_source_control/content_corrected')
OUTPUT = SOURCE / 'codex_control'


def now():
    return datetime.now(timezone.utc).isoformat()


def binding(path):
    value = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)) if path.is_relative_to(ROOT)
            else str(path), 'bytes': len(value),
            'sha256': hashlib.sha256(value).hexdigest()}


def verify(record):
    path = Path(record['path'])
    if not path.is_absolute():
        path = ROOT / path
    if binding(path) != record:
        raise ValueError(f'Frozen file changed: {path}')
    return path


def write_new(path, value):
    with path.open('x') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def prepare():
    setup = json.loads((OUTPUT / 'preparation.json').read_text())
    if setup['debug_returncode'] != 0:
        raise ValueError('Local prompt rendering did not succeed')
    cwd = Path(setup['cwd'])
    if not cwd.is_dir() or list(cwd.iterdir()):
        raise ValueError('Control working directory must be empty')
    prompts = json.loads((SOURCE / 'prompts.json').read_text())['prompts']
    questions = json.loads((SOURCE / 'questions.json').read_text())['questions']
    if [p['id'] for p in prompts] != [q['id'] for q in questions]:
        raise ValueError('Question IDs differ')
    inputs = OUTPUT / 'inputs'
    inputs.mkdir()
    frozen = []
    for entry, question in zip(prompts, questions):
        system, user = entry['messages']
        if system['role'] != 'system' or user['role'] != 'user':
            raise ValueError('Unexpected source prompt roles')
        if system['content'] != prompts[0]['messages'][0]['content']:
            raise ValueError('Control policies differ between questions')
        if question['question'] not in user['content']:
            raise ValueError('Fixed question missing from full-source prompt')
        path = inputs / (entry['id'] + '.txt')
        with path.open('x') as handle:
            handle.write(user['content'])
        if path.read_text() != user['content']:
            raise ValueError('Full-source prompt changed during serialization')
        frozen.append({'id': entry['id'], 'input': binding(path)})
    auth = subprocess.run(['codex', 'login', 'status'], capture_output=True,
                          text=True, timeout=30)
    # Do not copy credential-related command output into research artifacts.
    auth_text = auth.stdout + auth.stderr
    auth_mode = ('existing_chatgpt_login' if 'ChatGPT' in auth_text
                 else 'unverified_or_non_chatgpt_login')
    if auth.returncode != 0 or auth_mode != 'existing_chatgpt_login':
        raise ValueError('Existing ChatGPT authentication not established')
    version = subprocess.check_output(['codex', '--version'], text=True).strip()
    plan = {
        'created_utc': now(), 'producer': binding(Path(__file__).resolve()),
        'source_prompts': binding(SOURCE / 'prompts.json'),
        'source_packet': binding(SOURCE / 'source_packet.txt'),
        'source_units': binding(SOURCE / 'source_units.json'),
        'questions': binding(SOURCE / 'questions.json'),
        'system_policy': binding(OUTPUT / 'system_policy.txt'),
        'local_context_render': binding(OUTPUT / 'debug_prompt_input.json'),
        'preparation': binding(OUTPUT / 'preparation.json'),
        'inputs': frozen, 'cwd': str(cwd), 'cli_version': version,
        'authentication': auth_mode,
        'declared_model': 'gpt-6.1-sol', 'reasoning_effort': 'medium',
        'model_selection': 'Existing user CLI model and effort; no model migration.',
        'exact_root_model_identity': 'not_established',
        'sampling': 'Provider/CLI defaults; temperature, seed and output cap not controlled.',
        'comparison': 'Same saved full-source user text and four development questions as the local control.',
        'system_policy_change': 'Original 1597-character source policy plus prohibition of outside evidence and tools.',
        'history': 'Fresh ephemeral turns; no resume, reference answer, previous answer or researcher conversation provided.',
        'independence': 'Development-selected questions and researcher-exposed assessment; not independent semantic gold.',
        'additional_harness_context': 'CLI-generated permission, skills and environment instructions; local debug snapshot retained.',
        'tool_policy': 'External tool features disabled; any observed tool item invalidates the controlled condition and stops remaining turns.',
        'config_overrides': setup['config_overrides'],
        'auto_compact_token_limit': 180000,
        'context_capacity': 'Actual model tokenizer/window not inferred from the previous GGUF tokenizer.',
        'execution_policy': {'order': [x['id'] for x in frozen],
                             'parallelism': 1, 'max_attempts_per_question': 1,
                             'per_turn_wall_limit_seconds': 1200,
                             'on_failure': 'Preserve attempted turn and stop; remaining questions unattempted.'},
        'local_resources': {'model_weights_loaded': False, 'gpu_layers': 0,
                            'memory_max_gib': 2, 'memory_high_gib': 1,
                            'swap_max_bytes': 0, 'cpu_affinity': [0, 1],
                            'nice': 19, 'host_and_wsl_free_reserve_gib': 16},
        'target_requests_before_plan': 0, 'independent_human_labels': 0,
        'prior_local_control': {'dispatched': 1, 'saved_responses': 0,
                                'state': 'TERMINAL_TIMEOUT_WITHOUT_RESPONSES',
                                'pooled_with_this_control': False},
    }
    write_new(OUTPUT / 'plan.json', plan)
    print(json.dumps({'state': 'PREPARED', 'inputs': len(frozen),
                      'model_requests': 0, 'authentication': auth_mode}), flush=True)


def run():
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    for key in ('producer', 'source_prompts', 'source_packet', 'source_units',
                'questions', 'system_policy', 'local_context_render', 'preparation'):
        verify(plan[key])
    for item in plan['inputs']:
        verify(item['input'])
    if sorted(os.sched_getaffinity(0)) != [0, 1] or os.getpriority(os.PRIO_PROCESS, 0) != 19:
        raise ValueError('Run this only under the verified resource guard')
    work = Path(plan['cwd'])
    if not work.is_dir() or list(work.iterdir()):
        raise ValueError('Control working directory is no longer empty')
    output = OUTPUT / 'run'
    output.mkdir()
    results = []
    for entry in plan['inputs']:
        qid = entry['id']
        qout = output / qid
        qout.mkdir()
        argv = ['codex', 'exec', '--ignore-user-config', '--ignore-rules',
                '--strict-config', '--ephemeral', '--skip-git-repo-check',
                '--sandbox', 'read-only', '--cd', str(work), '--json',
                '--color', 'never', '--output-last-message', str(qout / 'answer.txt')]
        overrides = plan['config_overrides'] + [
            'model=' + json.dumps(plan['declared_model']),
            'model_reasoning_effort=' + json.dumps(plan['reasoning_effort']),
            'model_auto_compact_token_limit=180000', 'approval_policy="never"']
        for value in overrides:
            argv += ['-c', value]
        argv.append('-')
        dispatch = {'id': qid, 'started_utc': now(), 'argv': argv,
                    'input': entry['input'], 'condition': 'full_source_codex_development_control'}
        write_new(qout / 'dispatch.json', dispatch)
        print(json.dumps({'state': 'DISPATCHED', 'id': qid}), flush=True)
        start = time.monotonic()
        timed_out = False
        with verify(entry['input']).open('rb') as stdin, (qout / 'events.jsonl').open('xb') as stdout, (qout / 'stderr.txt').open('xb') as stderr:
            child = subprocess.Popen(argv, stdin=stdin, stdout=stdout, stderr=stderr)
            try:
                code = child.wait(timeout=plan['execution_policy']['per_turn_wall_limit_seconds'])
            except subprocess.TimeoutExpired:
                timed_out = True
                child.terminate()
                try:
                    code = child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
                    code = child.wait(timeout=10)
        events, unparsable = [], []
        for i, line in enumerate((qout / 'events.jsonl').read_text().splitlines(), 1):
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                unparsable.append(i)
        # Agent messages and exposed reasoning summaries contain no tool results.
        tool_events = [e for e in events if e.get('type', '').startswith('item.')
                       and e.get('item', {}).get('type') not in ('agent_message', 'reasoning')]
        completed = [e for e in events if e.get('type') == 'turn.completed']
        final = qout / 'answer.txt'
        result = {'id': qid, 'finished_utc': now(), 'elapsed_seconds': time.monotonic() - start,
                  'returncode': code, 'timed_out': timed_out,
                  'event_count': len(events), 'unparsable_lines': unparsable,
                  'turn_completed_events': completed,
                  'unexpected_tool_events': tool_events,
                  'errors': [e for e in events if e.get('type') in ('error', 'turn.failed')],
                  'answer': binding(final) if final.exists() else None,
                  'events': binding(qout / 'events.jsonl'), 'stderr': binding(qout / 'stderr.txt'),
                  'semantic_assessment': 'not_yet_performed'}
        clean = bool(code == 0 and not timed_out and len(completed) == 1
                     and not tool_events and not unparsable and final.exists()
                     and final.stat().st_size)
        result['state'] = 'SAVED_CONTROLLED_ANSWER' if clean else 'FAILED_OR_UNCONTROLLED_TURN'
        write_new(qout / 'result.json', result)
        results.append(result)
        print(json.dumps({'id': qid, 'state': result['state'],
                          'answer_bytes': result['answer']['bytes'] if result['answer'] else 0,
                          'elapsed_seconds': result['elapsed_seconds']}), flush=True)
        if not clean:
            break
    summary = {'finished_utc': now(), 'plan': binding(OUTPUT / 'plan.json'),
               'attempted': len(results),
               'saved_controlled_answers': sum(r['state'] == 'SAVED_CONTROLLED_ANSWER' for r in results),
               'unattempted': [e['id'] for e in plan['inputs'][len(results):]],
               'results': [binding(output / r['id'] / 'result.json') for r in results],
               'independent_human_labels': 0, 'independent_semantic_gold': 0,
               'semantic_assessment': 'not_yet_performed'}
    write_new(output / 'summary.json', summary)
    return 0 if summary['saved_controlled_answers'] == len(plan['inputs']) else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('prepare', 'run'))
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare()
    else:
        raise SystemExit(run())
