#!/usr/bin/env python3
"""Continue unattempted fixed Codex inputs after replaying CLI startup warnings.

The initial collector mistook two nonfatal configuration warnings for tool
executions. Preserve that collector and its results; do not regenerate SC01.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import time

spec = importlib.util.spec_from_file_location(
    'fixed_codex_control', Path(__file__).with_name('run_codex_standards_control.py'))
control = importlib.util.module_from_spec(spec)
spec.loader.exec_module(control)
OUTPUT = control.OUTPUT


def inspect_events(path):
    events = [json.loads(line) for line in path.read_text().splitlines()]
    warnings, unexpected = [], []
    for event in events:
        item = event.get('item', {})
        if not event.get('type', '').startswith('item.'):
            continue
        if item.get('type') in ('agent_message', 'reasoning'):
            continue
        message = item.get('message', '')
        startup_warning = (item.get('type') == 'error' and
                           (message.startswith('Under-development features enabled: skip_host_skill_discovery.')
                            or message.startswith('Code Mode is unavailable because code-mode host is disabled.')))
        if startup_warning:
            warnings.append(event)
        else:
            unexpected.append(event)
    completed = [e for e in events if e.get('type') == 'turn.completed']
    errors = [e for e in events if e.get('type') in ('error', 'turn.failed')]
    return {'event_count': len(events), 'startup_warnings': warnings,
            'unexpected_tool_or_item_events': unexpected,
            'turn_completed_events': completed, 'errors': errors}


def prepare():
    plan = json.loads((OUTPUT / 'plan.json').read_text())
    for key in ('producer', 'source_prompts', 'source_packet', 'source_units',
                'questions', 'system_policy', 'local_context_render', 'preparation'):
        control.verify(plan[key])
    initial = OUTPUT / 'run/SC01'
    result = json.loads((initial / 'result.json').read_text())
    control.verify(result['answer'])
    replay = inspect_events(control.verify(result['events']))
    if result['returncode'] != 0 or result['timed_out'] or replay['errors'] or replay['unexpected_tool_or_item_events'] or len(replay['turn_completed_events']) != 1:
        raise ValueError('Initial turn is not controlled and complete')
    remaining = [x for x in plan['inputs'] if x['id'] != 'SC01']
    if json.loads((OUTPUT / 'run/summary.json').read_text())['unattempted'] != [x['id'] for x in remaining]:
        raise ValueError('Continuation would repeat an attempted question')
    record = {'created_utc': control.now(), 'producer': control.binding(Path(__file__).resolve()),
              'original_plan': control.binding(OUTPUT / 'plan.json'),
              'initial_result': control.binding(initial / 'result.json'),
              'initial_answer': result['answer'], 'initial_event_replay': replay,
              'initial_controlled_answers': 1, 'remaining_inputs': remaining,
              'repair': 'Two explicit CLI startup warnings are not tool executions. Preserve original classification; recognize the saved answer by event replay.',
              'first_answer_regenerated': False, 'inputs_or_questions_changed': False,
              'remaining_model_requests_at_preparation': 0,
              'semantic_assessment': 'not_yet_performed'}
    control.write_new(OUTPUT / 'continuation_plan.json', record)
    print(json.dumps({'state': 'PREPARED_REMAINING', 'initial_answer_replayed': True,
                      'remaining': [x['id'] for x in remaining]}), flush=True)


def run():
    continuation = json.loads((OUTPUT / 'continuation_plan.json').read_text())
    control.verify(continuation['producer'])
    plan = json.loads(control.verify(continuation['original_plan']).read_text())
    for key in ('producer', 'source_prompts', 'source_packet', 'source_units',
                'questions', 'system_policy', 'local_context_render', 'preparation'):
        control.verify(plan[key])
    for entry in plan['inputs']:
        control.verify(entry['input'])
    if sorted(control.os.sched_getaffinity(0)) != [0, 1] or control.os.getpriority(control.os.PRIO_PROCESS, 0) != 19:
        raise ValueError('Continuation requires the resource guard')
    if list(Path(plan['cwd']).iterdir()):
        raise ValueError('Control working directory is no longer empty')
    output = OUTPUT / 'remaining_run'
    output.mkdir()
    results = []
    for entry in continuation['remaining_inputs']:
        qid = entry['id']
        qout = output / qid
        qout.mkdir()
        argv = ['codex', 'exec', '--ignore-user-config', '--ignore-rules',
                '--strict-config', '--ephemeral', '--skip-git-repo-check',
                '--sandbox', 'read-only', '--cd', plan['cwd'], '--json',
                '--color', 'never', '--output-last-message', str(qout / 'answer.txt')]
        overrides = plan['config_overrides'] + [
            'model=' + json.dumps(plan['declared_model']),
            'model_reasoning_effort=' + json.dumps(plan['reasoning_effort']),
            'model_auto_compact_token_limit=180000', 'approval_policy="never"']
        for value in overrides:
            argv += ['-c', value]
        argv.append('-')
        control.write_new(qout / 'dispatch.json', {'id': qid, 'started_utc': control.now(),
                                                  'argv': argv, 'input': entry['input']})
        print(json.dumps({'state': 'DISPATCHED', 'id': qid}), flush=True)
        start = time.monotonic()
        timed_out = False
        with control.verify(entry['input']).open('rb') as stdin, (qout / 'events.jsonl').open('xb') as stdout, (qout / 'stderr.txt').open('xb') as stderr:
            child = subprocess.Popen(argv, stdin=stdin, stdout=stdout, stderr=stderr)
            try:
                code = child.wait(timeout=plan['execution_policy']['per_turn_wall_limit_seconds'])
            except subprocess.TimeoutExpired:
                timed_out = True
                child.terminate()
                try:
                    code = child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill()
                    code = child.wait(timeout=10)
        replay = inspect_events(qout / 'events.jsonl')
        final = qout / 'answer.txt'
        clean = (code == 0 and not timed_out and not replay['errors']
                 and not replay['unexpected_tool_or_item_events']
                 and len(replay['turn_completed_events']) == 1
                 and final.exists() and final.stat().st_size > 0)
        result = {'id': qid, 'finished_utc': control.now(),
                  'elapsed_seconds': time.monotonic() - start, 'returncode': code,
                  'timed_out': timed_out, **replay,
                  'answer': control.binding(final) if final.exists() else None,
                  'events': control.binding(qout / 'events.jsonl'),
                  'stderr': control.binding(qout / 'stderr.txt'),
                  'state': 'SAVED_CONTROLLED_ANSWER' if clean else 'FAILED_OR_UNCONTROLLED_TURN',
                  'semantic_assessment': 'not_yet_performed'}
        control.write_new(qout / 'result.json', result)
        results.append(result)
        print(json.dumps({'id': qid, 'state': result['state'],
                          'elapsed_seconds': result['elapsed_seconds']}), flush=True)
        if not clean:
            break
    summary = {'finished_utc': control.now(), 'continuation_plan': control.binding(OUTPUT / 'continuation_plan.json'),
               'attempted': len(results),
               'saved_controlled_answers': sum(r['state'] == 'SAVED_CONTROLLED_ANSWER' for r in results),
               'unattempted': [e['id'] for e in continuation['remaining_inputs'][len(results):]],
               'results': [control.binding(output / r['id'] / 'result.json') for r in results],
               'initial_answer_preserved': True, 'independent_semantic_gold': 0}
    control.write_new(output / 'summary.json', summary)
    return 0 if summary['saved_controlled_answers'] == len(continuation['remaining_inputs']) else 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('prepare', 'run'))
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare()
    else:
        raise SystemExit(run())
