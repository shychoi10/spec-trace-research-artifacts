#!/usr/bin/env python3
"""Replay saved matched inputs, actions, literal witnesses and actual charges.

Only the Python standard library is used. Meaning judgments are exposed author
annotations, not inferred by this verifier. No model, corpus or network is used.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path, PurePosixPath

MARKER = '\n\nSUPPLIED UNITS WITH OCCURRENCES\n'
QIDS = ['Q1', 'Q2', 'Q3', 'Q4']
ACTIONS = {'Retain', 'Acquire', 'Ask explicitly', 'Keep unknown'}
STATUSES = {'covered', 'partial', 'absent', 'contradicted', 'uncertain'}


def require(value, message):
    if not value:
        raise ValueError(message)


def strict_json(raw):
    def pairs(rows):
        value = {}
        for key, item in rows:
            require(key not in value, 'Duplicate JSON key: ' + key)
            value[key] = item
        return value

    def constant(value):
        raise ValueError('Non-JSON numeric constant: ' + value)

    return json.loads(raw, object_pairs_hook=pairs, parse_constant=constant)


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def identity(value):
    return {key: value[key] for key in ('bytes', 'sha256')}


def safe_member(base, name):
    part = PurePosixPath(name)
    require(isinstance(name, str) and name and not part.is_absolute()
            and '..' not in part.parts and str(part) == name, 'Unsafe member: ' + str(name))
    path = base / name
    require(path.is_file() and not path.is_symlink(), 'Missing/symlink member: ' + name)
    require(path.resolve().is_relative_to(base.resolve()), 'Member leaves packet')
    return path


def source_input(path):
    raw = path.read_text(encoding='utf-8')
    require(raw.count(MARKER) == 1, 'Wrong supplied source grammar')
    header, tail = raw.split(MARKER)
    units = [strict_json(line) for line in tail.splitlines()]
    result = {}
    for unit in units:
        require(isinstance(unit['text'], str) and isinstance(unit['occurrences'], list),
                'Wrong source body/occurrences')
        for occurrence in unit['occurrences']:
            key = occurrence['id']
            require(isinstance(key, str) and key and key not in result,
                    'Repeated/empty actual supplied occurrence')
            result[key] = unit['text']
    require(result, 'No actual sources')
    return header, units, result


def encode_input(header, units):
    return header + MARKER + '\n'.join(json.dumps(u, ensure_ascii=False,
        separators=(',', ':')) for u in units) + '\n'


def evidence(rows, sources):
    require(isinstance(rows, list), 'Evidence is not an array')
    for row in rows:
        require(isinstance(row, dict) and set(row) == {'source_id', 'quote'},
                'Wrong evidence fields')
        require(row['source_id'] in sources and isinstance(row['quote'], str)
                and row['quote'] and row['quote'] in sources[row['source_id']],
                'Not a literal quote of an actual supplied occurrence')
    return len(rows)


def nonempty(value):
    return isinstance(value, str) and bool(value.strip())


def decisions(rows, sources):
    require(isinstance(rows, list) and len(rows) == 4, 'Four decisions required')
    total = 0
    fields = {'id', 'action', 'reason', 'source_ids', 'evidence', 'followup_question'}
    for qid, row in zip(QIDS, rows):
        require(isinstance(row, dict) and set(row) == fields and row['id'] == qid
                and row['action'] in ACTIONS and nonempty(row['reason']), 'Wrong decision')
        ids = row['source_ids']
        require(isinstance(ids, list) and all(x in sources for x in ids),
                'Decision names an unsupplied source')
        total += evidence(row['evidence'], sources)
        require(isinstance(row['followup_question'], str), 'Wrong followup question')
        if row['action'] == 'Ask explicitly':
            require(ids and row['evidence'] and row['followup_question'].strip(),
                    'Ask has no source witness')
        else:
            require(row['followup_question'] == '', 'Non-Ask has a followup question')
    return total


def narrative(value, sources):
    require(isinstance(value, dict) and list(value) == ['answers']
            and [r['id'] for r in value['answers']] == QIDS, 'Wrong narrative shape/order')
    total = 0
    for row in value['answers']:
        require(nonempty(row['answer']), 'Empty answer')
        for field in ('established_facts', 'missing_information'):
            require(isinstance(row[field], list) and all(isinstance(v, str) for v in row[field]),
                    'Wrong substantive string array')
        total += evidence(row['evidence'], sources)
    return {'literal_quotes_checked': total, 'answer_cells': 4}


def ledger(value, sources):
    require(isinstance(value, dict) and set(value) == {'obligations', 'unestablished'},
            'Wrong ledger shape')
    fields = {'key', 'question_ids', 'proposition', 'applicability_conditions',
              'retained_alternatives', 'role', 'version', 'evidence'}
    keys, qids, count = [], set(), 0
    require(isinstance(value['obligations'], list) and value['obligations'], 'Empty ledger')
    for row in value['obligations']:
        require(isinstance(row, dict) and set(row) == fields and nonempty(row['key'])
                and row['key'] not in keys, 'Wrong/repeated obligation key')
        keys.append(row['key'])
        ids = row['question_ids']
        require(isinstance(ids, list) and ids and len(ids) == len(set(ids))
                and all(q in QIDS for q in ids), 'Wrong ledger question scope')
        qids.update(ids)
        require(all(nonempty(row[f]) for f in ('proposition', 'role', 'version')), 'Empty ledger field')
        for field in ('applicability_conditions', 'retained_alternatives'):
            require(isinstance(row[field], list) and all(isinstance(v, str) for v in row[field]),
                    'Wrong obligation string array')
        require(row['evidence'], 'Obligation has no witness')
        count += evidence(row['evidence'], sources)
    require({'Q1', 'Q2'} <= qids, 'Missing Q1/Q2 ledger scope')
    unknown = set()
    require(isinstance(value['unestablished'], list), 'Wrong unknown entries')
    for row in value['unestablished']:
        require(set(row) == {'question_id', 'needed_evidence', 'why_not_established', 'evidence'}
                and row['question_id'] in QIDS and nonempty(row['needed_evidence'])
                and nonempty(row['why_not_established']), 'Wrong unknown ledger entry')
        unknown.add(row['question_id'])
        count += evidence(row['evidence'], sources)
    require({'Q3', 'Q4'} <= unknown, 'Missing unknown scope')
    return {'literal_quotes_checked': count, 'obligation_cells': len(keys),
            'unestablished_cells': len(value['unestablished'])}


def audit(value, sources, prior_ledger, first):
    require(set(value) == {'coverage', 'decisions'}
            and len(value['coverage']) == len(prior_ledger['obligations']), 'Wrong audit denominator')
    texts = {r['id']: [r['answer'], *r['established_facts'], *r['missing_information']]
             for r in first['answers']}
    spans = 0
    for row, obligation in zip(value['coverage'], prior_ledger['obligations']):
        require(set(row) == {'key', 'status', 'reason', 'answer_spans'}
                and row['key'] == obligation['key'] and row['status'] in STATUSES
                and nonempty(row['reason']) and isinstance(row['answer_spans'], list), 'Wrong audit row')
        for span in row['answer_spans']:
            require(set(span) == {'question_id', 'quote'} and span['question_id'] in texts
                    and nonempty(span['quote'])
                    and any(span['quote'] in t for t in texts[span['question_id']]),
                    'Audit span is not literal substantive first-answer text')
            spans += 1
        require(row['status'] != 'covered' or row['answer_spans'], 'Covered without span')
    return {'literal_quotes_checked': decisions(value['decisions'], sources),
            'coverage_cells': len(value['coverage']), 'answer_spans_checked': spans}


def close_numbers(actual, expected, label):
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), label + ' keys differ')
        for key in expected:
            close_numbers(actual[key], expected[key], label + '/' + key)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), label + ' length differs')
        for index, (item, wanted) in enumerate(zip(actual, expected)):
            close_numbers(item, wanted, label + '/' + str(index))
    elif isinstance(expected, float):
        require(isinstance(actual, (float, int)) and math.isclose(actual, expected,
                rel_tol=1e-12, abs_tol=1e-9), label + ' duration differs')
    else:
        require(actual == expected, label + ' differs')


def verify_resource(directory):
    base = directory.resolve()
    manifest = strict_json(safe_member(base, 'manifest.json').read_text(encoding='utf-8'))
    require(manifest['format'] == 'MATCHED_SAVED_RETURN_REPLAY' and manifest['schema'] == 1,
            'Unsupported format')
    entries = manifest['entries']
    require(len(entries) == len({x['member'] for x in entries}), 'Duplicate manifest member')
    members = {x['member'] for x in entries}
    require({p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file()}
            == members | {'manifest.json'}, 'Packet membership differs')
    original = {}
    for row in entries:
        path = safe_member(base, row['member'])
        require(digest(path) == identity(row), 'Changed packet member: ' + row['member'])
        for source in row.get('original_bindings', []):
            require(identity(source) == identity(row), 'Original/copy identity differs')
            old = original.get(source['path'])
            require(old is None or old == row['member'], 'Ambiguous original locator')
            original[source['path']] = row['member']

    def bound(binding):
        require(binding['path'] in original, 'Unadmitted original locator: ' + binding['path'])
        path = safe_member(base, original[binding['path']])
        require(digest(path) == identity(binding), 'Bound original byte identity differs')
        return path

    def load(binding):
        return strict_json(bound(binding).read_text(encoding='utf-8'))

    plan = strict_json(safe_member(base, 'method.json').read_text(encoding='utf-8'))
    accounting = load(plan['accounting'])
    require(plan['independent_trials'] is False and plan['expert_gold'] is False
            and plan['automatic_retries'] == 0 and plan['targeted_source_locations_only'] is True,
            'Wrong exposure/retry/fact injection boundary')
    require([c['id'] for c in plan['cases']] == ['CR3217', 'CR0842', 'CR0002'], 'Wrong fixed cases')
    require(len(plan['primary_jobs']) == 15 and len(plan['targeted_jobs']) == 5
            and len(set(plan['targeted_jobs'])) == 5, 'Wrong first-return job population')
    all_ids = [j['id'] for j in plan['primary_jobs']] + plan['targeted_jobs']
    require(len(all_ids) == len(set(all_ids)) == 20, 'Wrong/duplicate physical population')
    rows = {r['job']: r for r in accounting['physical_returns']}
    require(len(rows) == len(accounting['physical_returns']) and set(rows) == set(all_ids),
            'Accounting population differs')
    require(accounting['protocol'] == plan['original_protocol_opaque']
            and accounting['followup_admission'] == plan['original_followup_admission_opaque'],
            'Frozen accounting control identity differs')
    answers, counters = {}, {'literal_quotes_checked': 0, 'answer_cells': 0,
                            'obligation_cells': 0, 'decision_cells': 0}
    sources, case_map = {}, {c['id']: c for c in plan['cases']}
    for case in plan['cases']:
        cid = case['id']
        header, units, supply = source_input(bound(case['first_input']))
        sources[cid] = supply
        require(bound(case['original_source_input']).read_bytes() == bound(case['first_input']).read_bytes(),
                'Acquired input is not byte-identical original source input')
        require(sorted(supply) == case['all_available_scoped_occurrences'], 'Wrong available inventory')
        partial = [{**u, 'occurrences': [o for o in u['occurrences'] if o['role'] != 'target']}
                   for u in units if any(o['role'] != 'target' for o in u['occurrences'])]
        require([a['id'] for a in case['initial_allocations']] == ['target_withheld', 'intact'],
                'Wrong initial allocation pair')
        for allocation in case['initial_allocations']:
            _, _, before = source_input(bound(allocation['input']))
            require(set(before) <= set(supply) and all(supply[k] == t for k, t in before.items()),
                    'Inventory completion changes body or fabricates availability')
            require(allocation['initial_supplied_occurrences'] == len(before)
                    and allocation['acquired_occurrences'] == sorted(set(supply) - set(before))
                    and allocation['acquired_unique_source_characters'] == sum(
                        len(t) for t in set(supply.values()) - set(before.values())),
                    'Inventory ID/body/character charge differs')
            if allocation['id'] == 'target_withheld':
                require(bound(allocation['input']).read_text(encoding='utf-8') == encode_input(header, partial),
                        'Withheld input is not target-occurrence removal')
            else:
                require(bound(allocation['input']).read_bytes() == bound(case['first_input']).read_bytes(),
                        'Intact allocation differs')
        reference = load(case['references'])
        require(reference.get('expert_gold', reference.get('independent_expert_gold')) is False,
                'Reference is incorrectly labelled expert gold')

    for name in all_ids:
        cid, kind = name.split('.', 1)
        row = rows[name]
        check, result, dispatch = load(row['mechanical_check']), load(row['result']), load(row['dispatch'])
        value = load(row['answer'])
        answers[name] = value
        require(check['state'] == 'JSON_AND_LITERAL_REPLAY_PASS' and check['job'] == name
                and check['protocol'] == plan['original_protocol_opaque'], 'Wrong mechanical identity')
        for field in ('input', 'answer', 'result', 'dispatch'):
            require(row[field] == check[field], 'Accounting/check identity differs')
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER' and result['returncode'] == 0
                and result['timed_out'] is False and len(result['turn_completed_events']) == 1
                and not result['unexpected_tool_or_item_events'] and not result['errors'],
                'Not a completed controlled first return')
        require(result['answer'] == row['answer'] and dispatch['input'] == row['input']
                and dispatch['empty_cwd_at_dispatch'] is True, 'Input/answer dispatch differs')
        usage = result['turn_completed_events'][0]['usage']
        require({'input_tokens', 'output_tokens', 'cached_input_tokens'} <= set(usage)
                and all(type(v) is int and v >= 0 for v in usage.values())
                and usage['cached_input_tokens'] <= usage['input_tokens'], 'Invalid provider charge')
        require(row['raw_provider_usage'] == usage and row['request_seconds'] == result['elapsed_seconds'],
                'Provider usage/request charge differs')
        policy = kind if kind in ('ledger', 'triage', 'audit') else 'direct'
        require(dispatch['policy'] == plan['policies'][policy], 'Wrong actual policy')
        argv = dispatch['argv']
        require(argv.count('-') == 1 and '--ignore-user-config' in argv and '--ignore-rules' in argv
                and '--ephemeral' in argv and '--json' in argv and '--strict-config' in argv,
                'Runtime isolation flags absent')
        overrides = [argv[i + 1] for i, value_ in enumerate(argv[:-1]) if value_ == '-c']
        extra = 'model_instructions_file=' + json.dumps(str(Path(argv[argv.index('--output-last-message') + 1]).parents[2]
                     / (policy + '_policy.txt')))
        # Host paths are preserved records. Compare each declared override, then
        # permit only the one exact policy-path override present at dispatch.
        require(len(overrides) == len(plan['config_overrides']) + 1
                and overrides[:len(plan['config_overrides'])] == plan['config_overrides']
                and overrides[-1] == extra, 'Runtime settings or policy path differ')
        require('--sandbox' in argv and argv[argv.index('--sandbox') + 1] == 'read-only', 'Sandbox differs')
        header, units, supply = source_input(bound(case_map[cid]['first_input']))
        _, _, actual_supply = source_input(bound(row['input']))
        require(actual_supply == supply, 'An execution received different sources')
        if kind not in ('ledger', 'first'):
            header += '\n\nFROZEN FIRST ANSWER (FALLIBLE, NOT GOLD)\n' + json.dumps(
                answers[cid + '.first'], ensure_ascii=False)
        if kind == 'generic':
            header += '\n\nFOLLOWUP REQUEST\n' + plan['generic_request']
        if kind == 'audit':
            header += '\n\nSOURCE-ONLY CONDITION LEDGER (FALLIBLE, NOT GOLD)\n' + json.dumps(
                answers[cid + '.ledger'], ensure_ascii=False)
        if kind in ('triage_targeted', 'audit_targeted'):
            diagnosis = 'triage' if kind == 'triage_targeted' else 'audit'
            asks = [r for r in answers[cid + '.' + diagnosis]['decisions'] if r['action'] == 'Ask explicitly']
            require(asks, 'Conditional followup without an actual first Ask')
            locations = [{'question_id': r['id'], 'source_ids': r['source_ids']} for r in asks]
            header += '\n\nFOLLOWUP REQUEST\n' + plan['targeted_request'] + '\n' + json.dumps(locations)
        require(bound(row['input']).read_text(encoding='utf-8') == encode_input(header, units),
                'Input differs from source/first-answer/fact-free request recipe')
        if kind == 'ledger':
            observed = ledger(value, supply)
        elif kind == 'triage':
            require(set(value) == {'decisions'}, 'Wrong triage object')
            observed = {'literal_quotes_checked': decisions(value['decisions'], supply), 'decision_cells': 4}
        elif kind == 'audit':
            observed = audit(value, supply, answers[cid + '.ledger'], answers[cid + '.first'])
            counters['decision_cells'] += 4
        else:
            observed = narrative(value, supply)
        for key, number in observed.items():
            require(check[key] == number, 'Original mechanical counter differs: ' + key)
            if key in counters:
                counters[key] += number
        events = [strict_json(line) for line in bound(result['events']).read_text(encoding='utf-8').splitlines()]
        require(len(events) == result['event_count'] and [e for e in events if e['type'] == 'turn.completed']
                == result['turn_completed_events'], 'Actual CLI events/usage differ')
        require([e['item']['text'] for e in events if e['type'] == 'item.completed'
                and e.get('item', {}).get('type') == 'agent_message'] == [bound(row['answer']).read_text(encoding='utf-8')],
                'Saved answer differs from actual first CLI agent message')
        require(all(e['type'] in ('thread.started', 'turn.started', 'turn.completed', 'item.completed')
                    and (e['type'] != 'item.completed' or e['item']['type'] in ('agent_message', 'error'))
                    for e in events), 'Unexpected tool event in closed runtime')

    for case in plan['cases']:
        cid = case['id']
        for diagnosis in ('triage', 'audit'):
            asks = [r for r in answers[cid + '.' + diagnosis]['decisions'] if r['action'] == 'Ask explicitly']
            require((cid + '.' + diagnosis + '_targeted' in plan['targeted_jobs']) == bool(asks),
                    'Actual Ask and one-followup dispatch do not agree')
        ledger_result = load(rows[cid + '.ledger']['result'])
        first_dispatch = load(rows[cid + '.first']['dispatch'])
        require(ledger_result['finished_utc'] < first_dispatch['started_utc'],
                'Source-only ledger did not precede first answer')

    def total(ids, duplicates=False):
        require(duplicates or len(ids) == len(set(ids)), 'Duplicate physical charge in one unique workflow')
        usage_keys = set().union(*(rows[x]['raw_provider_usage'] for x in ids))
        return {'calls': len(ids), 'provider_usage_sum': {
            k: sum(rows[x]['raw_provider_usage'].get(k, 0) for x in ids) for k in sorted(usage_keys)},
            'request_seconds_sum': sum(rows[x]['request_seconds'] for x in ids)}

    unique, paired = [], []
    policies = [('inventory_stop', ['first']), ('inventory_generic', ['first', 'generic']),
                ('inventory_answer_first', ['first', 'triage']), ('inventory_ledger_audit', ['ledger', 'first', 'audit'])]
    for case in plan['cases']:
        cid = case['id']
        for policy, base_stages in policies:
            stages = list(base_stages)
            if policy in ('inventory_answer_first', 'inventory_ledger_audit'):
                diagnosis = 'triage' if policy == 'inventory_answer_first' else 'audit'
                target = cid + '.' + diagnosis + '_targeted'
                if target in plan['targeted_jobs']:
                    stages.append(diagnosis + '_targeted')
            ids = [cid + '.' + k for k in stages]
            item = {'case': cid, 'policy': policy, 'physical_job_ids': ids,
                    'final_answer_job': ids[-1] if stages[-1] in ('generic', 'triage_targeted', 'audit_targeted')
                    else cid + '.first', **total(ids)}
            unique.append(item)
            paired.extend({**item, 'initial_allocation': a['id'], 'exact_acquired_input': case['first_input'],
                'dependent_shared_first_returns': True, 'acquired_occurrences': a['acquired_occurrences'],
                'acquired_unique_source_characters': a['acquired_unique_source_characters']}
                for a in case['initial_allocations'])
    require(len(unique) == 12 and len(paired) == 24 and accounting['case_count'] == 3
            and accounting['unique_workflow_count'] == 12 and accounting['paired_dependent_workflow_count'] == 24
            and accounting['new_research_model_calls'] == 20 and accounting['independent_trials'] is False,
            'Workflow population or independence label differs')
    close_numbers(accounting['unique_case_policy_workflows'], unique, 'Unique workflows')
    close_numbers(accounting['paired_allocation_policy_workflows'], paired, 'Dependent workflows')
    close_numbers(accounting['all_unique_physical'], total(all_ids), 'Physical totals')
    groups = {p: total([x for w in unique if w['policy'] == p for x in w['physical_job_ids']])
              for p, _ in policies}
    close_numbers(accounting['policy_totals_unique_cases'], groups, 'Policy totals')
    logical = total([x for w in paired for x in w['physical_job_ids']], duplicates=True)
    close_numbers(accounting['all_dependent_logical'], logical, 'Dependent logical totals')
    require(logical['calls'] == 58 and counters == {'literal_quotes_checked': 655,
                'answer_cells': 44, 'obligation_cells': 46, 'decision_cells': 24},
            'Observed first-return mechanical population differs')
    semantic = load(plan['author_semantic_readback'])
    require(semantic['owner'] == 'root' and semantic['protocol'] == plan['original_protocol_opaque']
            and semantic['accounting'] == plan['accounting'], 'Author annotation source identities differ')
    require(len({r['path'] for r in plan['unchanged_references']}) == 2
            and semantic['unchanged_references'] == plan['unchanged_references'],
            'Unchanged author-reference identity differs')
    require(semantic['independent_expert_gold'] is False
            and semantic['root_assessment_not_machine_semantic_certification'] is True,
            'Authored meaning must not become a mechanical certificate')
    for witness in semantic['central_source_witnesses']:
        case = case_map[witness['case']]
        require(witness['input'] == case['first_input']
                and sources[witness['case']].get(witness['source_id']) == witness['text'],
                'Authored central witness does not match actual source ID/body')
    annotated = {}
    require([c['case'] for c in semantic['case_assessments']] == list(case_map), 'Authored case order differs')
    for assessment in semantic['case_assessments']:
        cid = assessment['case']
        case = case_map[cid]
        require(assessment['source'] == case['first_input'] and assessment['reference'] == case['references'],
                'Authored source/reference differs')
        ref = load(case['references'])
        if cid == 'CR0002':
            requirements = [(r['key'], r['question_ids'], r['required_claim']) for r in ref['requirements']]
        else:
            rid = 'row1' if cid == 'CR3217' else 'row23'
            requirements = [(q['id'] + '-claim-' + str(i + 1), [q['id']], claim)
                for q in ref['cases'][rid] for i, claim in enumerate(q['required_claims'])]
        for item in assessment['narrative_assessments']:
            job = item['job']
            require(job in rows and job.startswith(cid + '.') and job not in annotated
                    and item['unchanged_criteria'] == case['references'], 'Wrong/repeated authored answer identity')
            actual = [(r['key'], r['question_ids'], r['required_claim']) for r in item['requirements']]
            require(actual == requirements, 'Authored requirement is not byte-equivalent unchanged criterion')
            for requirement in item['requirements']:
                require(requirement['substantive_response'] == rows[job]['answer']
                        and requirement['essential_recovery'] in ('complete', 'partial', 'absent', 'uncertain')
                        and requirement['assigned_question_placement'] in ('complete', 'partial', 'absent', 'uncertain'),
                        'Authored response/status identity differs')
            q2 = [r for r in item['requirements'] if 'Q2' in r['question_ids']]
            require(item['essential_Q2_complete'] == all(r['essential_recovery'] == 'complete' for r in q2)
                    and item['assigned_Q2_complete'] == all(r['assigned_question_placement'] == 'complete' for r in q2)
                    and item['whole_response_support_certified'] is False, 'Authored label aggregation differs')
            annotated[job] = item
    expected_narratives = {j for j in rows if j.split('.', 1)[1] in
                           ('first', 'generic', 'triage_targeted', 'audit_targeted')}
    require(set(annotated) == expected_narratives, 'Missing/extra authored narrative population')
    allowances = []
    for row in semantic['word_allowances']:
        job = row['job']
        require(job in expected_narratives, 'Word count has a non-narrative job')
        counts = {r['id']: len(r['answer'].split()) for r in answers[job]['answers']}
        require(row['whitespace_word_counts'] == counts
                and row['allowances'] == {'Q1': 250, 'Q2': 400, 'Q3': 250, 'Q4': 250}
                and all(n <= row['allowances'][q] for q, n in counts.items()),
                'Actual narrative word count/allowance differs')
        allowances.append(job)
    require(len(allowances) == len(set(allowances)) and set(allowances) == expected_narratives,
            'Missing/repeated word count')
    authored_groups = {}
    for policy, _ in policies:
        finals = [w['final_answer_job'] for w in unique if w['policy'] == policy]
        authored_groups[policy] = {'complete': sum(annotated[j]['essential_Q2_complete'] for j in finals),
            'assigned_Q2_complete': sum(annotated[j]['assigned_Q2_complete'] for j in finals),
            'denominator': 3, 'final_answer_jobs': finals}
    close_numbers(semantic['policy_essential_Q2_recovery'], authored_groups, 'Authored aggregate reproduction')
    return {'state': 'MATCHED_SAVED_INPUT_ACTION_LITERAL_AND_CHARGE_REPLAY_PASS',
        'packet_members_including_manifest': len(entries) + 1, 'saved_physical_returns': 20,
        'unique_case_policy_workflows': 12, 'dependent_allocation_policy_workflows': 24,
        'dependent_logical_calls': 58, **counters, 'physical_charge': total(all_ids),
        'policy_charges': groups, 'author_semantic_annotations_reproduced': True,
        'author_annotation_counts': authored_groups,
        'semantic_correctness_certified': False, 'whole_response_support_certified': False,
        'native_extraction_or_retrieval_reexecuted': False, 'model_calls': 0, 'network_calls': 0}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify_resource(args.directory), ensure_ascii=False, indent=2), flush=True)


if __name__ == '__main__':
    main()
