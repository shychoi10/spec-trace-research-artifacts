#!/usr/bin/env python3
"""Copy the completed matched measurement into a portable saved-return packet.

No upstream corpus/native body is opened, no model is run, and no publication
occurs. Root executes this only after reading the implementations. Original
control records are opaque identities; their neutral scientific fields are
projected explicitly. All admitted measurement bytes are copied unchanged.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import tarfile

sys.dont_write_bytecode = True
import verify_matched_replay_resource as verifier

ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
AREA = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation'
WORK = AREA / 'priority23-matched-policy-reuse'
MEASURE = WORK / 'measurement'
DEFAULT_OUT = WORK / 'matched-public/candidate'
ARCHIVE = 'matched_inventory_first_resource.tar.gz'
require, digest, identity = verifier.require, verifier.digest, verifier.identity


def read(path):
    return verifier.strict_json(path.read_text(encoding='utf-8'))


def bind(path):
    return {'path': path.relative_to(ROOT).as_posix(), **digest(path)}


def resolve(binding):
    name = binding['path']
    part = Path(name)
    require(not part.is_absolute() and '..' not in part.parts, 'Outside original locator')
    path = ROOT / part
    require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT),
            'Missing/unsafe admitted original')
    require(digest(path) == identity(binding), 'Original bound bytes changed: ' + name)
    return path


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


class Packet:
    def __init__(self, directory):
        self.directory = directory
        self.entries = {}
        self.originals = {}
        self.bytes = 0

    def copy(self, member, binding, aliases=()):
        path = resolve(binding)
        require(member not in self.entries, 'Duplicate packet member')
        target = self.directory / member
        require(not Path(member).is_absolute() and '..' not in Path(member).parts,
                'Unsafe packet destination')
        target.parent.mkdir(parents=True, exist_ok=True)
        with path.open('rb') as source, target.open('xb') as destination:
            shutil.copyfileobj(source, destination, 1024 * 1024)
        actual = digest(target)
        require(actual == identity(binding), 'Copied bytes differ')
        bindings = [binding, *aliases]
        for original in bindings:
            require(identity(original) == actual and original['path'] not in self.originals,
                    'Ambiguous original alias')
            resolve(original)
            self.originals[original['path']] = member
        self.entries[member] = {'member': member, **actual, 'original_bindings': bindings}
        self.bytes += actual['bytes']
        require(len(self.entries) <= 200 and self.bytes <= 32 * 1024 * 1024,
                'Explicit bounded replay packet exceeds admission')

    def generated(self, member, value):
        require(member not in self.entries, 'Duplicate generated member')
        save(self.directory / member, value)
        self.entries[member] = {'member': member, **digest(self.directory / member),
                                'original_bindings': []}


README = '''# Matched inventory-first saved-return development resource

This packet contains three exposed change-request cases: CR3217, CR0842 and
CR0002. All four policies complete the same selected saved inventory before
answering. Target-withheld and intact allocations converge on the same acquired
input and share physical first returns. The 24 paired workflows are dependent;
there are 12 unique case/policy workflows and 20 saved physical first calls.

The comparisons are stop, one generic reanswer, answer-first diagnosis with an
actual conditional Ask, and source-only ledger/audit with an actual conditional
Ask. Ledgers precede first answers. Every actual Ask receives one reanswer with
only question IDs/source IDs; no diagnostic facts, quotes, ledger facts or author
requirements are injected. Extra-detail asks and unsuccessful recovery remain.

Run the standard-library verifier without models or network:

    python3 -B verify.py .
    python3 -B -O verify.py .

Both commands recompute byte identities, actual occurrence/body supply, paired
inventory completion, exact followup input recipes, JSON/literal evidence,
source-only ledger ordering, one-followup dispatch, raw CLI usage and all physical
and dependent logical charges. Cache is included in input; reasoning is included
in output. Request-duration sums exclude acquisition I/O, preparation, author
readback and manuscript review and are not pipeline elapsed time or total cost.

The immutable author criteria and root readback are exposed annotations, not
independent expert gold. Essential condition recovery, assigned-question placement
and whole-response support are separate. This verifier certifies saved mechanical
replay only; it does not regenerate model outputs, certify every supplemental
claim, rerender native source documents or rerun production retrieval. Native
and runtime provenance locators in raw records are opaque and must not be opened.
The original run-control and followup-admission records are hash-bound outside
the packet; method.json is their explicitly selected scientific projection.

Source text derives from attributed 3GPP change requests and observed standards.
The saved input units retain clause/version/source-role occurrence metadata.
Copyright and attribution remain with their original authors/3GPP. Reuse should
cite the source CR/specification identifiers alongside this development resource.
No DOI, independent external use, expert annotation or conference acceptance is
implied. Preparation, repository upload and anonymous download are separate
states; this producer performs local preparation only.
'''


def prepare(out):
    require(sorted(os.sched_getaffinity(0)) == [0, 1]
            and os.getpriority(os.PRIO_PROCESS, 0) == 19, 'Root resource guard required')
    out = out.resolve()
    require(out.is_relative_to(WORK.resolve()) and not out.exists() and not out.is_symlink(),
            'Fresh candidate inside the authorized measurement work area required')
    protocol_binding = bind(MEASURE / 'model_run_protocol.json')
    protocol = read(resolve(protocol_binding))
    admission_binding = bind(MEASURE / 'root_followup_admission.json')
    admission = read(resolve(admission_binding))
    accounting_binding = bind(MEASURE / 'completed_first_call_accounting.json')
    accounting = read(resolve(accounting_binding))
    semantic_binding = bind(MEASURE / 'root_completed_semantic_readback.json')
    semantic = read(resolve(semantic_binding))
    require(accounting['state'] == 'COMPLETE_FIRST_MATCHED_PHYSICAL_AND_DEPENDENT_LOGICAL_ACCOUNTING'
            and accounting['protocol'] == admission['protocol'] == protocol_binding
            and accounting['new_research_model_calls'] == 20 and semantic['owner'] == 'root'
            and semantic['accounting'] == accounting_binding and semantic['protocol'] == protocol_binding,
            'Completed root-admitted first measurement required')
    require(admission['fact_injection'] is False and admission['author_requirements_passed_to_reader'] is False,
            'Fact-free source-ID followup required')
    require(not list((MEASURE / 'predictions').glob('*/mechanical_failure.json')),
            'Preserved first failure prevents completed-resource preparation')
    expected = [j['id'] for j in protocol['primary_jobs']] + admission['admitted_job_ids']
    require(len(expected) == len(set(expected)) == 20
            and {p.name for p in (MEASURE / 'predictions').iterdir() if p.is_dir()} == set(expected),
            'Unexpected/missing/repeated physical return')
    out.mkdir(parents=True)
    packet = Packet(out)
    try:
        for name, binding in protocol['policies'].items():
            packet.copy('policies/' + name + '.txt', binding)
        cases = []
        references = []
        for case in protocol['cases']:
            cid = case['id']
            aliases = [] if case['original_source_input'] == case['first_input'] else [case['original_source_input']]
            packet.copy('inputs/' + cid + '.acquired-source.txt', case['first_input'], aliases)
            for allocation in case['initial_allocations']:
                if allocation['input']['path'] not in packet.originals:
                    packet.copy('inputs/' + cid + '.initial-target-withheld.txt', allocation['input'])
            reference = case['references']
            if reference['path'] not in packet.originals:
                packet.copy('criteria/' + ('radio' if cid != 'CR0002' else 'ambient') + '_author_reference.json', reference)
            references.append(reference)
            cases.append({k: case[k] for k in ('id', 'original_source_input', 'first_input',
                'initial_allocations', 'all_available_scoped_occurrences', 'inventory_first_is_pre_inference',
                'no_partial_first_answer_generated', 'references')})
        for row in accounting['physical_returns']:
            name = row['job']
            packet.copy('inputs/' + name + '.txt', row['input'])
            for field, filename in [('answer', 'answer.txt'), ('result', 'result.json'),
                    ('dispatch', 'dispatch.json'), ('mechanical_check', 'mechanical_check.json')]:
                packet.copy('predictions/' + name + '/' + filename, row[field])
            result = read(resolve(row['result']))
            for field, filename in [('events', 'events.jsonl'), ('stderr', 'stderr.txt')]:
                packet.copy('predictions/' + name + '/' + filename, result[field])
        packet.copy('completed_first_call_accounting.json', accounting_binding)
        packet.copy('author_semantic_readback.json', semantic_binding)
        packet.copy('verify.py', bind(Path(verifier.__file__).resolve()))
        packet.copy('producer.py', bind(Path(__file__).resolve()))
        method = {k: protocol[k] for k in ('cli_version', 'config_overrides', 'declared_model',
            'declared_reasoning_effort', 'actual_provider_model_id_verified', 'seed_sampling_verified',
            'policies', 'primary_jobs', 'automatic_retries', 'maximum_targeted_followup_per_diagnostic_path',
            'generic_request', 'targeted_request', 'targeted_source_locations_only', 'policies_compared',
            'development_exposure', 'independent_trials', 'expert_gold', 'evaluation', 'cost', 'acquisition')}
        method.update({'cases': cases, 'targeted_jobs': admission['admitted_job_ids'],
            'original_protocol_opaque': protocol_binding, 'original_followup_admission_opaque': admission_binding,
            'runtime_executable_opaque': protocol['cli_binary'], 'accounting': accounting_binding,
            'author_semantic_readback': semantic_binding, 'unchanged_references': references,
            'projection_boundary': 'Only explicitly selected scientific fields; raw run-control, goals, prior reviews and author improvement strategy are not supplied.'})
        packet.generated('method.json', method)
        with (out / 'README.md').open('x', encoding='utf-8') as stream:
            stream.write(README)
        packet.entries['README.md'] = {'member': 'README.md', **digest(out / 'README.md'), 'original_bindings': []}
        save(out / 'manifest.json', {'format': 'MATCHED_SAVED_RETURN_REPLAY', 'schema': 1,
            'entries': [packet.entries[name] for name in sorted(packet.entries)],
            'original_protocol_opaque': protocol_binding, 'original_followup_admission_opaque': admission_binding,
            'state': 'LOCAL_PREPARED_SAVED_FIRST_MEASUREMENT', 'repository_upload_completed': False,
            'anonymous_download_verified': False, 'independent_external_users': 0, 'doi': None,
            'new_model_calls_during_preparation': 0, 'new_semantic_annotations_during_preparation': 0})
        for row in packet.entries.values():
            require(digest(out / row['member']) == identity(row), 'Prepared member changed')
        for row in packet.entries.values():
            (out / row['member']).chmod(0o444)
        (out / 'manifest.json').chmod(0o444)
        receipt = {'state': 'LOCAL_MATCHED_REPLAY_PACKET_PREPARED_NOT_YET_REPLAYED_OR_PUBLISHED',
            'created_utc': datetime.now(timezone.utc).isoformat(), 'candidate': out.relative_to(ROOT).as_posix(),
            'manifest': bind(out / 'manifest.json'), 'producer': bind(Path(__file__).resolve()),
            'verifier': bind(Path(verifier.__file__).resolve()), 'packet_members_including_manifest': len(packet.entries) + 1,
            'raw_member_bytes': sum(row['bytes'] for row in packet.entries.values()) + (out / 'manifest.json').stat().st_size,
            'new_model_calls': 0, 'semantic_annotations_created': 0,
            'repository_upload_completed': False, 'anonymous_download_verified': False}
        save(out.parent / 'preparation.json', receipt)
        print(json.dumps(receipt, ensure_ascii=False), flush=True)
    except Exception as error:
        save(out.parent / 'preparation_failure.json', {'state': 'FIRST_RESOURCE_PREPARATION_FAILURE_PRESERVED',
            'error': repr(error), 'new_model_calls': 0, 'automatic_retry': False})
        raise


def guarded_replay(guard, candidate, optimized):
    result = read(guard / 'result.json')
    require(result['state'] == 'CHILD_EXITED' and result['child_dispatched'] is True
            and type(result['child_exit_code']) is int and result['child_exit_code'] == 0,
            'Actual completed root replay required')
    command = result['command']
    require(command.count('-B') == 1 and command.count('-O') == (1 if optimized else 0)
            and Path(command[-1]).resolve() == candidate.resolve()
            and Path(command[-2]).resolve() == (candidate / 'verify.py').resolve(),
            'Replay guard executed a different package/verifier/mode')
    report = read(guard / 'child.log')
    require(report['state'] == 'MATCHED_SAVED_INPUT_ACTION_LITERAL_AND_CHARGE_REPLAY_PASS'
            and report['model_calls'] == report['network_calls'] == 0
            and report['semantic_correctness_certified'] is False, 'Wrong actual replay result')
    return report, {'guard': bind(guard / 'result.json'), 'stdout': bind(guard / 'child.log')}


def package(candidate, normal_guard, optimized_guard, integrity_report, out):
    require(sorted(os.sched_getaffinity(0)) == [0, 1]
            and os.getpriority(os.PRIO_PROCESS, 0) == 19, 'Root resource guard required')
    candidate, out = candidate.resolve(), out.resolve()
    require(candidate.is_relative_to(WORK) and out.is_relative_to(WORK) and not out.exists(),
            'Fresh authorized publication package required')
    normal, normal_evidence = guarded_replay(normal_guard, candidate, False)
    optimized, optimized_evidence = guarded_replay(optimized_guard, candidate, True)
    require(normal == optimized, 'Normal/optimized saved replay differs')
    integrity = read(integrity_report)
    require(integrity['state'] == 'MATCHED_SUPPLY_FACT_FREE_AND_CHARGE_CORRUPTIONS_REJECTED'
            and integrity['original_package_unchanged'] is True
            and integrity['package_manifest'] == digest(candidate / 'manifest.json')
            and len(integrity['meaningful_integrity_tests']) == 5
            and all(r['rejected'] is True for r in integrity['meaningful_integrity_tests']),
            'Actual meaningful integrity tests required')
    manifest = read(candidate / 'manifest.json')
    expected = {r['member']: identity(r) for r in manifest['entries']}
    require(len(expected) == len(manifest['entries']), 'Repeated candidate member')
    expected['manifest.json'] = digest(candidate / 'manifest.json')
    require({p.relative_to(candidate).as_posix() for p in candidate.rglob('*') if p.is_file()}
            == set(expected), 'Unexpected/missing candidate member')
    out.mkdir(parents=True)
    copied = out / 'packet'
    copied.mkdir()
    for name, binding in sorted(expected.items()):
        source = verifier.safe_member(candidate, name)
        require(digest(source) == binding, 'Candidate member changed after replay')
        target = copied / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as inp, target.open('xb') as dest:
            shutil.copyfileobj(inp, dest, 1024 * 1024)
        require(digest(target) == binding, 'Publication packet copy differs')
    archive_path = out / ARCHIVE
    with tarfile.open(archive_path, 'w:gz', compresslevel=6) as archive:
        for name in sorted(expected):
            path = copied / name
            info = archive.gettarinfo(str(path), arcname=name)
            info.uid = info.gid = info.mtime = 0
            info.uname = info.gname = ''
            with path.open('rb') as stream:
                archive.addfile(info, stream)
    observed = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive:
            require(member.isfile() and member.name in expected and member.name not in observed,
                    'Unexpected/duplicate archive member')
            h, size = hashlib.sha256(), 0
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(block)
                    size += len(block)
            require({'bytes': size, 'sha256': h.hexdigest()} == expected[member.name],
                    'Reopened archive member differs')
            observed.add(member.name)
    require(observed == set(expected), 'Missing archive member')
    save(out / 'normal_replay.json', normal)
    save(out / 'optimized_replay.json', optimized)
    shutil.copyfile(integrity_report, out / 'integrity_tests.json')
    with (out / 'README.md').open('x', encoding='utf-8') as stream:
        stream.write(README)
    save(out / 'resource.json', {
        'state': 'LOCALLY_PREPARED_NORMAL_OPTIMIZED_REPLAY_AND_INTEGRITY_TESTED',
        'created_utc': datetime.now(timezone.utc).isoformat(), 'producer': bind(Path(__file__).resolve()),
        'archive': bind(archive_path), 'manifest': bind(copied / 'manifest.json'),
        'normal_replay': bind(out / 'normal_replay.json'), 'optimized_replay': bind(out / 'optimized_replay.json'),
        'integrity_tests': bind(out / 'integrity_tests.json'), 'source_integrity_report': bind(integrity_report),
        'actual_guarded_replays': {'normal': normal_evidence, 'optimized': optimized_evidence},
        'archive_members': len(expected), 'all_archive_members_reopened_and_hashed': True,
        'unique_saved_physical_returns': normal['saved_physical_returns'],
        'new_research_model_calls_during_resource_preparation': 0, 'semantic_labels_rejudged': False,
        'independent_expert_gold': False, 'protected_body_reads': 0,
        'public_upload_complete': False, 'anonymous_download_verified': False,
        'independent_external_users': 0, 'DOI': None})
    names = ('README.md', 'resource.json', ARCHIVE, 'normal_replay.json', 'optimized_replay.json', 'integrity_tests.json')
    with (out / 'checksums.sha256').open('x', encoding='utf-8') as stream:
        stream.write(''.join(digest(out / name)['sha256'] + '  ' + name + '\n' for name in names))
    print(json.dumps({'state': 'LOCALLY_PREPARED_NORMAL_OPTIMIZED_REPLAY_AND_INTEGRITY_TESTED',
                      'archive_members': len(expected), 'archive': bind(archive_path),
                      'public_upload_complete': False}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['prepare', 'package'])
    parser.add_argument('--output', type=Path, default=DEFAULT_OUT)
    parser.add_argument('--candidate', type=Path, default=DEFAULT_OUT)
    parser.add_argument('--normal-guard', type=Path)
    parser.add_argument('--optimized-guard', type=Path)
    parser.add_argument('--integrity-report', type=Path)
    args = parser.parse_args()
    if args.action == 'prepare':
        prepare(args.output)
    else:
        require(all((args.normal_guard, args.optimized_guard, args.integrity_report)),
                'Actual replay guards and integrity report required')
        package(args.candidate, args.normal_guard, args.optimized_guard, args.integrity_report, args.output)
