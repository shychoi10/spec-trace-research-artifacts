#!/usr/bin/env python3
"""Replay the standalone RAN3 development ablation without model calls."""
import csv
import importlib.util
import io
import json
from pathlib import Path, PurePosixPath
import re
import sys


def require(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    text = path.read_text().strip()
    if text.startswith('```'):
        text = '\n'.join(text.splitlines()[1:-1])
    return json.loads(text)


def verify(folder):
    spec = importlib.util.spec_from_file_location('native', folder / 'native_replay.py')
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)
    manifest = load(folder / 'manifest.json')
    require(manifest['kind'] == 'ran3_matched_scope_development_ablation_replay', 'Wrong resource')
    actual = {str(p.relative_to(folder)) for p in folder.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    require(actual == set(manifest['files']) | {'manifest.json'}, 'Unexpected file membership')
    for name, binding in manifest['files'].items():
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts and not (folder / name).is_symlink(), 'Unsafe path')
        require(native.digest((folder / name).read_bytes()) == binding, 'Changed file: ' + name)

    def read(bound):
        raw = (folder / manifest['source_path_objects'][bound['path']]).read_bytes()
        observed = native.digest(raw)
        require(observed['sha256'] == bound['sha256'] and ('bytes' not in bound or observed['bytes'] == bound['bytes']), 'Changed source binding')
        return raw

    path = folder / 'ran3_scope_comparison'
    source, selection = load(path / 'source_units.json'), load(path / 'selection.json')
    packet = (path / 'source_packet.txt').read_text()
    compact = json.loads(packet.split('\n', 2)[2])
    require(compact['metadata'] == source['metadata'], 'Metadata payload differs')
    require([d['id'] for d in compact['documents']] == [d['id'] for d in source['documents']], 'Document order differs')
    for unit, serialized in zip(source['documents'], compact['documents']):
        observed = native.projection(read(unit['reading_input']))
        require(observed == unit['content']['paragraphs'], 'Reading XML projection differs')
        recovered = [(p[0], p[1], p[2] if len(p) == 3 else p[1]) for p in serialized['paragraphs']]
        require(recovered == [(p['paragraph_index'], p['before'], p['after']) for p in observed], 'Text views differ')
        for projection in unit['projections']:
            require(json.loads(read(projection)) == unit['content'], 'Stored projection differs')
        for occurrence in unit['occurrences']:
            if 'native' in occurrence:
                read(occurrence['native'])
    sheets, attachment_cells, availability = {}, 0, 0
    for row in source['metadata']:
        role = row['role']
        if role == 'collected_CR_metadata':
            raw = read({'path': row['source_path'], 'sha256': row['source_sha256']})
            rows = list(csv.DictReader(io.StringIO(raw.decode())))
            require(rows[row['csv_record_number'] - 2] == row['recorded_fields'], 'Collected CSV row differs')
        elif role == 'official_meeting_processing_snapshot':
            key = (row['source']['sha256'], row['sheet'])
            if key not in sheets:
                sheets[key] = native.worksheet(read(row['source']), row['sheet'])
            table = sheets[key]
            headers = [table[1][i][0] for i in range(len(row['fields']))]
            observed = {h: table[row['row_1based']].get(i, (None, 'n'))[0] for i, h in enumerate(headers)}
            require(observed == row['fields'], 'Processing row differs')
        elif role == 'spreadsheet_attachment_literal_cells':
            raw, fields, types = read(row['source']), {}, {}
            for sheet in row['sheets']:
                for number, cells in native.worksheet(raw, sheet['name']).items():
                    for index, (value, typ) in cells.items():
                        label, n = '', index + 1
                        while n:
                            n, r = divmod(n - 1, 26)
                            label = chr(65 + r) + label
                        key = sheet['name'] + '!' + label + str(number)
                        fields[key], types[key] = value, typ
            require(fields == row['fields'] and types == row['cell_types'], 'Attachment cells or types differ')
            require(json.loads(read(row['projection']))['fields'] == fields, 'Attachment projection differs')
            attachment_cells += len(fields)
        elif role == 'research_preparation_source_availability':
            require(row['fields'] in json.loads(read(row['source']))['source_limitations'], 'Availability differs')
            availability += 1
        else:
            raise ValueError('Unknown metadata role')
    prefix = 'QUESTION\n' + selection['question'] + '\nROWS\n' + json.dumps(selection['row_ids']) + '\nIDENTITIES\n' + json.dumps(selection['identities']) + '\n'
    result = []
    documents = {d['id']: {str(p['paragraph_index']): p for p in d['content']['paragraphs']} for d in source['documents']}
    metadata = {r['id']: r.get('fields', r.get('recorded_fields', {})) for r in source['metadata']}
    full_metadata = {r['id']: r for r in source['metadata']}

    def metadata_coordinate_exists(tid, field):
        # Retain the original flat-field diagnostic and separately accept literal
        # top-level keys or exact dotted dictionary paths. Neither proves meaning.
        if field in metadata.get(tid, {}) or field in full_metadata.get(tid, {}):
            return True
        value = full_metadata.get(tid, {})
        for part in field.split('.'):
            if not isinstance(value, dict) or part not in value:
                return False
            value = value[part]
        return True

    for role in selection['role_order']:
        text = (path / (role + '.answer.txt')).read_text()
        answer = load(path / (role + '.answer.txt'))
        if role in selection['conditions']:
            expected = prefix + 'CONDITION INSTRUCTION\n' + selection['conditions'][role] + '\n\n' + packet
            require((path / (role + '.input.txt')).read_text() == expected, 'Prediction input differs')
            require([r['row_id'] for r in answer['crs']] == selection['row_ids'] and [r['cr'] for r in answer['crs']] == selection['identities'], 'Prediction identities differ')
        else:
            require([u['unit_id'] for u in answer['units']] == selection['unit_ids'], 'Reference/judge identities differ')
        pins = set(re.findall(r'\[(S\d+):p(\d+):(before|after)\]', text))
        fields = set(re.findall(r'\[(T\d+):([^\]]+)\]', text))
        invalid = [[sid, index, view] for sid, index, view in sorted(pins) if index not in documents.get(sid, {})]
        invalid += [[tid, field] for tid, field in sorted(fields) if field not in metadata.get(tid, {})]
        unresolved = [item for item in invalid if len(item) == 3 or not metadata_coordinate_exists(*item)]
        result.append({'role': role, 'paragraph_citations': len(pins), 'metadata_citations': len(fields),
                       'invalid_coordinates': invalid, 'flat_field_diagnostic_preserved': True,
                       'unresolved_after_literal_dictionary_path_lookup': unresolved})
    reference = load(path / 'REFERENCE.answer.txt')
    expected_reference = prefix + 'UNIT_IDS\n' + json.dumps(selection['unit_ids']) + '\nREFERENCE INSTRUCTION\n' + selection['reference_instruction'] + '\n\n' + packet
    require((path / 'REFERENCE.input.txt').read_text() == expected_reference, 'Reference input differs')
    anonymous = {label: load(path / (role + '.answer.txt')) for label, role in selection['anonymous_mapping'].items()}
    expected_judge = prefix + 'UNIT_IDS\n' + json.dumps(selection['unit_ids']) + '\nJUDGE INSTRUCTION\n' + selection['judge_instruction'] + '\nFIXED PROVISIONAL REFERENCE\n' + json.dumps(reference, ensure_ascii=False) + '\nANONYMOUS CANDIDATE ANSWERS\n' + json.dumps(anonymous, ensure_ascii=False) + '\n\n' + packet
    require((path / 'JUDGE.input.txt').read_text() == expected_judge, 'Anonymous judge input differs')
    freeze = load(path / 'reference_frozen.json')
    require(native.digest((path / 'REFERENCE.answer.txt').read_bytes()) == {k: freeze['answer'][k] for k in ('sha256', 'bytes')}, 'Frozen reference differs')
    calls = load(path / 'observed_calls.json')
    require([c['role'] for c in calls] == selection['role_order'], 'Call order differs')
    require(calls[0]['finished_utc'] <= freeze['frozen_utc'] < calls[1]['started_utc'], 'Reference not frozen before predictions')
    for previous, current in zip(calls, calls[1:]):
        require(previous['finished_utc'] < current['started_utc'], 'Calls did not run sequentially')
    return {'state': 'PASS_STANDALONE_RAN3_NATIVE_TEXT_AND_MATCHED_INPUT_REPLAY',
            'reading_inputs': len(source['documents']), 'paragraphs': sum(len(d['content']['paragraphs']) for d in source['documents']),
            'metadata_rows': len(source['metadata']), 'attachment_cells': attachment_cells, 'availability_rows': availability,
            'roles': result, 'human_labels': 0, 'model_calls': 0,
            'scope': 'Bounded reading XML, literal cells, hashes, fixed inputs and citation coordinates; not rendering, DOC conversion fidelity, semantic accuracy or third-party replication.'}


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1]).resolve()), ensure_ascii=False))
