#!/usr/bin/env python3
"""Verify a standalone development-input bundle, without network or inference.

Raw XML replay follows the bounded content-token projection recorded by
project_standards_content.py. It does not implement full Word rendering or
establish the semantic correctness of the assistant's development references.
"""
import argparse
import csv
from datetime import datetime, timedelta
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import xml.etree.ElementTree as ET
import zipfile

W = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
M = '{http://schemas.openxmlformats.org/officeDocument/2006/math}'
A = '{http://schemas.openxmlformats.org/drawingml/2006/main}'
X = '{http://schemas.openxmlformats.org/spreadsheetml/2006/main}'
R = '{http://schemas.openxmlformats.org/officeDocument/2006/relationships}'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def projection(raw):
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        root = ET.fromstring(package.read('word/document.xml'))

    def tokens(node, view, ancestors=()):
        tag = node.tag
        namespace, _, local = tag.rpartition('}')
        if namespace + '}' in {W, M, A} and (local.endswith('Pr') or local.endswith('PrChange')):
            return ''
        if (view == 'before' and tag in {W + 'ins', W + 'moveTo'}) or (view == 'after' and tag in {W + 'del', W + 'moveFrom'}):
            return ''
        if tag in {W + 't', W + 'delText', M + 't', A + 't'}:
            return node.text or ''
        if tag == W + 'tab':
            return '\t'
        if tag in {W + 'br', W + 'cr'}:
            return '\n'
        require(local not in {'t', 'delText', 'tab', 'br', 'cr'}, 'Unresolved token namespace')
        return ''.join(tokens(child, view, (*ancestors, tag)) for child in node)

    paragraphs = []
    for index, paragraph in enumerate(root.iter(W + 'p')):
        style = paragraph.find(W + 'pPr/' + W + 'pStyle')
        paragraphs.append({'paragraph_index': index, 'style': style.get(W + 'val') if style is not None else None,
            'insertions': len(list(paragraph.iter(W + 'ins'))), 'deletions': len(list(paragraph.iter(W + 'del'))),
            'before': tokens(paragraph, 'before'), 'after': tokens(paragraph, 'after')})
    return paragraphs


def unpack(raw, chain):
    for member in chain:
        with zipfile.ZipFile(io.BytesIO(raw)) as package:
            raw = package.read(member)
    return raw


def column_number(label):
    number = 0
    for character in re.match(r'^[A-Z]+', label).group():
        number = number * 26 + ord(character) - ord('A') + 1
    return number - 1


def worksheet(raw, name):
    with zipfile.ZipFile(io.BytesIO(raw)) as package:
        workbook = ET.fromstring(package.read('xl/workbook.xml'))
        relation = next(s.get(R + 'id') for s in workbook.find(X + 'sheets') if s.get('name') == name)
        relations = ET.fromstring(package.read('xl/_rels/workbook.xml.rels'))
        target = next(r.get('Target') for r in relations if r.get('Id') == relation)
        target = target.lstrip('/') if target.startswith('/') else 'xl/' + target
        require('..' not in PurePosixPath(target).parts, 'Unexpected worksheet relationship')
        strings = []
        if 'xl/sharedStrings.xml' in package.namelist():
            strings = [''.join(t.text or '' for t in node.iter(X + 't')) for node in ET.fromstring(package.read('xl/sharedStrings.xml'))]
        styles = ET.fromstring(package.read('xl/styles.xml'))
        formats = {int(node.get('numFmtId')): node.get('formatCode') for node in styles.find(X + 'numFmts') or []}
        style_ids = [int(node.get('numFmtId', 0)) for node in styles.find(X + 'cellXfs')]
        properties = workbook.find(X + 'workbookPr')
        epoch = datetime(1904, 1, 1) if properties is not None and properties.get('date1904') in {'1', 'true'} else datetime(1899, 12, 30)
        result = {}
        for row in ET.fromstring(package.read(target)).find(X + 'sheetData'):
            cells = {}
            for cell in row:
                typ, node = cell.get('t', 'n'), cell.find(X + 'v')
                text = node.text if node is not None else None
                datatype = typ
                if typ == 's':
                    value = strings[int(text)]
                elif typ == 'inlineStr':
                    value = ''.join(t.text or '' for t in cell.iter(X + 't')); datatype = 's'
                elif typ == 'd':
                    value = str(datetime.fromisoformat(text.replace('Z', '+00:00')))
                elif typ == 'n' and text is not None:
                    value = float(text) if any(c in text for c in '.eE') else int(text)
                    fmt = style_ids[int(cell.get('s', '0'))]
                    code = re.sub(r'"[^"]*"|\[[^]]*\]', '', formats.get(fmt, ''))
                    if fmt in set(range(14, 23)) | {45, 46, 47} or re.search(r'[dmyhs]', code, re.I):
                        day = int(value); milliseconds = round((value - day) * 86400000)
                        value = str(epoch + timedelta(days=day, milliseconds=milliseconds)); datatype = 'd'
                elif typ == 'b':
                    value = text == '1'
                else:
                    value = text
                cells[column_number(cell.get('r'))] = (value, datatype)
            result[int(row.get('r'))] = cells
        return result

