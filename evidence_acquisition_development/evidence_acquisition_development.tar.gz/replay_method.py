# Exact function/class exports from the preserved acquisition producers.
import json, math, re
from collections import Counter, defaultdict
from pathlib import Path
import hashlib
TOKEN = re.compile(r"[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*")
class PackageReader:
    def __init__(self,root):self.root=root
    def read(self,path):return json.loads(path.read_text())
    def verify(self,binding):
        path=self.root/'endpoints'/Path(binding['path']).name
        raw=path.read_bytes()
        if len(raw)!=binding['bytes'] or hashlib.sha256(raw).hexdigest()!=binding['sha256']:
            raise ValueError('Endpoint context packet differs')
        return path


def tokens(text):
    """Frozen ASCII lexical control; retain dotted identifiers, no learned vocab."""
    if not isinstance(text, str):
        raise TypeError('text must be a string')
    return TOKEN.findall(text.lower())


class BM25:
    """Positive-IDF BM25, k1=1.2, b=.75; corpus is one full exact-base index.

    IDF = log(1 + (N - df + .5)/(df + .5)). Query terms contribute once each.
    Statistics use all candidates, never reference labels or query documents.
    """
    def __init__(self, documents, k1=1.2, b=.75):
        if not documents or not math.isfinite(k1) or k1 <= 0 or not 0 <= b <= 1:
            raise ValueError('nonempty documents and valid BM25 parameters required')
        self.n, self.k1, self.b = len(documents), k1, b
        self.postings = defaultdict(list)
        self.lengths = []
        for i, document in enumerate(documents):
            counts = Counter(tokens(document))
            self.lengths.append(sum(counts.values()))
            for term, count in counts.items():
                self.postings[term].append((i, count))
        self.avglen = sum(self.lengths)/self.n

    def score(self, query):
        query_terms = sorted(set(tokens(query)))
        result = [0.0] * self.n
        if self.avglen == 0:
            return result
        for term in query_terms:
            postings = self.postings.get(term, ())
            df = len(postings)
            if not df:
                continue
            idf = math.log1p((self.n - df + .5)/(df + .5))
            for i, tf in postings:
                norm = self.k1 * (1 - self.b + self.b*self.lengths[i]/self.avglen)
                result[i] += idf * tf * (self.k1 + 1)/(tf + norm)
        return result


def metadata(unit):
    result = {k: unit[k] for k in ('id','document_id','role','specification','version','clause','heading','paragraphs','kind','changed')}
    if unit.get('explicit_native_run_formats'):
        result['explicit_native_run_formats']=unit['explicit_native_run_formats']
    return result


def unique_units(units):
    unique=[]; lookup={}; aliases={}
    for unit in units:
        index=lookup.get(unit['text'])
        if index is None:
            index=len(unique); lookup[unit['text']]=index
            unique.append({'id':unit['id'],'text':unit['text'],'occurrences':[]})
        unique[index]['occurrences'].append(metadata(unit)); aliases[unit['id']]=index
    return unique,aliases


def context_bundles(original, aliases, inventory):
    contexts={i:{i} for i in set(aliases.values())}
    documents={}
    for u in original: documents.setdefault(u['document_id'],[]).append(u)
    for rows in documents.values():
        for position,u in enumerate(rows):
            index=aliases[u['id']]
            for v in rows[max(0,position-1):position+2]:
                if v['clause']==u['clause']: contexts[index].add(aliases[v['id']])
            if u['kind']=='table_row':
                contexts[index].update(aliases[v['id']] for v in rows if v['kind']=='table_row' and
                                      v['table']==u['table'] and (v['header_declared'] or v['row']<2))
    blocks=list(inventory['CR_configuration_blocks'])
    for endpoint in inventory['endpoint_excerpt_matches']:
        for member in endpoint['matched_members']:
            packet=executor.read(executor.verify(member['packet']))
            blocks.extend(packet['selected_configuration_blocks'])
    for block in blocks:
        indexes={aliases[r] for r in block['rows'] if r in aliases}
        for i in indexes: contexts[i].update(indexes)
    return contexts


def ranked_bundles(unique, contexts, questions):
    encoded=[u['text']+'\n'+json.dumps(u['occurrences'],ensure_ascii=False,sort_keys=True) for u in unique]
    index=BM25(encoded); queues=[]; scores=[]
    for question in questions:
        score=index.score(question['question']); scores.append(score)
        roles=('CR',) if question['id']=='Q1' else ('CR','base','target')
        for role in roles:
            eligible=[i for i,u in enumerate(unique) if any(o['role']==role for o in u['occurrences'])]
            queues.append(sorted(eligible,key=lambda i:(-score[i],unique[i]['id'])))
    ordered=[]
    for depth in range(max(map(len,queues))):
        for queue in queues:
            if depth<len(queue): ordered.append(sorted(contexts[queue[depth]]))
    return ordered,scores,index


def pack(bundles, unique, budget):
    chosen=set(); skipped=[]; used=0
    for bundle in bundles:
        new=set(bundle)-chosen; cost=sum(len(unique[i]['text']) for i in new)
        if used+cost<=budget: chosen.update(new); used+=cost
        elif new: skipped.append({'unit_ids':[unique[i]['id'] for i in sorted(new)],'source_characters':cost})
    return sorted(chosen),used,skipped


def closure_bundles(original, unique, aliases, contexts, index, baseline):
    cover=[u for u in original if u['role']=='CR' and u['clause'] is None]
    technical=[u for u in cover if any(s in u['text'] for s in
               ('Reason for change:','Summary of change:','Clauses affected:','Title:','Current version:','Release:'))]
    result=[[aliases[u['id']] for u in technical]]
    changes=[u for u in original if u['role']=='CR' and u['changed']]
    for changed in changes:
        indexes=set(contexts[aliases[changed['id']]])
        for role,view in (('base','before'),('target','after')):
            candidates=[u for u in original if u['role']==role and u['clause']==changed['clause'] and u['kind']==changed['kind']]
            if not candidates: continue
            text=changed[view]
            exact=[u for u in candidates if text and u['text']==text]
            scores=index.score(text or changed['text'])
            selected=exact[0] if exact else sorted(candidates,key=lambda u:(-scores[aliases[u['id']]],u['id']))[0]
            indexes.update(contexts[aliases[selected['id']]])
        result.append(sorted(indexes))
    # Complete retained prose beside edited clauses before lexical backfill.
    edited_clauses={u['clause'] for u in changes if u['clause']}
    for clause in sorted(edited_clauses):
        ids={aliases[u['id']] for u in original if u['clause']==clause and u['kind']=='paragraph'}
        if ids: result.append(sorted(ids))
    return result+baseline
