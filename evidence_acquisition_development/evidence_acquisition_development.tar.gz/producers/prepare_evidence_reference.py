#!/usr/bin/env python3
"""Save the root author's exposed source-readback reference before predictions.

The text below is authored after bounded source reading. It is neither expert
gold nor an independent label set. Evidence quotes are exact saved unit texts.
"""
from pathlib import Path
import run_codex_relation_comparison as executor
from priority5_evidence_acquisition import OUT

AUTHOR = {
 'row1': {
  'Q1': ('positive_technical_recovery', [
   'The submitted request says PC1.5 for UL CA_n25A-n41A was added in draft R4-2521599 but the MOP table update was missing; the draft itself is not supplied.',
   'It requests 29 dBm for CA_n25A-n41A in Table 6.2A.1.3-1, rather than measured device improvement.'
  ], ['CR:t2r11','CR:t2r13']),
  'Q2': ('positive_technical_recovery', [
   'For CA_n25A-n41A, the projected proposal and observed 19.4.0→19.5.0 row add PC1.5 29 dBm with +2/-3 dB tolerance from blank cells; PC2 26 dBm and PC3 23 dBm with +2/-3 are retained. Blank cells do not prove historical deletion.',
   'The retained scope includes two-band total output across component carriers/antenna connectors, measurement period at least 1 ms, reported per-band power-class capability or fallback, and higherPowerLimit-r17/mixed-class adjustment. Do not broaden this single configuration to every UE or CA combination.',
   'Neighboring capability/duty-cycle conditions remain conditions, not new changes or actual deployed UE observations.'
  ], ['CR:t3r0','CR:t3r135','base:2:t101r135','target:3:t101r135','CR:p115','CR:p116','CR:p2378','CR:p2389','CR:p2390']),
 },
 'row23': {
  'Q1': ('positive_technical_recovery', [
   'The request identifies LP-WUS editorial/citation errors and says ACS and ASCS measure receiver ability rather than UE ability, seeking alignment with TS38.101-1; that external specification is not supplied here.',
   'Its requested corrections include LP-WUS titles, an unnecessary note, the 7.5M.3 citation, both receiver definitions and other editorial errors, not a demonstrated receiver-performance gain.'
  ], ['CR:t2r11','CR:t2r13']),
  'Q2': ('positive_technical_recovery', [
   'The projected changes and supplied endpoints support both ACS and ASCS UE’s→receiver’s definition changes while retaining configured RB/adjacent-signal scope; ASCS remains conditional on fully populated non-LPWUS DL RBs.',
   'The ASCS parameter citation changes from Tables 7.11M-1 to Table 7.5M.3-1. MDR 7.1M and its side conditions, all 5.3M channel bandwidths, RIB and wanted AoA along Rx beam peak remain; ACS also retains both wanted/interfering peak directions, same polarization/all polarizations and any specified SCS.',
   'Table 7.5M.2-3 removes the rounded 10log10(x) note, renumbers its following definition note 4→3 and corresponding superscript, and Table 7.5M.2-2 adds superscript 2 to REFSENS_LP-WUS. Explicit native alignment supports markers, not a new parameter named ACS3/ACS4 or a new numeric sensitivity.',
   'Titles gain LP-WUS/WUR or test-parameter wording, a table heading changes Channel BW→Value, and the A.3M.1 General heading is removed while the reference-channel content remains. This is not deletion of the entire Annex or changed empirical test values.',
   'The retained guard-RB definitions distinguish ASCS between NR RB and LP-WUS RB from ACS between NR guardband and LP-WUS RB.'
  ], ['CR:p182','CR:p242','CR:p243','CR:p183','CR:p184','CR:p114','CR:t8r1','CR:t9r2','CR:t9r5','CR:p111','CR:p159','CR:p167','CR:t6r0','CR:p259','CR:p264','CR:p265',
      'base:0:p14019','target:0:p14019','base:0:p14079','target:0:p14078','base:0:p14080','target:0:p14079']),
 },
 'row25': {
  'Q1': ('positive_technical_recovery', [
   'The request corrects Table 7.3B.2.3.5.2-1 MSD configuration parameters using duplex-spacing and interference-product rationale, rather than reporting measured MSD improvements.',
   'For DC_7A-28A_n5A/DC_7C-28A_n5A it requests 2725→2660, 854→874 and 874→885 MHz; for DC_7A-20A_n3A 896→814 MHz; for the listed DC_2A-13A and DC_2A-2A-13A n77A/C family, band-13 BW 10→5 MHz and 50→25 RB; for DC_3A-28A_n5A/DC_3C-28A_n5A, 874→890 MHz in two cases.',
   'Treat Rel-17 alignment as the cover’s rationale without certifying the absent Rel-17 source. The cover Release is Rel-19 even though the title/work-item contain Rel-18.'
  ], ['CR:t2r11','CR:t2r13','CR:t2r1','CR:t2r8','CR:t2r24']),
  'Q2': ('positive_technical_recovery', [
   'Preserve all four listed configuration groups and all numerical directions in Q1. The seven changed table units have corresponding old/new values in observed 19.4.0→19.5.0 selected rows; the two 874→890 edits belong to different victim cases, not two independent configurations.',
   'Keep UL-Fc/DL-Fc, bandwidth and allocated-RB columns distinct: band7 UL2540/DL2725→2660; n5 UL829/DL854→874 and UL840/DL874→885; band20 UL855/DL896→814; band13 UL783/BW10→5/RB50→25; n5 UL845/DL874→890 twice. Preserve victim/context rather than guessing from blank configuration cells.',
   'The separate Table ...-1a for power class 2 already has band13 783 MHz, 5 MHz and 25 RB in the base and target. Do not claim every band13/PC2 configuration changed. The ordinary projected row has one literal n77C label; cover-group membership and adjacent labels are context, not certified full merged-layout attribution.',
   'Retained MSD values are requirements, not measured gains. Cover Rel-19 vs Rel-18 title, absent referenced Cat-F CR R4-2602237 and Rel-17, and structural/rendering limitations stay explicit where used. Superscript 1 after IMD2 is a marker, not interference order 21.'
  ], ['CR:t2r13','CR:t4r637','CR:t4r1058','CR:t4r1061','CR:t4r1677','CR:t4r1751','CR:t4r1753','CR:t4r1756','CR:t4r1676','CR:t5r146','CR:t5r147','CR:t5r148',
      'base:2:t57r637','target:2:t57r637','base:2:t58r147','target:2:t58r147']),
 },
}


def main():
    executor.guarded(); cases={}; read_records=[]
    for cid,rows in AUTHOR.items():
        pool=OUT/'sources/scoped'/(cid+'.pool.json'); packet=executor.read(pool)
        units={u['id']:u for u in packet['units']}; answers=[]
        for qid,(kind,claims,ids) in rows.items():
            evidence=[]
            for suffix in ids:
                uid=cid+':'+suffix
                if uid not in units: raise ValueError('Author witness ID absent: '+uid)
                evidence.append({'source_id':uid,'quote':units[uid]['text']})
            answers.append({'id':qid,'assessment_kind':kind,'required_claims':claims,'evidence':evidence})
        examples={ 'row1':'target:3:t101r135','row23':'target:0:p14078','row25':'target:2:t57r637'}
        witness=cid+':'+examples[cid]
        answers.append({'id':'Q3','assessment_kind':'approval_and_causation_boundary',
           'required_claims':['The inventory has a submitted CR, a byte-identical TSG-package copy and observed version excerpts. A concrete matching observed edit may be described as text consistency, not certified official processing.',
                              'The copy or match alone does not establish approval, exact incorporation of this CR as a whole, sole causation, or first historical introduction. Official processing/outcome and complete attribution evidence are absent from this bounded inventory.'],
           'evidence':[{'source_id':witness,'quote':units[witness]['text']}],
           'inventory_evidence':packet['inventory']['absent_evidence_types']})
        answers.append({'id':'Q4','assessment_kind':'measurement_and_deployment_boundary',
           'required_claims':['Give a concrete available technical rule/correction while separating normative test requirements or CR rationale from actual measured improvements.',
                              'No device/network measurement or deployed-UE capability/configuration evidence is supplied. Actual performance improvement and a particular deployed UE’s behavior are not established; avoid promoting this absence into a universal impossibility.'],
           'evidence':[{'source_id':witness,'quote':units[witness]['text']}],
           'inventory_evidence':packet['inventory']['absent_evidence_types']})
        cases[cid]=answers; read_records.append({'case':cid,'pool':executor.bind(pool),'directly_read_current_units':len(units)})
    executor.save(OUT/'author_reference.json',{'state':'EXPOSED_AUTHOR_REFERENCE_FROZEN_BEFORE_FIRST_PREDICTIONS',
          'created_utc':executor.now(),'producer':executor.bind(Path(__file__)),'cases':cases,
          'assessment_rule':'Root reads all first Q1–Q4 answers and evidence. For the six positive Q1/Q2 cells per mode report complete supported technical recovery separately from partial/missing recovery and false promotions. A positive cell is complete when the essential requested edits/conditions in its required claims are preserved with no material unsupported promotion; equivalent wording accepted. Q3 and Q4 boundary preservation (three each per mode), unnecessary abstention, input quote fidelity and acquisition coverage are separate. No overall accuracy combining unknowns with positive recovery, no independent gold, statistical generalization or latent reasoning score. Root must record concrete omissions/errors and available-vs-withheld supporting input per answer.',
          'reference_exposure':'Root authored this after direct selected-source readback; authentic CR requests, author-derived question templates, shared-package/reference dependency, development sources. No prediction output seen or labels supplied to acquisition/model.',
          'independent_human_adjudicators':0,'expert_gold':False,'heldout_accuracy':False})
    executor.save(OUT/'root_source_readback.json',{'state':'ALL_CURRENT_SELECTED_POOL_TEXT_DIRECTLY_READ_BEFORE_FIRST_PREDICTIONS',
          'created_utc':executor.now(),'cases':read_records,'all_current_supplied_selected_units_directly_read':True,
          'root_read_basis':['row1 original 124 units fully printed untruncated; final scoped (id,text) membership identical.',
                            'row23 original 172 units fully printed untruncated, then all 22 additional final scoped units printed and read; 194 total.',
                            'row25 final scoped 144 units printed and read in chunks 0:50,50:100,100:144, all untruncated.',
                            'Native sidecar CR formatted units inspected, including inserted superscript 2, deleted 4/inserted3 and IMD2 superscript1. Full inherited styles/rendering not certified.'],
          'native_formats':executor.bind(OUT/'native_run_formats.json'),'model_calls':0,
          'unselected_native_bodies_semantically_read_in_full':False,'protected_email_bodies_opened':0})
    print('AUTHOR_REFERENCE_AND_ROOT_READBACK_SAVED_BEFORE_PREDICTIONS',flush=True)


if __name__=='__main__': main()
