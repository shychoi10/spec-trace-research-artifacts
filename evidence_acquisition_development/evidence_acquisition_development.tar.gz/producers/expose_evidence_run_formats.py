#!/usr/bin/env python3
"""Expose explicit native run vertical alignment in the selected source units.

This bounded mechanical sidecar does not resolve inherited styles or certify
Word rendering. It prevents plain-text concatenations from concealing explicit
superscript/subscript tokens. Every acquisition mode uses the same sidecar.
"""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import zipfile

import run_codex_relation_comparison as executor
from priority5_evidence_acquisition import OUT
from project_standards_content import W


def selected_formats(native, selected):
    result={}; stack=[]; pids={}; count=0; paragraph_depth=0; row_depth=0
    def runs(element, ancestors=()):
        if element.tag==W+'r':
            prop=element.find(W+'rPr')
            align=prop.find(W+'vertAlign') if prop is not None else None
            if align is not None:
                token=''.join(e.text or '' for e in element.iter() if e.tag in (W+'t',W+'delText'))
                if token:
                    yield {'token_text':token,'vertical_alignment':align.get(W+'val'),
                           'inline_containers':[a for a in ancestors if a in ('ins','del','moveTo','moveFrom')]}
            return
        for child in element:
            yield from runs(child,ancestors+(element.tag.rsplit('}',1)[-1],))
    with zipfile.ZipFile(native) as archive, archive.open('word/document.xml') as source:
        for event,element in ET.iterparse(source,events=('start','end')):
            if event=='start':
                stack.append(element)
                if element.tag==W+'p': pids[id(element)]=count; count+=1; paragraph_depth+=1
                if element.tag==W+'tr': row_depth+=1
                continue
            if element.tag==W+'p':
                index=pids[id(element)]
                if index in selected:
                    formats=list(runs(element))
                    if formats: result[index]=formats
                if paragraph_depth==1 and row_depth==0:
                    for p in element.iter(W+'p'): pids.pop(id(p),None)
                    parent=stack[-2] if len(stack)>1 else None
                    element.clear()
                    if parent is not None: parent.remove(element)
                paragraph_depth-=1
            elif element.tag==W+'tr':
                if row_depth==1:
                    for p in element.iter(W+'p'): pids.pop(id(p),None)
                    parent=stack[-2]; element.clear(); parent.remove(element)
                row_depth-=1
            elif element.tag==W+'tbl' and row_depth==0:
                parent=stack[-2]; element.clear(); parent.remove(element)
            stack.pop()
    return result,count


def main():
    executor.guarded(); selection=executor.read(OUT/'selection.json')
    cases={}
    for case in selection['selected']:
        cid='row'+str(case['row_id']); pool=OUT/'sources/scoped'/(cid+'.pool.json')
        packet=executor.read(pool); documents={}; natives={cid+':CR':OUT/'native'/(cid+'.CR.docx')}
        for endpoint in packet['inventory']['endpoint_excerpt_matches']:
            for member in endpoint['matched_members']:
                saved=executor.read(executor.verify(member['packet']))
                docid=saved['selected_units'][0]['document_id']
                natives[docid]=executor.verify(member['native'])
        for unit in packet['units']: documents.setdefault(unit['document_id'],[]).append(unit)
        by_unit={}; source_records=[]
        for docid,units in documents.items():
            wanted={i for unit in units for i in unit['paragraphs']}
            formats,total=selected_formats(natives[docid],wanted)
            for unit in units:
                records=[{'paragraph_index':i,**entry} for i in unit['paragraphs'] for entry in formats.get(i,[])]
                if records: by_unit[unit['id']]=records
            source_records.append({'document_id':docid,'native':executor.bind(natives[docid]),
                                   'native_paragraphs':total,'selected_paragraphs':len(wanted),
                                   'selected_paragraphs_with_explicit_formats':len(formats)})
        cases[cid]={'pool':executor.bind(pool),'sources':source_records,'units':by_unit}
    executor.save(OUT/'native_run_formats.json',{'state':'NATIVE_EXPLICIT_RUN_FORMATS_BEFORE_PREDICTIONS',
                  'created_utc':executor.now(),'producer':executor.bind(Path(__file__)),
                  'scope':'Only explicit local w:rPr/w:vertAlign and w:t/w:delText tokens in current selected paragraphs. Inline insertion/deletion containers retained. No inherited style, field, equation, drawing, layout or semantic footnote resolution; not certified Word rendering.',
                  'cases':cases,'model_calls':0,'same_sidecar_for_all_modes':True})
    print(json.dumps({c:len(r['units']) for c,r in cases.items()}),flush=True)


if __name__=='__main__': main()
