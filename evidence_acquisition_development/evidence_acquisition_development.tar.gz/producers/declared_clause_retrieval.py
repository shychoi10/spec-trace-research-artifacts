"""Untrained controls for recovering source-declared clause references.

BM25 is an established model, not a SPECTRA contribution. The rationale-to-base
retrieval setup is antecedented by CR-Eval; version-matched localization and
structured lexical controls are antecedented by Bench4BL and BLUiR. See the
source-linked protocol in docs/.../codex/declared_clause_retrieval_protocol.md.
This module neither extracts labels nor decides source eligibility.
"""
from collections import Counter, defaultdict
from copy import deepcopy
import hashlib
import math
import re

TOKEN = re.compile(r"[A-Za-z0-9]+(?:[.-][A-Za-z0-9]+)*")


def tokens(text):
    """Frozen ASCII lexical control; retain dotted identifiers, no learned vocab."""
    if not isinstance(text, str):
        raise TypeError('text must be a string')
    return TOKEN.findall(text.lower())


class BM25:
    """Positive-IDF BM25, k1=1.2, b=.75; corpus is one full exact-base index.

    IDF = log(1 + (N - df + .5)/(df + .5)). Query terms contribute once each.
    Statistics use all candidates, never reference labels or query documents.
    """
    def __init__(self, documents, k1=1.2, b=.75):
        if not documents or not math.isfinite(k1) or k1 <= 0 or not 0 <= b <= 1:
            raise ValueError('nonempty documents and valid BM25 parameters required')
        self.n, self.k1, self.b = len(documents), k1, b
        self.postings = defaultdict(list)
        self.lengths = []
        for i, document in enumerate(documents):
            counts = Counter(tokens(document))
            self.lengths.append(sum(counts.values()))
            for term, count in counts.items():
                self.postings[term].append((i, count))
        self.avglen = sum(self.lengths)/self.n

    def score(self, query):
        query_terms = sorted(set(tokens(query)))
        result = [0.0] * self.n
        if self.avglen == 0:
            return result
        for term in query_terms:
            postings = self.postings.get(term, ())
            df = len(postings)
            if not df:
                continue
            idf = math.log1p((self.n - df + .5)/(df + .5))
            for i, tf in postings:
                norm = self.k1 * (1 - self.b + self.b*self.lengths[i]/self.avglen)
                result[i] += idf * tf * (self.k1 + 1)/(tf + norm)
        return result


def validate_candidates(candidates):
    ids = [c['candidate_id'] for c in candidates]
    if not ids or any(not isinstance(s, str) or not s for s in ids) or len(ids) != len(set(ids)):
        raise ValueError('candidate_id must be nonempty and unique')
    clause_ids = [c['clause_id'] for c in candidates]
    if any(not isinstance(s, str) or not s for s in clause_ids) or len(clause_ids) != len(set(clause_ids)):
        raise ValueError('ambiguous clause identities are not admitted by this runner')
    for c in candidates:
        for key in ['title', 'own_text']:
            if not isinstance(c[key], str):
                raise TypeError(key)
        if not isinstance(c['ancestor_titles'], list) or any(not isinstance(t, str) for t in c['ancestor_titles']):
            raise TypeError('ancestor_titles')
    return ids


def candidate_text(candidate):
    # Every method receives the identical serialized candidate information.
    return '\n'.join([candidate['clause_id'], *candidate['ancestor_titles'],
                      candidate['title'], candidate['own_text']])


def literal_id_hit(query, clause_id):
    """Literal occurrence diagnostic, not a certified reference resolver.

    Dotted clause IDs use token boundaries. A single integer/annex letter needs
    an immediately preceding 'clause', 'section' or 'annex' cue. Other-spec and
    numeric collisions are intentionally possible and must be measured.
    """
    if '.' in clause_id:
        pattern = r'(?<![A-Za-z0-9.])' + re.escape(clause_id) + r'(?![A-Za-z0-9]|\.[A-Za-z0-9])'
    else:
        pattern = r'\b(?:clause|section|annex)\s+' + re.escape(clause_id) + r'(?![A-Za-z0-9]|\.[A-Za-z0-9])'
    return bool(re.search(pattern, query, flags=re.I))


class Controls:
    def __init__(self, candidates):
        self.candidates = deepcopy(candidates)
        self.ids = validate_candidates(self.candidates)
        self.index = BM25([candidate_text(c) for c in self.candidates])

    def rank(self, query):
        scores = self.index.score(query)
        lexical = sorted(range(len(self.ids)), key=lambda i: (-scores[i], self.ids[i]))
        literal = [literal_id_hit(query, c['clause_id']) for c in self.candidates]
        orders = {
            'candidate_id_order': sorted(range(len(self.ids)), key=lambda i: self.ids[i]),
            'bm25_flat': lexical,
            'literal_id_then_bm25': sorted(range(len(self.ids)),
                                         key=lambda i: (-int(literal[i]), -scores[i], self.ids[i])),
        }
        return {name: [self.ids[i] for i in order] for name, order in orders.items()}, {
            'bm25': dict(zip(self.ids, scores)),
            'literal_id_hits': sorted(self.ids[i] for i, hit in enumerate(literal) if hit),
            'query_sha256': hashlib.sha256(query.encode()).hexdigest(),
        }


def evaluate(order, reference_ids, candidate_ids, cutoffs=(1, 5, 10)):
    """Full-permutation AP/MRR and recall of the recorded reference set.

    Reject missing reference candidates rather than silently shrinking its
    denominator. Relevance beyond the recorded declaration is not measured.
    """
    if not candidate_ids or len(candidate_ids) != len(set(candidate_ids)):
        raise ValueError('nonempty unique candidate universe required')
    if len(order) != len(set(order)) or set(order) != set(candidate_ids):
        raise ValueError('ranking must be a full permutation of the candidate universe')
    if not reference_ids or len(reference_ids) != len(set(reference_ids)):
        raise ValueError('nonempty unique reference set required')
    reference = set(reference_ids)
    if not reference <= set(order):
        raise ValueError('reference outside supplied candidate set')
    ranks = [i for i, c in enumerate(order, 1) if c in reference]
    metrics = {'reciprocal_rank': 1/ranks[0],
               'average_precision': sum(j/r for j, r in enumerate(ranks, 1))/len(reference),
               'reference_count': len(reference), 'candidate_count': len(order)}
    for k in cutoffs:
        if type(k) is not int or k <= 0:
            raise ValueError('positive integer cutoff required')
        hits = sum(r <= k for r in ranks)
        metrics[f'recall_at_{k}'] = hits/len(reference)
        metrics[f'hit_at_{k}'] = int(hits > 0)
        metrics[f'all_references_at_{k}'] = int(hits == len(reference))
        metrics[f'inspected_at_{k}'] = min(k, len(order))
    return metrics
