#!/usr/bin/env python3
"""Compare source acquisition with the same strong direct answer instruction.

Metadata filtering, exact-text deduplication, contextual BM25, and version
matching are established techniques. This is a bounded development instrument,
not a faithful implementation or defeat of any published retrieval system.
"""
import argparse
import json
from pathlib import Path
import subprocess
import time

from declared_clause_retrieval import BM25
import run_codex_relation_comparison as executor
from priority5_evidence_acquisition import OUT, BASE

MODES = ('source_complete_selected_direct', 'metadata_bm25_neighbors', 'scope_version_closure')
BUDGET = 12000
POLICY = '''Use only the supplied source units, their explicit occurrences, and
inventory. Use strong contextual direct reading: verify each technical fact
against the passages and check conditions, table configuration, clause, source
role, and observed version. No tools, external knowledge, prior answers or
author reference. Exact-text deduplication retains all listed occurrences: a
unit text may be cited through any of its supplied occurrence IDs. Do not infer
that a source withheld by retrieval is absent from the complete saved pool.
The inventory can establish which evidence types are unavailable, but cannot
replace withheld technical content. Distinguish requested change, projected
inline edits, observed endpoint text, actual official approval/processing,
first historical introduction, sole causation and measured/deployed behavior.
BEFORE/AFTER resolve inline tokens only; table structural revisions, rendering,
automatic fields, reference resolution and full math/drawing layout remain
unresolved. Retained neighboring table rows supply configuration context;
empty cells are not independently certified merges. Give supported technical
details even when a broader conclusion is not established. Answer every Q in
order, with up to 250 words each; Q2 may use up to 400 words if the technical
changes need it. Avoid unnecessary abstention when supplied evidence suffices.
Return exactly one JSON object:
{"answers":[{"id":"Q1","answer":"...","established_facts":["..."],
"missing_information":["specific missing evidence, if needed"],
"evidence":[{"source_id":"an explicitly supplied occurrence ID",
"quote":"an exact nonempty substring of that supplied unit text"}]}]}
Include Q1–Q4. A literal quote match is not a semantic certificate.
'''


def metadata(unit):
    result = {k: unit[k] for k in ('id','document_id','role','specification','version','clause','heading','paragraphs','kind','changed')}
    if unit.get('explicit_native_run_formats'):
        result['explicit_native_run_formats']=unit['explicit_native_run_formats']
    return result


def unique_units(units):
    unique=[]; lookup={}; aliases={}
    for unit in units:
        index=lookup.get(unit['text'])
        if index is None:
            index=len(unique); lookup[unit['text']]=index
            unique.append({'id':unit['id'],'text':unit['text'],'occurrences':[]})
        unique[index]['occurrences'].append(metadata(unit)); aliases[unit['id']]=index
    return unique,aliases


def context_bundles(original, aliases, inventory):
    contexts={i:{i} for i in set(aliases.values())}
    documents={}
    for u in original: documents.setdefault(u['document_id'],[]).append(u)
    for rows in documents.values():
        for position,u in enumerate(rows):
            index=aliases[u['id']]
            for v in rows[max(0,position-1):position+2]:
                if v['clause']==u['clause']: contexts[index].add(aliases[v['id']])
            if u['kind']=='table_row':
                contexts[index].update(aliases[v['id']] for v in rows if v['kind']=='table_row' and
                                      v['table']==u['table'] and (v['header_declared'] or v['row']<2))
    blocks=list(inventory['CR_configuration_blocks'])
    for endpoint in inventory['endpoint_excerpt_matches']:
        for member in endpoint['matched_members']:
            packet=executor.read(executor.verify(member['packet']))
            blocks.extend(packet['selected_configuration_blocks'])
    for block in blocks:
        indexes={aliases[r] for r in block['rows'] if r in aliases}
        for i in indexes: contexts[i].update(indexes)
    return contexts


def ranked_bundles(unique, contexts, questions):
    encoded=[u['text']+'\n'+json.dumps(u['occurrences'],ensure_ascii=False,sort_keys=True) for u in unique]
    index=BM25(encoded); queues=[]; scores=[]
    for question in questions:
        score=index.score(question['question']); scores.append(score)
        roles=('CR',) if question['id']=='Q1' else ('CR','base','target')
        for role in roles:
            eligible=[i for i,u in enumerate(unique) if any(o['role']==role for o in u['occurrences'])]
            queues.append(sorted(eligible,key=lambda i:(-score[i],unique[i]['id'])))
    ordered=[]
    for depth in range(max(map(len,queues))):
        for queue in queues:
            if depth<len(queue): ordered.append(sorted(contexts[queue[depth]]))
    return ordered,scores,index


def pack(bundles, unique, budget):
    chosen=set(); skipped=[]; used=0
    for bundle in bundles:
        new=set(bundle)-chosen; cost=sum(len(unique[i]['text']) for i in new)
        if used+cost<=budget: chosen.update(new); used+=cost
        elif new: skipped.append({'unit_ids':[unique[i]['id'] for i in sorted(new)],'source_characters':cost})
    return sorted(chosen),used,skipped


def closure_bundles(original, unique, aliases, contexts, index, baseline):
    cover=[u for u in original if u['role']=='CR' and u['clause'] is None]
    technical=[u for u in cover if any(s in u['text'] for s in
               ('Reason for change:','Summary of change:','Clauses affected:','Title:','Current version:','Release:'))]
    result=[[aliases[u['id']] for u in technical]]
    changes=[u for u in original if u['role']=='CR' and u['changed']]
    for changed in changes:
        indexes=set(contexts[aliases[changed['id']]])
        for role,view in (('base','before'),('target','after')):
            candidates=[u for u in original if u['role']==role and u['clause']==changed['clause'] and u['kind']==changed['kind']]
            if not candidates: continue
            text=changed[view]
            exact=[u for u in candidates if text and u['text']==text]
            scores=index.score(text or changed['text'])
            selected=exact[0] if exact else sorted(candidates,key=lambda u:(-scores[aliases[u['id']]],u['id']))[0]
            indexes.update(contexts[aliases[selected['id']]])
        result.append(sorted(indexes))
    # Complete retained prose beside edited clauses before lexical backfill.
    edited_clauses={u['clause'] for u in changes if u['clause']}
    for clause in sorted(edited_clauses):
        ids={aliases[u['id']] for u in original if u['clause']==clause and u['kind']=='paragraph'}
        if ids: result.append(sorted(ids))
    return result+baseline


def prepare():
    executor.guarded(); selection=executor.read(OUT/'selection.json')
    formats=executor.read(OUT/'native_run_formats.json')
    (OUT/'acquisition').mkdir(); (OUT/'inputs').mkdir()
    executor.text_new(OUT/'direct_policy.txt',POLICY)
    records=[]
    for ci,selected in enumerate(selection['selected']):
        acquisition_start=time.perf_counter(); acquisition_cpu=time.process_time()
        cid='row'+str(selected['row_id']); path=OUT/'sources/scoped'/(cid+'.pool.json')
        packet=executor.read(path); original=packet['units']
        executor.verify(formats['cases'][cid]['pool'])
        for u in original:
            u['explicit_native_run_formats']=formats['cases'][cid]['units'].get(u['id'],[])
        unique,aliases=unique_units(original)
        contexts=context_bundles(original,aliases,packet['inventory'])
        spec,base,target=selected['transition']; _,cr,rev=selected['cr_identity']
        questions=[{'id':q['id'],'question':q['question'].format(spec=spec,cr=cr,rev=rev,tdoc=selected['wg_tdoc'],base=base,target=target)} for q in selection['query_templates']]
        baseline,scores,index=ranked_bundles(unique,contexts,questions)
        closure=closure_bundles(original,unique,aliases,contexts,index,baseline)
        modes={MODES[0]:(list(range(len(unique))),sum(len(u['text']) for u in unique),[]),
               MODES[1]:pack(baseline,unique,BUDGET),MODES[2]:pack(closure,unique,BUDGET)}
        mode_records={}
        for mode,(chosen,characters,skipped) in modes.items():
            supplied=[unique[i] for i in chosen]
            body='QUESTIONS\n'+json.dumps(questions,ensure_ascii=False)+'\n\nSOURCE INVENTORY\n'+json.dumps(packet['inventory'],ensure_ascii=False)+'\n\nSUPPLIED UNITS WITH OCCURRENCES\n'
            body+='\n'.join(json.dumps(u,ensure_ascii=False,separators=(',',':')) for u in supplied)
            file=OUT/'inputs'/(cid+'.'+mode+'.txt'); executor.text_new(file,body)
            mode_records[mode]={'input':executor.bind(file),'source_characters':characters,
                               'input_characters':len(body),'non_source_serialization_characters':len(body)-characters,
                               'unique_units':len(supplied),'original_occurrences':sum(len(u['occurrences']) for u in supplied),
                               'supplied_occurrence_ids':[o['id'] for u in supplied for o in u['occurrences']],
                               'selected_unique_ids':[u['id'] for u in supplied], 'skipped_atomic_bundles':skipped}
        acquisition=OUT/'acquisition'/(cid+'.json')
        executor.save(acquisition,{'case':cid,'pool':executor.bind(path),'questions':questions,'modes':mode_records,
                                 'unique_text_units':len(unique),'original_units':len(original),
                                 'deduplication':'Exact text only; all role/version/paragraph occurrences retained for every mode.',
                                 'control':'Same case/spec metadata filter, BM25 across identical text+occurrence metadata, question/role-stratified ranking, adjacent paragraphs, table headers and full explicit configuration blocks. No semantic encoder or LLM retrieval pass.',
                                 'candidate':'Technical CR cover and every inline-change context prioritized, matched same-clause base/target text (exact first, contextual BM25 fallback), complete retained clause prose, then identical control backfill. No reference labels, implementation claim for a published system, or semantic match certificate.',
                                 'deterministic_acquisition_and_serialization_seconds':time.perf_counter()-acquisition_start,
                                 'preparation_cpu_seconds':time.process_time()-acquisition_cpu,
                                 'budget':BUDGET,'budget_units':'Actual unique supplied source-text characters; serialization/metadata extra reported separately; no equal-token/TCO claim.'})
        order=list(MODES[ci:]+MODES[:ci])
        records.append({'id':cid,'acquisition':executor.bind(acquisition),'pool':executor.bind(path),'questions':questions,
                        'modes':{m:r['input'] for m,r in mode_records.items()},'order':order})
    executor.save(OUT/'acquisition_preparation.json',{'state':'DETERMINISTIC_INPUTS_PREPARED_BEFORE_PREDICTIONS',
                    'created_utc':executor.now(),'producer':executor.bind(Path(__file__)),'cases':records,
                    'model_calls':0,'author_reference_used_in_retrieval':False,'same_pools_and_budget':True})
    print(json.dumps([{'case':r['id'],'inputs':r['modes']} for r in records]),flush=True)


def freeze():
    executor.guarded(); prepared=executor.read(OUT/'acquisition_preparation.json')
    readback=executor.read(OUT/'root_source_readback.json')
    assert readback['all_current_supplied_selected_units_directly_read']
    reference=executor.read(OUT/'author_reference.json')
    for case in prepared['cases']:
        units={u['id']:u['text'] for u in executor.read(executor.verify(case['pool']))['units']}
        assert [r['id'] for r in reference['cases'][case['id']]]==['Q1','Q2','Q3','Q4']
        for row in reference['cases'][case['id']]:
            for evidence in row['evidence']:
                assert evidence['quote'] and evidence['quote'] in units[evidence['source_id']]
        for binding in case['modes'].values(): executor.verify(binding)
    settings=executor.read(BASE/'experiments/relation_annotation/priority4_obligation_contrasts/protocol.json')
    binary=executor.verify(settings['cli_binary'])
    login=subprocess.run([str(binary),'login','status'],capture_output=True,text=True,timeout=30)
    assert login.returncode==0 and 'ChatGPT' in login.stdout+login.stderr
    dependencies=[Path(__file__),Path(executor.__file__),Path(executor.collector.__file__),
                  Path(executor.collector.control.__file__),Path(__file__).with_name('declared_clause_retrieval.py')]
    dependencies += [OUT/p for p in ('selection.json','source_audit.json','clause_excerpt_policy.json','scoped_source_preparation.json',
                                    'acquisition_preparation.json','native_run_formats.json','root_source_readback.json','primary_recomparison.json')]
    executor.save(OUT/'protocol.json',{'state':'FROZEN_BEFORE_ALL_NINE_FIRST_PREDICTIONS','created_utc':executor.now(),
                 'producer':executor.bind(Path(__file__)),'dependencies':[executor.bind(p) for p in dependencies],
                 'reference_not_supplied_to_predictions':executor.bind(OUT/'author_reference.json'),
                 'cli_binary':settings['cli_binary'],'cli_version':subprocess.check_output([str(binary),'--version'],text=True).strip(),
                 'config_overrides':settings['config_overrides'],'policies':{m:executor.bind(OUT/'direct_policy.txt') for m in MODES},
                 'cases':prepared['cases'],'per_turn_wall_limit_seconds':900,'attempts_per_condition':1,
                 'planned_prediction_calls':9,'obligations':12,'answer_cells':36,'retrieved_source_character_budget':BUDGET,
                 'sampling':'Provider defaults, temperature/seed/output cap uncontrolled.',
                 'assessment':'Author source-readback of technical recovery/false promotions/refutations/uncertainty/unnecessary abstention separately. Literal quotes and acquisition source coverage separate from meaning. Exposed related-family development, not expert gold or heldout accuracy.',
                 'full_selected_diagnostic':'Uses every unique selected source-text unit; actual information equality/extra information depends on each saved selected subset. Not full native corpus or compute-matched retrieval comparison.',
                 'failure':'Stop subsequent dispatch after incomplete/timeout/uncontrolled first call. Preserve every attempt/missing cell; no repair/resampling.',
                 'cost':'All actual first token/cache/request seconds; lexical acquisition seconds and source preparation separately. No monetary/TCO or causal latency advantage.',
                 'protected_email_bodies_opened':0,'independent_components_certified':False,'new_neural_method_claim':False})
    print('FROZEN_BEFORE_ALL_NINE_FIRST_PREDICTIONS',flush=True)


def run():
    executor.guarded(); plan=executor.read(OUT/'protocol.json')
    for b in plan['dependencies']+list(plan['policies'].values())+[plan['reference_not_supplied_to_predictions']]:executor.verify(b)
    executor.OUT=OUT; (OUT/'predictions').mkdir(); attempts=[]
    try:
        for case in plan['cases']:
            executor.verify(case['acquisition']);executor.verify(case['pool'])
            for mode in case['order']:
                attempts.append({'case':case['id'],'mode':mode})
                executor.turn(plan,OUT/'predictions'/(case['id']+'.'+mode),case['modes'][mode],mode)
    except Exception as error:
        executor.save(OUT/'completion.json',{'state':'STOPPED_FIRST_FAILED_OR_UNCONTROLLED_CALL','finished_utc':executor.now(),
                      'attempts':attempts,'error':repr(error),'retries':0});raise
    executor.save(OUT/'completion.json',{'state':'ALL_NINE_FIRST_CONTROLLED_ANSWERS_SAVED','finished_utc':executor.now(),
                  'attempts':attempts,'retries':0})


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare','freeze','run'])
    globals()[parser.parse_args().action]()
