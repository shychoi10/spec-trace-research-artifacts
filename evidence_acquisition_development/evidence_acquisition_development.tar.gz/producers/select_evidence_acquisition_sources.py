#!/usr/bin/env python3
"""Apply a saved CR-conditioned excerpt policy before any prediction.

Excerpt availability and missing matches are recorded, not treated as semantic
labels. Configuration context remains original rows with explicit boundaries.
"""
import argparse
import gc
import json
from pathlib import Path
import re
import shutil

from stream_scoped_word_tables import grouped, CLAUSE
import project_standards_content as projection
import run_codex_relation_comparison as executor
from priority5_evidence_acquisition import OUT

COMBO = re.compile(r'(?:CA|DC)_[0-9A-Za-z_-]+')


def first_cell(unit):
    if unit['kind'] != 'table_row' or not unit['cells']: return ''
    return unit['cells'][0]['after'] or unit['cells'][0]['before']


def scope(units, clauses, titles):
    current = None
    result = []
    for unit in units:
        text = unit['after'] or unit['before']
        style = (unit.get('style') or '').lower()
        literal = CLAUSE.match(text) if unit['kind'] == 'paragraph' and not style.startswith('toc') else None
        if literal:
            current = literal.group(1).rstrip('.')
        elif unit['kind'] == 'paragraph' and style.startswith('heading'):
            current = titles.get(text.strip())
        copied = {**unit, 'clause': current}
        if current and any(current == c or current.startswith(c + '.') for c in clauses): result.append(copied)
    return result


def selected_rows(units, combos, force_changes=False):
    chosen = set()
    for i, unit in enumerate(units):
        if unit['kind'] == 'paragraph': chosen.add(i)
        if unit['kind'] == 'table_row' and (unit['header_declared'] or unit['row'] < 2 or
                                          'NOTE' in unit['text']): chosen.add(i)
    blocks = []
    start = None
    labels = set()
    for i, unit in enumerate(units):
        explicit = set(COMBO.findall(first_cell(unit)))
        boundary = unit['kind'] != 'table_row' or (i and units[i-1].get('table') != unit.get('table'))
        if start is not None and (boundary or explicit):
            blocks.append((start, i, labels)); start = None
        if explicit: start, labels = i, explicit
    if start is not None: blocks.append((start, len(units), labels))
    selected_blocks = []
    for start, end, labels in blocks:
        if labels & combos or (force_changes and any(u['changed'] for u in units[start:end])):
            chosen.update(range(start, end))
            selected_blocks.append({'first': units[start]['id'], 'last': units[end-1]['id'],
                                    'configuration_labels': sorted(labels),
                                    'rows': [u['id'] for u in units[start:end]]})
    if force_changes:
        chosen.update(i for i, u in enumerate(units) if u['changed'])
    return [u for i, u in enumerate(units) if i in chosen], selected_blocks


def prepare():
    executor.guarded()
    policy = executor.bind(OUT / 'clause_excerpt_policy.json')
    audit = executor.read(OUT / 'source_audit.json')
    (OUT / 'endpoints' / 'scoped').mkdir(exist_ok=True)
    (OUT / 'sources' / 'scoped').mkdir(exist_ok=True)
    summaries = []
    for case in audit['cases']:
        cid = case['id']; spec, base_version, target_version = case['selection']['transition']
        cached = OUT / 'sources' / 'scoped' / (cid + '.pool.json')
        if cached.exists():
            packet = executor.read(cached)
            for endpoint in packet['inventory']['endpoint_excerpt_matches']:
                for member in endpoint['matched_members']:
                    executor.verify(member['native']); executor.verify(member['corrected_projection']); executor.verify(member['packet'])
            retained = packet['units']
            summaries.append({'id':cid, 'units':len(retained), 'source_characters':sum(len(u['text']) for u in retained),
                              'roles':{r:sum(u['role']==r for u in retained) for r in ('CR','base','target')},
                              'packet':executor.bind(cached), 'resumed_preserved_completed_case':True})
            continue
        projected = executor.read(executor.verify(case['cr_projection']))
        ps = projected['paragraphs']
        ci = next(i for i,p in enumerate(ps) if p['after'].strip() == 'Clauses affected:')
        affected = next(p['after'].strip() for p in ps[ci+1:] if p['after'].strip())
        clauses = [c.strip() for c in affected.split(',')]
        cr = executor.read(OUT / 'sources' / (cid + '.rows.json'))['units']
        body = next(i for i,u in enumerate(cr) if u['kind']=='paragraph' and CLAUSE.match(u['after'] or u['before']) and min(u['paragraphs']) > ci)
        cover = cr[:body]
        combos = set(COMBO.findall('\n'.join(u['text'] for u in cover)))
        titles = {}
        for u in cr[body:]:
            if u['kind'] != 'paragraph': continue
            for view in ('before','after'):
                m = CLAUSE.match(u[view])
                if m: titles[m.group(2).strip()] = m.group(1).rstrip('.')
        cr_body = scope(cr[body:], clauses, titles)
        selected, blocks = selected_rows(cr_body, combos, force_changes=True)
        units = [{**u, 'clause': None} for u in cover] + selected
        inventory = {'case': cid, 'specification': spec, 'submitted_CR': case['selection']['cr_identity'],
                     'wg_tdoc': case['selection']['wg_tdoc'], 'tsg_copy': case['selection']['tsg_tdoc'],
                     'tsg_copy_is_byte_identical': len({x['native']['sha256'] for x in case['selection']['inputs']})==1,
                     'affected_clauses_declared': clauses, 'configuration_labels_from_cover': sorted(combos),
                     'CR_configuration_blocks': blocks, 'endpoint_excerpt_matches': [],
                     'source_scope': 'Complete textual CR cover plus selected affected-clause prose, table headers/notes and complete configuration-label blocks. Observed endpoint excerpts use the same rule. Only saved excerpts are supplied; absence outside them is unresolved.',
                     'absent_evidence_types': ['official CR processing decision/history', 'exhaustive earlier/later specification versions', 'every co-occurring CR', 'external referenced clauses beyond selected excerpts', 'measured performance', 'particular deployed UE/device records'],
                     'projection_scope': projected['projection_scope'],
                     'table_scope': 'Grid and labelled vertical continuations; empty first-column configuration context supplied as original preceding/following rows, without certifying merge semantics or rendered table layout.'}
        for role, version in (('base',base_version),('target',target_version)):
            endpoint = case['endpoints'][role]
            matches = []
            for ai, artifact in enumerate(endpoint['artifacts']):
                if artifact['cover_only']: continue
                native = executor.verify(artifact['native'])
                projected_endpoint = executor.read(executor.verify(artifact['corrected_projection']))
                did = cid + ':' + role + ':' + str(ai)
                all_units, native_audit = grouped(native, projected_endpoint, did, role, spec, version, clauses, titles)
                scoped = scope(all_units, clauses, titles)
                picked, endpoint_blocks = selected_rows(scoped, combos)
                if picked:
                    dest = OUT / 'native' / (did.replace(':','_') + '.scoped.docx'); shutil.copyfile(native,dest)
                    executor.save(OUT / 'endpoints' / 'scoped' / (did.replace(':','_') + '.json'),
                                  {'native': executor.bind(dest), 'original_member': artifact,
                                   'selected_units': picked, 'selected_configuration_blocks': endpoint_blocks, 'selected_native_text_audit': native_audit,
                                   'scope': 'Selected textual excerpts; original document and corrected projection bound separately.'})
                    units.extend(picked)
                    matches.append({'member': artifact['member_chain'], 'native': executor.bind(dest),
                                    'corrected_projection': artifact['corrected_projection'],
                                    'selected': len(picked), 'scoped_before_selection': len(scoped), 'selected_native_text_audit': native_audit,
                                    'clauses': sorted({u['clause'] for u in picked if u['clause']}),
                                    'configuration_labels': sorted({c for b in endpoint_blocks for c in b['configuration_labels']}),
                                    'packet': executor.bind(OUT / 'endpoints' / 'scoped' / (did.replace(':','_') + '.json'))})
                del all_units, scoped, picked, projected_endpoint
                gc.collect()
            inventory['endpoint_excerpt_matches'].append({'role': role, 'version': version,
                                                           'native_cover_verified': endpoint['native_cover_verified'],
                                                           'matched_members': matches,
                                                           'no_match': not matches})
        executor.save(OUT / 'sources' / 'scoped' / (cid + '.pool.json'), {'units': units, 'inventory': inventory})
        executor.text_new(OUT / 'sources' / 'scoped' / (cid + '.pool.txt'),
                          '\n\n'.join('['+u['id']+'] '+u['role']+' v='+u['version']+' clause='+str(u['clause'])+'\n'+u['text'] for u in units))
        summaries.append({'id':cid, 'units':len(units), 'source_characters':sum(len(u['text']) for u in units),
                          'roles': {r:sum(u['role']==r for u in units) for r in ('CR','base','target')},
                          'packet':executor.bind(OUT/'sources'/'scoped'/(cid+'.pool.json'))})
    executor.save(OUT/'scoped_source_preparation.json',{'state':'SELECTED_CR_AND_OBSERVED_ENDPOINT_EXCERPTS_PREPARED_NO_PREDICTIONS',
                  'created_utc':executor.now(),'producer':executor.bind(Path(__file__)),
                  'dependencies':[executor.bind(Path(grouped.__code__.co_filename)),executor.bind(OUT/'source_audit.json')],
                  'policy':policy,'cases':summaries,'model_calls':0,'protected_email_bodies':0,
                  'semantic_gold':False,'native_rendering_certified':False})
    print(json.dumps(summaries),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=['prepare'])
    globals()[parser.parse_args().action]()
