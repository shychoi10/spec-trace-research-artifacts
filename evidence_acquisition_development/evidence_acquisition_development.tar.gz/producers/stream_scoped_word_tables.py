"""Stream native selected clause rows and independently check their text.

No complete specification XML tree is retained in memory. Projection scope and
unresolved structural revisions remain identical to the saved textual contract.
"""
import re
import xml.etree.ElementTree as ET
import zipfile

import project_standards_content as projection

W, M, A = projection.W, projection.M, projection.A
CLAUSE = re.compile(r'^\s*((?:[0-9]+[A-Za-z]?(?:\.[0-9]+[A-Za-z]?)*|A(?:\.[0-9]+[A-Za-z]?)+))[\t ]+(.+)$')


def content(element, view):
    tag = element.tag
    if projection.property_element(tag): return ''
    if view == 'before' and tag in {W+'ins', W+'moveTo'}: return ''
    if view == 'after' and tag in {W+'del', W+'moveFrom'}: return ''
    if tag in {W+'t', W+'delText', M+'t', A+'t'}: return element.text or ''
    if tag == W+'tab': return '\t'
    if tag in {W+'br', W+'cr'}: return '\n'
    if tag.rsplit('}',1)[-1] in {'t','delText','tab','br','cr'}:
        raise ValueError('Unknown text token namespace: '+tag)
    return ''.join(content(child,view) for child in element)


def grouped(native, projected, document_id, role, spec, version, clauses, titles):
    ps = projected['paragraphs']; current = None; scope_map = {}; selected = set()
    units, stack, pids, verified, covered = [], [], {}, set(), set()
    count, table, row_number, table_depth, row_depth, paragraph_depth = 0, -1, -1, 0, 0, 0
    heading = ''; inherited = {'before':{},'after':{}}

    def append(uid,text,ids,clause,**extra):
        covered.update(set(ids)&selected)
        if text.strip():
            units.append({'id':document_id+':'+uid,'text':text,'document_id':document_id,
                          'role':role,'specification':spec,'version':version,'heading':heading,
                          'clause':clause,'paragraphs':ids,**extra})

    def descendants(container,tag):
        result=[]
        for child in container:
            if child.tag==tag: result.append(child)
            elif child.tag!=W+'tbl': result.extend(descendants(child,tag))
        return result

    with zipfile.ZipFile(native) as archive, archive.open('word/document.xml') as source:
        for event, element in ET.iterparse(source,events=('start','end')):
            if event=='start':
                stack.append(element)
                if element.tag==W+'p': pids[id(element)]=count; count+=1; paragraph_depth+=1
                if element.tag==W+'tbl':
                    if table_depth==0: table+=1; row_number=-1; inherited={'before':{},'after':{}}
                    table_depth+=1
                if element.tag==W+'tr': row_depth+=1
                continue
            if element.tag==W+'p':
                i=pids[id(element)]; p=ps[i]
                if paragraph_depth==1 and table_depth==0:
                    text=p['after'] or p['before']; style=(p['style'] or '').lower()
                    match=CLAUSE.match(text) if not style.startswith('toc') else None
                    if match and ('.' in match.group(1) or style.startswith('heading')):
                        current=match.group(1); heading=text
                    elif style.startswith('heading'):
                        current=titles.get(text.strip()); heading=text
                applicable=current and any(current==c or current.startswith(c+'.') for c in clauses)
                if applicable:
                    for child in element.iter(W+'p'):
                        index=pids[id(child)]
                        scope_map[index]=current; selected.add(index)
                        for view in ('before','after'):
                            if content(child,view)!=ps[index][view]:
                                raise ValueError('Selected native text mismatch at p'+str(index))
                        verified.add(index)
                if paragraph_depth==1 and table_depth==0:
                    ids=[pids[id(child)] for child in element.iter(W+'p')]
                    if set(ids)&selected:
                        if (p['style'] or '').lower().startswith('heading') or CLAUSE.match(p['after'] or p['before']): heading=p['after'] or p['before']
                        text=p['after'] if p['before']==p['after'] else 'BEFORE: '+p['before']+'\nAFTER: '+p['after']
                        append('p'+str(i),text,ids,scope_map.get(i),kind='paragraph',style=p['style'],
                               changed=p['before']!=p['after'],before=p['before'],after=p['after'],
                               nested_paragraph_projection_aliases=ids[1:])
                    for child in element.iter(W+'p'): pids.pop(id(child),None)
                    parent=stack[-2] if len(stack)>1 else None
                    element.clear()
                    if parent is not None: parent.remove(element)
                paragraph_depth-=1
            elif element.tag==W+'tr':
                if row_depth==1:
                    row_number+=1; ids=[pids[id(p)] for p in element.iter(W+'p')]
                    covered.update(set(ids)&selected)
                    if set(ids)&selected:
                        trpr=element.find(W+'trPr'); start=trpr.find(W+'gridBefore') if trpr is not None else None
                        col=int(start.get(W+'val','0')) if start is not None else 0; cells=[]
                        for cell in descendants(element,W+'tc'):
                            cp=[pids[id(p)] for p in cell.iter(W+'p')]; pr=cell.find(W+'tcPr')
                            span=pr.find(W+'gridSpan') if pr is not None else None
                            width=int(span.get(W+'val','1')) if span is not None else 1
                            vm=pr.find(W+'vMerge') if pr is not None else None
                            merge=vm.get(W+'val','continue') if vm is not None else None
                            item={'grid_columns':[col+1,col+width],'grid_span':width,'vertical_merge':merge,'paragraphs':cp}
                            for view in ('before','after'):
                                text='\n'.join(ps[i][view] for i in cp if ps[i][view].strip())
                                item[view]=text
                                item[view+'_vertical_context']=inherited[view].get(col,'') if merge=='continue' else ''
                                if merge=='restart': inherited[view][col]=text
                                elif merge is None: inherited[view].pop(col,None)
                            cells.append(item); col+=width
                        def render(view):
                            parts=[]
                            for cell in cells:
                                lo,hi=cell['grid_columns']; label='C'+str(lo)+(('-'+str(hi)) if hi!=lo else '')
                                value=cell[view]; context=cell[view+'_vertical_context']
                                if context: value='[vertical continuation from prior row] '+context+('\n'+value if value else '')
                                parts.append(label+': '+value)
                            return '\n'.join(parts)
                        before,after=render('before'),render('after')
                        text=after if before==after else 'BEFORE CELLS:\n'+before+'\nAFTER CELLS:\n'+after
                        if any(c['before'] or c['after'] or c['before_vertical_context'] or c['after_vertical_context'] for c in cells):
                            append('t'+str(table)+'r'+str(row_number),text,ids,next(scope_map[i] for i in ids if i in scope_map),
                                   kind='table_row',table=table,row=row_number,cells=cells,changed=before!=after,
                                   header_declared=trpr is not None and trpr.find(W+'tblHeader') is not None,before=before,after=after)
                    for p in element.iter(W+'p'): pids.pop(id(p),None)
                    parent=stack[-2]; element.clear(); parent.remove(element)
                row_depth-=1
            elif element.tag==W+'tbl':
                table_depth-=1
                if table_depth==0:
                    parent=stack[-2]; element.clear(); parent.remove(element)
            stack.pop()
    if count!=len(ps): raise ValueError('Native paragraph enumeration differs')
    if verified!=selected or covered!=selected:
        raise ValueError('Selected native scope coverage differs: verified_missing=' + str(sorted(selected-verified)[:8]) + '; represented_missing=' + str([(i,len(ps[i]['before']),len(ps[i]['after'])) for i in sorted(selected-covered)[:8]]))
    return units, {'native_paragraphs':count,'selected_paragraphs':len(scope_map),
                   'selected_before_after_native_text_matches':len(verified),
                   'selected_coordinates_accounted':len(covered),'complete_native_rendering':False}
