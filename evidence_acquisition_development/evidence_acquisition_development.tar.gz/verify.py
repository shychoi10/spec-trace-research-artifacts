#!/usr/bin/env python3
"""Offline saved-source/input/quote replay. No inference or semantic scoring."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode=True


def digest(path):
    raw=path.read_bytes()
    return {'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}


def read(path): return json.loads(path.read_text())


def unique_units(units, formats):
    result=[];lookup={}
    for unit in units:
        meta={k:unit[k] for k in ('id','document_id','role','specification','version','clause','heading','paragraphs','kind','changed')}
        if formats.get(unit['id']):meta['explicit_native_run_formats']=formats[unit['id']]
        i=lookup.get(unit['text'])
        if i is None:
            i=len(result);lookup[unit['text']]=i
            result.append({'id':unit['id'],'text':unit['text'],'occurrences':[]})
        result[i]['occurrences'].append(meta)
    return result


def verify(directory):
    manifest=read(directory/'manifest.json')
    for entry in manifest['files']:
        path=directory/entry['path']
        if digest(path)!={k:entry[k] for k in ('bytes','sha256')}:raise ValueError('Package hash differs: '+entry['path'])
    module_spec=importlib.util.spec_from_file_location('saved_acquisition_method',directory/'replay_method.py')
    method=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(method)
    method.executor=method.PackageReader(directory)
    formats=read(directory/'native_run_formats.json'); calls=0;quotes=0;defects=[]; inputs=[]
    for case in ('row1','row23','row25'):
        pool=read(directory/'sources'/ (case+'.pool.json'));a=read(directory/'acquisition'/(case+'.json'))
        unique=unique_units(pool['units'],formats['cases'][case]['units']);by_id={u['id']:u for u in unique}
        original=pool['units']
        for u in original:u['explicit_native_run_formats']=formats['cases'][case]['units'].get(u['id'],[])
        actual_unique,aliases=method.unique_units(original)
        if actual_unique!=unique:raise ValueError('Shared deduplication differs')
        contexts=method.context_bundles(original,aliases,pool['inventory'])
        baseline,_,index=method.ranked_bundles(unique,contexts,a['questions'])
        closure=method.closure_bundles(original,unique,aliases,contexts,index,baseline)
        computed={'source_complete_selected_direct':list(range(len(unique))),
                  'metadata_bm25_neighbors':method.pack(baseline,unique,12000)[0],
                  'scope_version_closure':method.pack(closure,unique,12000)[0]}
        for mode,r in a['modes'].items():
            if [unique[i]['id'] for i in computed[mode]]!=r['selected_unique_ids']:
                raise ValueError('Deterministic acquired subset differs')
            supplied=[by_id[i] for i in r['selected_unique_ids']]
            chars=sum(len(u['text']) for u in supplied)
            if chars!=r['source_characters'] or (mode!='source_complete_selected_direct' and chars>12000):
                raise ValueError('Source budget differs')
            body='QUESTIONS\n'+json.dumps(a['questions'],ensure_ascii=False)+'\n\nSOURCE INVENTORY\n'+json.dumps(pool['inventory'],ensure_ascii=False)+'\n\nSUPPLIED UNITS WITH OCCURRENCES\n'
            body+='\n'.join(json.dumps(u,ensure_ascii=False,separators=(',',':')) for u in supplied)
            actual=directory/'inputs'/(case+'.'+mode+'.txt')
            if actual.read_text()!=body:raise ValueError('Saved input reconstruction differs')
            aliases={o['id']:u['text'] for u in supplied for o in u['occurrences']}
            answer=read(directory/'predictions'/(case+'.'+mode)/'answer.txt')
            if [q['id'] for q in answer['answers']]!=['Q1','Q2','Q3','Q4']:raise ValueError('Question order differs')
            for q in answer['answers']:
                for e in q['evidence']:
                    quotes+=1
                    if e['source_id'] not in aliases or not e['quote'] or e['quote'] not in aliases[e['source_id']]:
                        defects.append({'case':case,'mode':mode,'question':q['id'],'anchor':e})
            calls+=1;inputs.append({'case':case,'mode':mode,'source_characters':chars,'unique_units':len(supplied)})
    expected=sum(len(c['literal_defects']) for c in read(directory/'mechanical_replay.json')['calls'])
    if len(defects)!=expected:raise ValueError('Preserved first quote defect count differs')
    return {'state':'SAVED_SOURCE_INPUT_AND_LITERAL_QUOTE_REPLAY_PASS','files_checked':len(manifest['files']),
            'first_calls':calls,'answer_cells':calls*4,'quotes':quotes,'literal_defects':defects,'inputs':inputs,
            'model_calls':0,'meaning_certified':False,'native_projection_recomputed':False,
            'retrieval_rank_recomputed':True,'limit':'Package hashes, deterministic source selection and saved input reconstruction; not native rendering, semantic truth, independent expert annotation or rerun inference.'}


if __name__=='__main__':print(json.dumps(verify(Path(sys.argv[1])),ensure_ascii=False))
