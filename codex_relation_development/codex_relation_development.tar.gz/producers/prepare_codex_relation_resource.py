#!/usr/bin/env python3
"""Package completed fixed relation measurements using an explicit allowlist."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[6]
G = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/issue_lineage_generation'
SOURCE, OUT = G / 'codex_relation_comparison', G / 'codex_relation_resource_completed'
PACKET = G.parent / 'relation_annotation/issue_lineage_development/annotation_packet'
SCRIPT = Path(__file__).parent


def digest(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def main():
    accounting = json.loads((SOURCE / 'assessment/first_label_accounting.json').read_text())
    if accounting['controlled_answers_read'] != 43 or accounting['returned_first_ai_judgments'] != 13:
        raise ValueError('Completed bounded measurements required')
    OUT.mkdir()
    folder = OUT / 'bundle'
    folder.mkdir()
    (folder / 'objects').mkdir()
    (folder / 'comparison').mkdir()
    (folder / 'producers').mkdir()
    mapping = {}

    def add(path, destination=None, binding=None):
        path = path if path.is_absolute() else ROOT / path
        raw = path.read_bytes()
        observed = digest(raw)
        if binding and (observed['sha256'] != binding['sha256']
                        or ('bytes' in binding and observed['bytes'] != binding['bytes'])):
            raise ValueError('Frozen binding changed: ' + str(path))
        key = str(path.relative_to(ROOT))
        name = destination or 'objects/' + observed['sha256'] + '.bin'
        target = folder / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(raw)
        elif target.read_bytes() != raw:
            raise ValueError('Destination collision')
        mapping[key] = name
        return {'path': key, **observed}

    names = ['plan.json', 'preflight.json', 'answer_plan.json', 'answer_input_verification.json',
             'assessment_protocol.json', 'completed_answer_accounting.json', 'hint_field_differences.json',
             'direct_policy.txt', 'extract_policy.txt', 'comparison_policy.txt']
    directories = ['inputs', 'extraction', 'continuation', 'answers', 'answer_recovery',
                   'answer_interruption', 'assessment', 'author_readback']
    for name in names:
        add(SOURCE / name, 'comparison/' + name)
    for directory in directories:
        for path in sorted((SOURCE / directory).rglob('*')):
            if path.is_file() and path.suffix in {'.json', '.txt', '.py'}:
                add(path, 'comparison/' + str(path.relative_to(SOURCE)))
    plan = json.loads((SOURCE / 'plan.json').read_text())
    add(ROOT / plan['bundle']['path'], binding=plan['bundle'])
    for item in plan['inputs']:
        for key in ('source_input', 'direct_input', 'extraction_input'):
            add(ROOT / item[key]['path'], binding=item[key])
    # Only the selected RAN4 source family; no protected CR-email families or
    # SA/CT corpus trees are traversed. Model binaries and credentials excluded.
    bundle = json.loads((ROOT / plan['bundle']['path']).read_text())
    source_ids = {o['source_id'] for item in bundle['inputs']
                  for group in item['groups'] for o in group['occurrences']}
    source_rows = {r['id']: r for r in json.loads((PACKET / 'sources.json').read_text())}
    messages = []
    for sid in sorted(source_ids):
        if sid == 'R4-2207053':
            continue
        if not (sid.startswith('M') and sid[1:].isdigit()):
            raise ValueError('Unselected source family')
        row = source_rows[sid]
        packet = add(PACKET / row['file'], binding={'sha256': row['sha256']})
        original = add(ROOT / row['original_source']['path'], binding=row['original_source'])
        messages.append({'id': sid, 'packet': packet, 'original': original})
    native = {'messages': messages,
              'formal_docx': add(PACKET / 'sources/R4-2207053.docx'),
              'formal_projection': add(PACKET / 'sources/R4-2207053.paragraphs.json')}
    producers = ['resolve_issue_relations.py', 'compare_issue_relation_answers.py',
                 'run_issue_lineage_generation.py', 'run_codex_relation_comparison.py',
                 'continue_codex_relation_comparison.py', 'continue_codex_relation_answers.py',
                 'assess_codex_relation_comparison.py', 'analyze_completed_codex_relation_answers.py',
                 'inspect_codex_relation_judgment_items.py', 'summarize_codex_relation_judgments.py',
                 'guard_codex_measurement.py', 'guard_codex_thread_headroom.py',
                 'prepare_codex_relation_resource.py', 'verify_codex_relation_resource.py']
    for name in producers:
        add(SCRIPT / name, 'producers/' + name)
    for key in ('source_protocol', 'development_reference', 'development_reference_audit'):
        protocol = json.loads((SOURCE / 'assessment_protocol.json').read_text())
        bound = protocol.get(key)
        if isinstance(bound, dict) and 'path' in bound and 'sha256' in bound:
            add(ROOT / bound['path'], binding=bound)
    add(SCRIPT / 'verify_codex_relation_resource.py', 'verify.py')
    readme = '''# Fixed relation tracing: controlled Codex development measurements

Four conditions share the same fourteen questions and selected RAN4 source
excerpts. Direct answering has no extraction; the other conditions share one
fallible extraction and differ only in omitted, first-target or all-target
finite relation hints. Thirty-five requested facets were fixed before answers.
This is one previously exposed source component, not independent semantic gold.

Run `python3 -B verify.py .` after unpacking. Standard-library replay checks
the selected email bodies against native JSON, Word paragraph/deleted channels
and physical table positions against native DOCX, fixed source/input identity,
unchanged finite resolver outputs, original candidate texts and literal judgment
anchors. Resolver ROOT/BASE location assignments are supplied by an explicit
AST adapter; original algorithm functions and source bytes remain unchanged.
This invokes no model, network, training or local model server. It does not
certify the meaning of an anchor, quoted speaker, rendered document or decision.

Thirteen extractions returned: ten decoded, three failed literal binding and
one was resource-interrupted. Forty-three of forty-four planned answer calls
returned; LQ06 direct was unavailable after a recorded thread-startup error.
No interrupted call was retried. Only previously unattempted suffix calls ran
under separately frozen continuation plans. The resource preserves original
failures and the fourteen-question denominator. Heavy local inference is absent.
CLI calls used the configured gpt-6.1-sol family/medium and existing ChatGPT
authentication with tools disabled. Exact model weights and provider sampling
defaults are uncontrolled; no credentials or model binaries are distributed.

All thirteen admitted first source-only AI judgments returned. The unchanged
whole-judgment literal check accepts four and rejects nine for empty anchors;
the separate item diagnostic finds 261 items, 425 literal anchor bindings and
44 empty-anchor violations. Invalid judgments' raw labels are not accepted
accuracy scores. Author readback covers all 43 answers and the substantive
judgment fields with bounded source inspection, not fresh exhaustive reading
of every selected group or human/independent gold. Principal requested
distinctions are preserved in direct answers; no general coverage advantage
is established. Complete source-bound uncertainty does not recover omitted
requested source text. Qualifications for LQ04 and LQ12 are retained.

First/all-target compact hints are identical on five decoded questions, differ
in proposition/condition or attachment invariance on four, and differ only in
reason categories on one. This computational difference is not an answer gain.
For the same ten paired questions, direct answering used 187381 input tokens,
9659 output tokens and 347.278 summed call seconds; all-target answering with
one shared extraction pass used 419419/45383 tokens and 1479.780 seconds.
These are measured calls, not an equal-compute or efficiency claim. Usage for
interrupted calls is unobserved rather than zero. All first outputs are retained.

Sources are the selected public RAN4 reflector record family and formal record
R4-2207053 with source identities, archive URLs and original hashes. No SA/CT
trees or the 87 protected CR-email body families were opened or included.
Only explicitly selected native source files are included. Public preparation,
upload and anonymous replay remain separate states; this local bundle claims
no DOI, independent external user, human labels or conference acceptance.

Participant commitments build on Lascarides & Asher, Agreement, Disputes and
Commitments in Dialogue (https://aclanthology.org/W08-0104.pdf). Alternative
contexts build on Reiter & de Kleer, Foundations of Assumption-Based Truth
Maintenance Systems (https://cdn.aaai.org/AAAI/1987/AAAI87-033.pdf). Cross-record
edit alignment is related to ARIES (https://aclanthology.org/2024.acl-long.377.pdf).
These foundations remain their authors' contributions; finite alternative
enumeration and literal checking are not claimed as new algorithms.
'''
    (folder / 'README.md').write_text(readme)
    files = {str(p.relative_to(folder)): digest(p.read_bytes()) for p in folder.rglob('*') if p.is_file()}
    manifest = {'kind': 'codex_fixed_relation_development_replay', 'created_utc': datetime.now(timezone.utc).isoformat(),
                'files': files, 'source_path_objects': mapping, 'native_source_bindings': native,
                'selected_source_ids': sorted(source_ids), 'human_labels': 0, 'independent_semantic_gold': 0,
                'excluded': ['model/CLI binaries', 'credentials', 'unselected corpus trees',
                             'protected CR-email bodies', 'unrelated root status snapshots']}
    (folder / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n')
    check = subprocess.run([sys.executable, '-B', str(folder / 'verify.py'), str(folder)], capture_output=True, text=True)
    (OUT / 'local_replay.stdout.txt').write_text(check.stdout)
    (OUT / 'local_replay.stderr.txt').write_text(check.stderr)
    if check.returncode:
        raise ValueError('Offline replay failed; preserve preparation and inspect saved error')
    archive = OUT / 'codex_relation_development.tar.gz'
    with tarfile.open(archive, 'x:gz') as tar:
        for path in sorted(folder.rglob('*')):
            if path.is_file():
                tar.add(path, arcname=str(path.relative_to(folder)), recursive=False)
    (OUT / 'README.md').write_text(readme)
    resource = {'state': 'LOCALLY_PREPARED_AND_REPLAYED', 'archive': digest(archive.read_bytes()),
                'replay': json.loads(check.stdout), 'file_count': len(files) + 1,
                'public_upload': False, 'human_labels': 0, 'independent_semantic_gold': 0}
    (OUT / 'resource.json').write_text(json.dumps(resource, ensure_ascii=False, indent=2) + '\n')
    names = ['README.md', 'resource.json', archive.name]
    (OUT / 'checksums.sha256').write_text(''.join(digest((OUT / name).read_bytes())['sha256'] + '  ' + name + '\n' for name in names))
    print(json.dumps(resource, ensure_ascii=False))


if __name__ == '__main__':
    main()
