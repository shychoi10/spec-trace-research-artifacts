#!/usr/bin/env python3
"""Offline replay of selected native sources, fixed inputs and finite relations.

Model outputs and invalid first judgments are preserved, never repaired or
rescored. The original resolver functions run over their original hypotheses.
"""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys
import xml.etree.ElementTree as ET
from zipfile import ZipFile


def digest(raw):
    return {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify(folder):
    manifest = json.loads((folder / 'manifest.json').read_text())
    require(manifest['kind'] == 'codex_fixed_relation_development_replay', 'Wrong resource')
    actual = {str(p.relative_to(folder)) for p in folder.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts}
    require(actual == set(manifest['files']) | {'manifest.json'}, 'File membership differs')
    for name, bound in manifest['files'].items():
        path = PurePosixPath(name)
        require(not path.is_absolute() and '..' not in path.parts
                and not (folder / name).is_symlink(), 'Unsafe path')
        require(digest((folder / name).read_bytes()) == bound, 'File changed: ' + name)

    def read(bound):
        raw = (folder / manifest['source_path_objects'][bound['path']]).read_bytes()
        observed = digest(raw)
        require(observed['sha256'] == bound['sha256']
                and ('bytes' not in bound or observed['bytes'] == bound['bytes']), 'Binding differs')
        return raw

    def load(bound):
        return json.loads(read(bound))

    def artifact(name):
        return json.loads((folder / 'comparison' / name).read_text())

    # Location assignments are omitted in the adapter; algorithm/function ASTs
    # are unchanged. No model launcher or network function is invoked.
    source = (folder / 'producers/resolve_issue_relations.py').read_text()
    tree = ast.parse(source)
    tree.body = [node for node in tree.body if not (
        isinstance(node, ast.Assign) and any(isinstance(t, ast.Name)
        and t.id in {'ROOT', 'BASE'} for t in node.targets))]
    resolver = {'__name__': 'offline_original_resolver', '__file__': str(folder / 'producers/resolve_issue_relations.py'),
                'ROOT': folder, 'BASE': folder}
    exec(compile(tree, '<bound-original-resolver>', 'exec'), resolver)
    compare_tree = ast.parse((folder / 'producers/compare_issue_relation_answers.py').read_text())
    compact_node = next(n for n in compare_tree.body if isinstance(n, ast.FunctionDef)
                        and n.name == 'compact_resolution')
    compact = {}
    exec(compile(ast.Module(body=[compact_node], type_ignores=[]), '<bound-original-compact>', 'exec'), compact)

    plan, answers, judges = artifact('plan.json'), artifact('answer_plan.json'), artifact('assessment/plan.json')
    bundle = load(plan['bundle'])
    groups_by_id = {q['id']: q for q in bundle['inputs']}
    native = manifest['native_source_bindings']
    paragraphs = load(native['formal_projection'])['paragraphs']
    with ZipFile(folder / manifest['source_path_objects'][native['formal_docx']['path']]) as archive:
        tree = ET.fromstring(archive.read('word/document.xml'))
    w = '{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    parents = {c: p for p in tree.iter() for c in p}
    tables = {t: i for i, t in enumerate(tree.iter(w + 'tbl'))}
    projected = []
    for index, paragraph in enumerate(tree.iter(w + 'p')):
        node, ancestors = paragraph, []
        while node in parents:
            node = parents[node]
            ancestors.append(node)
        cell = next((p for p in ancestors if p.tag == w + 'tc'), None)
        row = next((p for p in ancestors if p.tag == w + 'tr'), None)
        table = next((p for p in ancestors if p.tag == w + 'tbl'), None)
        location = None if table is None else {'table_index': tables[table],
                   'row_index': list(table.findall(w + 'tr')).index(row),
                   'cell_index': list(row.findall(w + 'tc')).index(cell)}
        style = paragraph.find(w + 'pPr/' + w + 'pStyle')
        projected.append({'paragraph_index': index,
                          'text': ''.join(t.text or '' for t in paragraph.iter(w + 't')),
                          'deleted_text': ''.join(t.text or '' for t in paragraph.iter(w + 'delText')),
                          'style_id': style.get(w + 'val') if style is not None else None,
                          'nearest_table_cell': location})
    require(projected == paragraphs, 'Native Word text/channel/position projection differs')
    messages = {entry['id']: load(entry['packet']) for entry in native['messages']}
    for entry in native['messages']:
        original, packet = load(entry['original']), messages[entry['id']]
        require(original['body_plain'] == packet['body_plain'], 'Native email body differs')
        require(original['sender_raw'] == packet['sender_raw']
                and original['date_str'] == packet['date_raw'], 'Email metadata differs')

    source_parts, group_count = 0, 0
    for row in plan['inputs']:
        item = groups_by_id[row['id']]
        original = load(row['source_input'])
        require(resolver['excerpts'](original) == item['groups'], 'Original selected groups differ')
        question = {k: v for k, v in original['question'].items() if k != 'source_family'}
        require(question == item['question'], 'Question differs')
        payload = 'QUESTION:\n' + resolver['canonical'](question) + '\nSOURCE EXCERPTS:\n' + '\n'.join(
            resolver['canonical'](g) for g in item['groups'])
        require(read(row['extraction_input']).decode() == payload
                and read(row['direct_input']).decode() == payload, 'Direct/extraction information differs')
        for group in item['groups']:
            group_count += 1
            for occurrence in group['occurrences']:
                require(len(occurrence['positions']) == len(group['source_text']), 'Source positions differ')
                for part, position in zip(group['source_text'], occurrence['positions']):
                    sid = occurrence['source_id']
                    if sid.startswith('M'):
                        observed = messages[sid]['body_plain'][position['start']:position['end']]
                        require(part['channel'] == 'body_plain', 'Email channel differs')
                    else:
                        p = paragraphs[position['paragraph_index']]
                        observed = p[position['channel']]
                        require(p['nearest_table_cell'] == position['cell'], 'Formal table position differs')
                    require(observed == part['text'] and position['channel'] == part['channel'], 'Native selected part differs')
                    source_parts += 1

    decoded_count, invalid_count = 0, 0
    for row in answers['questions']:
        item = groups_by_id[row['id']]
        if row['extraction'] is None:
            require(row['id'] == 'LQ09', 'Unexpected absent extraction')
            continue
        decoded = load(row['extraction'])
        if decoded['status'] == 'resource_interrupted':
            require(row['id'] == 'LQ09' and row['shared_extraction_failure'],
                    'Unexpected interrupted extraction')
            continue
        graph = load(decoded['answer'])
        try:
            events = resolver['validate'](graph, item['groups'])
        except (ValueError, KeyError, TypeError, AttributeError):
            require(decoded['status'] == 'invalid_extraction', 'Unexpected extraction rejection')
            invalid_count += 1
            continue
        require(decoded['status'] == 'decoded', 'Extraction acceptance differs')
        decoded_count += 1
        for mode, key in [('first', 'first'), ('all', 'all')]:
            require(resolver['resolve'](events, mode) == decoded[key], 'Finite resolver output differs')
        common = 'QUESTION:\n' + resolver['canonical'](item['question']) + '\nSOURCE EXCERPTS:\n' + '\n'.join(
            resolver['canonical'](g) for g in item['groups']) + '\nAUTOMATIC EXTRACTION:\n' + resolver['canonical'](graph)
        for mode in ['extraction_only', 'first_target', 'all_targets']:
            hint = None if mode == 'extraction_only' else compact['compact_resolution'](decoded['first' if mode == 'first_target' else 'all'])
            expected = common + '\nOPTIONAL RESOLUTION HINTS:\n' + resolver['canonical'](hint)
            require(read(row['conditions'][mode]['input']).decode() == expected, 'Condition payload differs')
    require(decoded_count == 10 and invalid_count == 3, 'Extraction denominator differs')

    collection = artifact('answer_recovery/collection_summary.json')
    require(collection['returned_controlled_calls'] == 43
            and collection['originally_planned_calls'] == 44, 'Answer denominator differs')
    by_call = {}
    for row in collection['results']:
        result = load(row['result'])
        require(result['state'] == 'SAVED_CONTROLLED_ANSWER', 'Uncontrolled candidate')
        raw = read(result['answer']).decode()
        by_call[(row['id'], row['mode'])] = raw
    item_count, anchors, violations = 0, 0, Counter()
    for row in judges['questions']:
        if not row['admitted_judgment']:
            require(row['id'] == 'LQ06', 'Unexpected unavailable judge')
            continue
        packet = load(row['input'])
        require(packet['question'] == groups_by_id[row['id']]['question']
                and packet['selected_source_groups'] == groups_by_id[row['id']]['groups'], 'Judge source differs')
        candidates = {c['label']: c['answer'] for c in packet['candidate_answers']}
        for label, mode in row['label_to_mode'].items():
            require(candidates[label] == by_call[row['id'], mode], 'Judge candidate text differs')
        raw = artifact('assessment/run/' + row['id'] + '/answer.txt')
        by_chunk = {g['chunk_id']: g for g in packet['selected_source_groups']}
        for candidate in raw['candidates']:
            for kind in ('facets', 'added_claims'):
                for item in candidate[kind]:
                    item_count += 1
                    quote = item['answer_quote']
                    if quote is not None:
                        require(quote and quote in candidates[candidate['label']], 'Judge answer quote differs')
                    if item['support'] in {'supported', 'contradicted'} and not item['source_anchors']:
                        violations['source_support_or_contradiction_without_anchor'] += 1
                    for anchor in item['source_anchors']:
                        resolver['bind_anchor'](anchor, by_chunk)
                        anchors += 1
    checks = Counter(artifact('assessment/run/' + q['id'] + '/literal_check.json')['state']
                     for q in judges['questions'] if q['admitted_judgment'])
    require(item_count == 261 and anchors == 425 and sum(violations.values()) == 44,
            'First item diagnostic differs')
    return {'state': 'SELECTED_NATIVE_INPUT_AND_FINITE_RELATION_REPLAY_PASS',
            'files': len(actual), 'questions': 14, 'requested_facets': 35,
            'selected_group_appearances': group_count, 'native_part_appearances': source_parts,
            'native_email_sources': len(messages), 'native_word_paragraphs': len(paragraphs),
            'decoded_extractions': decoded_count, 'invalid_extractions': invalid_count,
            'interrupted_extractions': 1, 'controlled_answers': len(by_call),
            'returned_first_judgments': 13, 'original_literal_states': dict(checks),
            'judgment_items': item_count, 'literal_source_anchor_bindings': anchors,
            'original_empty_anchor_violations': sum(violations.values()),
            'model_calls': 0, 'original_acceptance_rule_changed': False,
            'semantic_accuracy_certified': False, 'human_labels': 0, 'independent_semantic_gold': 0,
            'limit': 'Literal source/input replay and unchanged finite computations; no model rerun, repaired scores, independent semantics, document rendering or quoted-speaker certification.'}


if __name__ == '__main__':
    print(json.dumps(verify(Path(sys.argv[1]).resolve()), ensure_ascii=False, indent=2))
