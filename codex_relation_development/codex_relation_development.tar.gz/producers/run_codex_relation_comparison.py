#!/usr/bin/env python3
"""Measure the fixed relation workload with controlled Codex calls.

The unchanged extraction contract and deterministic decoders are experimental
components. Validated anchors do not certify semantic interpretation. Original
local-model failures remain separate from this declared backend change.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time

import compare_issue_relation_answers as comparison
import continue_codex_standards_control as collector
import resolve_issue_relations as resolver
import run_issue_lineage_generation as legacy

ROOT = resolver.ROOT
BASE = resolver.BASE
OUT = BASE / 'codex_relation_comparison'
CONFIG_SOURCE = ROOT / 'logs/publication/paper/ongoing/kdd-2027-research/experiments/relation_annotation/standards_changes/development/ran3_scope_comparison/plan.json'
MODES = ('direct', 'extraction_only', 'first_target', 'all_targets')


def now():
    return datetime.now(timezone.utc).isoformat()


def bind(path):
    raw = path.read_bytes()
    locator = str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path)
    return {'path': locator, 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def verify(binding):
    path = ROOT / binding['path']
    if bind(path) != binding:
        raise ValueError('Bound artifact changed: ' + binding['path'])
    return path


def read(path):
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def text_new(path, value):
    with path.open('x') as stream:
        stream.write(value)


def guarded():
    if sorted(os.sched_getaffinity(0)) != [0, 1] or os.getpriority(os.PRIO_PROCESS, 0) != 19:
        raise ValueError('CPU affinity and nice resource guard required')


def prepare():
    frozen = resolver.require_completed_control()
    bundle_path = BASE / 'relation_candidate_inputs.json'
    bundle = read(bundle_path)
    if bundle['frozen_inputs_sha256'] != resolver.digest(BASE / 'frozen_inputs.json'):
        raise ValueError('Original source manifest changed')
    if bundle['system'] != resolver.EXTRACTION_SYSTEM:
        raise ValueError('Extraction instruction differs from preserved contract')
    if [i['id'] for i in bundle['inputs']] != [i['id'] for i in frozen['inputs']]:
        raise ValueError('Question set changed')
    originals = []
    for old, item in zip(frozen['inputs'], bundle['inputs']):
        original = BASE / old['path']
        if resolver.digest(original) != old['sha256'] or item['source_input_sha256'] != old['sha256']:
            raise ValueError('Original input changed')
        inp = read(original)
        question = {k: v for k, v in inp['question'].items() if k != 'source_family'}
        if item['question'] != question or item['groups'] != resolver.excerpts(inp):
            raise ValueError('Selected question or source groups changed')
        originals.append(bind(original))
    binary = Path.home() / '.local/bin/codex'
    auth = subprocess.run([str(binary), 'login', 'status'], capture_output=True, text=True, timeout=30)
    if auth.returncode or 'ChatGPT' not in auth.stdout + auth.stderr:
        raise ValueError('Existing ChatGPT authentication unavailable')
    OUT.mkdir()
    inputs = OUT / 'inputs'
    inputs.mkdir()
    policies = {}
    for name, policy in [('extract', resolver.EXTRACTION_SYSTEM), ('direct', legacy.SYSTEM),
                         ('comparison', comparison.SYSTEM_COMMON)]:
        path = OUT / (name + '_policy.txt')
        text_new(path, policy)
        policies[name] = bind(path)
    prepared = []
    for item, original in zip(bundle['inputs'], originals):
        qid = item['id']
        content = 'QUESTION:\n' + resolver.canonical(item['question']) + '\nSOURCE EXCERPTS:\n' + '\n'.join(resolver.canonical(g) for g in item['groups'])
        extract_path = inputs / (qid + '.extract.txt')
        direct_path = inputs / (qid + '.direct.txt')
        text_new(extract_path, content)
        text_new(direct_path, content)
        prepared.append({'id': qid, 'source_input': original, 'extraction_input': bind(extract_path),
                         'direct_input': bind(direct_path), 'selected_groups': len(item['groups'])})
    # Carry the already inspected closed-tool configuration, not prior answers.
    config = [x for x in read(CONFIG_SOURCE)['config_overrides'] if not x.startswith('model_instructions_file=')]
    sources = [bundle_path, BASE / 'frozen_inputs.json', BASE / 'completion.json', BASE / 'source_units.json',
               CONFIG_SOURCE, Path(__file__).resolve(), Path(resolver.__file__), Path(comparison.__file__),
               Path(legacy.__file__), Path(collector.__file__), Path(collector.control.__file__)]
    plan = {'created_utc': now(), 'state': 'FIXED_INPUTS_PREPARED_NO_NEW_MODEL_CALLS',
            'sources': [bind(p) for p in sources], 'bundle': bind(bundle_path), 'policies': policies,
            'cli_binary': bind(binary), 'cli_version': subprocess.check_output([str(binary), '--version'], text=True).strip(),
            'declared_model': 'gpt-6.1-sol', 'reasoning_effort': 'medium', 'config_overrides': config,
            'authentication': 'existing_chatgpt_login', 'inputs': prepared, 'modes': list(MODES),
            'per_turn_wall_limit_seconds': 900, 'automatic_retries': 0,
            'source_components': 1, 'development_exposure': True, 'human_labels': 0,
            'independent_semantic_gold': 0, 'protected_email_body_families_used': 0,
            'contract': 'Exactly the fourteen preserved questions and selected source groups. One extraction per question supplies every decoder. No extraction/reference/previous answer is supplied to direct answering.',
            'ordering': 'All extractions once; freeze all admitted answer inputs; rotate four answer conditions by fixed question index. Invalid extraction skips its three dependent conditions and remains in the fourteen-question denominator.',
            'failure_policy': 'Save invalid JSON/anchors without repair or resampling; continue the remaining fixed extraction questions. Stop all subsequent dispatch after an incomplete or uncontrolled CLI turn.',
            'cost': 'Extraction adds one model pass. All token counts and elapsed times are retained; comparisons with direct answering are not compute matched.',
            'sampling': 'Provider defaults; seed, temperature and output cap uncontrolled.',
            'novelty': 'Uses existing attribution, assumption tracking and the preserved experimental decoders; backend execution is not a new algorithm.',
            'previous_goal_turn': 'PROGRESS: completed RAN3 source readback, public replay and actual eight-page-body manuscript integration.'}
    save(OUT / 'plan.json', plan)
    print(json.dumps({'state': plan['state'], 'questions': len(prepared), 'selected_group_occurrences': sum(x['selected_groups'] for x in prepared), 'plan': bind(OUT / 'plan.json')}), flush=True)


def verified_plan():
    plan = read(OUT / 'plan.json')
    for binding in plan['sources'] + list(plan['policies'].values()) + [plan['cli_binary']]:
        verify(binding)
    for item in plan['inputs']:
        for name in ('source_input', 'extraction_input', 'direct_input'):
            verify(item[name])
    return plan


def turn(plan, destination, binding, policy_name):
    destination.mkdir()
    work = Path(tempfile.mkdtemp(prefix='spectra-kdd-relations-'))
    argv = [str(verify(plan['cli_binary'])), 'exec', '--ignore-user-config', '--ignore-rules', '--strict-config',
            '--ephemeral', '--skip-git-repo-check', '--sandbox', 'read-only', '--cd', str(work), '--json',
            '--color', 'never', '--output-last-message', str(destination / 'answer.txt')]
    overrides = plan['config_overrides'] + ['model_instructions_file=' + json.dumps(str(verify(plan['policies'][policy_name])))]
    for value in overrides:
        argv += ['-c', value]
    argv.append('-')
    save(destination / 'dispatch.json', {'started_utc': now(), 'input': binding,
         'policy': plan['policies'][policy_name], 'argv': argv, 'empty_cwd_at_dispatch': not any(work.iterdir())})
    print(json.dumps({'state': 'DISPATCHED', 'call': str(destination.relative_to(OUT))}), flush=True)
    start, timed_out = time.monotonic(), False
    with verify(binding).open('rb') as stdin, (destination / 'events.jsonl').open('xb') as stdout, (destination / 'stderr.txt').open('xb') as stderr:
        child = subprocess.Popen(argv, stdin=stdin, stdout=stdout, stderr=stderr)
        try:
            code = child.wait(timeout=plan['per_turn_wall_limit_seconds'])
        except subprocess.TimeoutExpired:
            timed_out = True
            child.terminate()
            try:
                code = child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                child.kill()
                code = child.wait(timeout=10)
    audit = collector.inspect_events(destination / 'events.jsonl')
    answer = destination / 'answer.txt'
    clean = code == 0 and not timed_out and not audit['errors'] and not audit['unexpected_tool_or_item_events'] and len(audit['turn_completed_events']) == 1 and answer.exists() and answer.stat().st_size > 0
    result = {'finished_utc': now(), 'elapsed_seconds': time.monotonic() - start, 'returncode': code,
              'timed_out': timed_out, **audit, 'answer': bind(answer) if answer.exists() else None,
              'events': bind(destination / 'events.jsonl'), 'stderr': bind(destination / 'stderr.txt'),
              'state': 'SAVED_CONTROLLED_ANSWER' if clean else 'FAILED_OR_UNCONTROLLED_TURN'}
    save(destination / 'result.json', result)
    print(json.dumps({'state': result['state'], 'call': str(destination.relative_to(OUT)), 'elapsed_seconds': result['elapsed_seconds']}), flush=True)
    if not clean:
        raise RuntimeError('CLI turn incomplete/uncontrolled; no retry or subsequent dispatch')
    return answer


def extract():
    guarded()
    plan = verified_plan()
    items = read(verify(plan['bundle']))['inputs']
    output = OUT / 'extraction'
    output.mkdir()
    rows, failure = [], None
    try:
        for prepared, item in zip(plan['inputs'], items):
            destination = output / item['id']
            answer = turn(plan, destination, prepared['extraction_input'], 'extract')
            result = {'id': item['id'], 'answer': bind(answer), 'call': bind(destination / 'result.json')}
            try:
                graph = read(answer)
                if not isinstance(graph.get('unestablished'), list) or any(not isinstance(v, str) for v in graph['unestablished']):
                    raise ValueError('Invalid unestablished list')
                events = resolver.validate(graph, item['groups'])
                result.update({'status': 'decoded', 'event_count': len(events), 'empty_graph': not events,
                               'first': resolver.resolve(events, 'first'), 'all': resolver.resolve(events, 'all')})
            except (ValueError, KeyError, TypeError, AttributeError) as error:
                result.update({'status': 'invalid_extraction', 'error': repr(error)})
            save(destination / 'decoded.json', result)
            rows.append(bind(destination / 'decoded.json'))
            print(json.dumps({'id': item['id'], 'status': result['status'], 'event_count': result.get('event_count')}), flush=True)
    except Exception as error:
        failure = repr(error)
    summary = {'finished_utc': now(), 'plan': bind(OUT / 'plan.json'), 'rows': rows, 'failure': failure,
               'state': 'EXTRACTION_PASS_FINISHED' if failure is None else 'STOPPED_INCOMPLETE_OR_UNCONTROLLED',
               'processed_questions': len(rows), 'total_questions': len(plan['inputs']),
               'human_labels': 0, 'independent_semantic_gold': 0, 'model_retries': 0}
    save(output / 'summary.json', summary)
    if failure is not None:
        raise RuntimeError(failure)


def prepare_answers():
    plan = verified_plan()
    summary = read(OUT / 'extraction/summary.json')
    if summary['failure'] or summary['processed_questions'] != len(plan['inputs']):
        raise ValueError('Incomplete extraction pass')
    items = read(verify(plan['bundle']))['inputs']
    output = OUT / 'answer_inputs'
    output.mkdir()
    rows = []
    for index, (prepared, item) in enumerate(zip(plan['inputs'], items)):
        check_path = OUT / 'extraction' / item['id'] / 'decoded.json'
        check = read(check_path)
        if bind(check_path) != summary['rows'][index]:
            raise ValueError('Extraction check changed')
        verify(check['call'])
        answer_path = verify(check['answer'])
        conditions = {'direct': {'input': prepared['direct_input'], 'policy': 'direct'}}
        if check['status'] == 'decoded':
            messages = comparison.comparison_messages(item['question'], item['groups'], read(answer_path))
            for mode, pair in messages.items():
                if pair[0]['content'] != verify(plan['policies']['comparison']).read_text():
                    raise ValueError('Comparison policy changed')
                path = output / (item['id'] + '.' + mode + '.txt')
                text_new(path, pair[1]['content'])
                conditions[mode] = {'input': bind(path), 'policy': 'comparison'}
        order = list(MODES[index % len(MODES):] + MODES[:index % len(MODES)])
        rows.append({'id': item['id'], 'extraction': bind(check_path), 'conditions': conditions,
                     'execution_order': [mode for mode in order if mode in conditions],
                     'shared_extraction_failure': check['status'] != 'decoded'})
    answer_plan = {'created_utc': now(), 'plan': bind(OUT / 'plan.json'), 'extraction_summary': bind(OUT / 'extraction/summary.json'),
                   'questions': rows, 'denominator': 'All fourteen questions; invalid extraction retains the three skipped downstream conditions.',
                   'semantic_accuracy': 'NOT_YET_EVALUATED', 'automatic_retries': 0}
    save(OUT / 'answer_plan.json', answer_plan)
    print(json.dumps({'state': 'ANSWER_INPUTS_FROZEN', 'questions': len(rows), 'planned_calls': sum(len(r['conditions']) for r in rows)}), flush=True)


def answer():
    guarded()
    plan = verified_plan()
    answer_plan = read(OUT / 'answer_plan.json')
    verify(answer_plan['plan'])
    verify(answer_plan['extraction_summary'])
    for row in answer_plan['questions']:
        verify(row['extraction'])
        for condition in row['conditions'].values():
            verify(condition['input'])
    output = OUT / 'answers'
    output.mkdir()
    units = read(BASE / 'source_units.json')
    originals = {p['id']: read(verify(p['source_input'])) for p in plan['inputs']}
    results, failure = [], None
    try:
        for row in answer_plan['questions']:
            qout = output / row['id']
            qout.mkdir()
            for mode in row['execution_order']:
                condition = row['conditions'][mode]
                destination = qout / mode
                path = turn(plan, destination, condition['input'], condition['policy'])
                try:
                    audit = legacy.verify_answer(read(path), originals[row['id']], units)
                except (ValueError, KeyError, TypeError, AttributeError) as error:
                    audit = {'structural_errors': [repr(error)], 'literal_bindings': [], 'semantic_correctness': 'NOT_EVALUATED'}
                save(destination / 'literal_check.json', audit)
                results.append({'id': row['id'], 'mode': mode, 'result': bind(destination / 'result.json'),
                                'literal_check': bind(destination / 'literal_check.json')})
    except Exception as error:
        failure = repr(error)
    save(output / 'summary.json', {'finished_utc': now(), 'answer_plan': bind(OUT / 'answer_plan.json'),
         'state': 'ADMITTED_ANSWER_CALLS_FINISHED' if failure is None else 'STOPPED_INCOMPLETE_OR_UNCONTROLLED',
         'results': results, 'failure': failure, 'human_labels': 0, 'independent_semantic_gold': 0, 'model_retries': 0})
    if failure is not None:
        raise RuntimeError(failure)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'extract', 'prepare-answers', 'answer'])
    mode = parser.parse_args().mode
    {'prepare': prepare, 'extract': extract, 'prepare-answers': prepare_answers, 'answer': answer}[mode]()
