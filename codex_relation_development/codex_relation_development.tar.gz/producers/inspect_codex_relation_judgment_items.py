#!/usr/bin/env python3
"""Inspect each saved judgment item without changing the frozen acceptance rule.

The original validator stops at its first violation. This diagnostic enumerates
literal failures in already returned items; it neither repairs them nor awards
semantic credit to an invalid judgment.
"""
import argparse
from pathlib import Path

import assess_codex_relation_comparison as assessment
import run_codex_relation_comparison as experiment


def inspect(output):
    experiment.guarded()
    _, plan = assessment.checked_plan()
    rows = []
    for row in plan['questions']:
        folder = assessment.REVIEW / 'run' / row['id']
        result_path = folder / 'result.json'
        check_path = folder / 'literal_check.json'
        if not result_path.exists() or not check_path.exists():
            continue
        result = experiment.read(result_path)
        if result['state'] != 'SAVED_CONTROLLED_ANSWER':
            continue
        raw = experiment.read(experiment.verify(result['answer']))
        packet = experiment.read(experiment.verify(row['input']))
        answers = {c['label']: c['answer'] for c in packet['candidate_answers']}
        groups = {g['chunk_id']: g for g in packet['selected_source_groups']}
        items = []
        for candidate in raw['candidates']:
            for kind in ('facets', 'added_claims'):
                for index, item in enumerate(candidate[kind]):
                    failures, anchors = [], []
                    quote = item['answer_quote']
                    if quote is not None and (not isinstance(quote, str) or not quote
                                               or quote not in answers[candidate['label']]):
                        failures.append('answer_quote_not_literal')
                    if item['support'] in ('supported', 'contradicted') and not item['source_anchors']:
                        failures.append('source_support_or_contradiction_without_anchor')
                    for anchor_index, anchor in enumerate(item['source_anchors']):
                        try:
                            bound = experiment.resolver.bind_anchor(anchor, groups)
                            anchors.append({'index': anchor_index, 'binding': bound})
                        except (ValueError, KeyError, TypeError, IndexError) as error:
                            failures.append({'source_anchor_index': anchor_index, 'error': repr(error)})
                    items.append({'label': candidate['label'], 'mode': row['label_to_mode'][candidate['label']],
                                  'kind': kind, 'index': index, 'facet_id': item.get('id'),
                                  'response': item.get('response'), 'raw_support': item['support'],
                                  'failures': failures, 'literal_anchor_bindings': anchors})
        rows.append({'id': row['id'], 'input': row['input'],
                     'result': experiment.bind(result_path), 'raw_judgment': result['answer'],
                     'original_literal_check': experiment.bind(check_path),
                     'original_literal_state': experiment.read(check_path)['state'], 'items': items})
    value = {'state': 'RETURNED_JUDGMENT_ITEM_LITERAL_DIAGNOSTIC', 'observed_utc': experiment.now(),
             'plan': experiment.bind(assessment.REVIEW / 'plan.json'),
             'producer': experiment.bind(Path(__file__).resolve()), 'questions': rows,
             'returned_judgments_inspected': len(rows),
             'original_acceptance_rule_or_artifacts_changed': False,
             'semantic_credit_awarded': False, 'semantic_accuracy_certified': False,
             'human_labels': 0, 'independent_semantic_gold': 0, 'new_model_calls': 0}
    experiment.save(output, value)
    print({'state': value['state'], 'returned_judgments': len(rows),
           'original_acceptance_rule_changed': False, 'semantic_credit_awarded': False})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    inspect(args.output)
