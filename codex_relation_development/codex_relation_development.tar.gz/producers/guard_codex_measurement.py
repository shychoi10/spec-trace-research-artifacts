#!/usr/bin/env python3
"""Use a persistent native Windows memory observer with the existing job guard.

Kernel limits and the host/WSL reserve policy remain unchanged. Missing host
visibility still stops the owned job. This avoids starting PowerShell and
querying CIM on every observation; it does not certify computer stability.
"""
import argparse
import base64
import hashlib
import json
import os
from pathlib import Path
import select
import subprocess
import sys
import time

import guard_local_inference as guard

POWERSHELL_SOURCE = r'''
$ErrorActionPreference = 'Stop'
Add-Type -TypeDefinition @'
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
public static class SpectraPhysicalMemory {
    [StructLayout(LayoutKind.Sequential)]
    public struct MemoryStatus {
        public uint Length;
        public uint Load;
        public ulong TotalPhysical;
        public ulong AvailablePhysical;
        public ulong TotalPageFile;
        public ulong AvailablePageFile;
        public ulong TotalVirtual;
        public ulong AvailableVirtual;
        public ulong AvailableExtendedVirtual;
    }
    [DllImport("kernel32.dll", SetLastError=true)]
    private static extern bool GlobalMemoryStatusEx(ref MemoryStatus status);
    public static MemoryStatus Read() {
        MemoryStatus status = new MemoryStatus();
        status.Length = (uint)Marshal.SizeOf(typeof(MemoryStatus));
        if (!GlobalMemoryStatusEx(ref status))
            throw new Win32Exception(Marshal.GetLastWin32Error());
        return status;
    }
}
'@
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
[Console]::WriteLine((@{state='ready'; windows_pid=$PID} | ConvertTo-Json -Compress))
while ($null -ne ($request = [Console]::ReadLine())) {
    if ($request -eq 'quit') { break }
    if ($request -notmatch '^[0-9]+$') { throw 'Invalid memory observation request' }
    $memory = [SpectraPhysicalMemory]::Read()
    [Console]::WriteLine((@{
        sequence=[int]$request;
        windows_pid=$PID;
        TotalVisibleMemorySize=$memory.TotalPhysical;
        FreePhysicalMemory=$memory.AvailablePhysical
    } | ConvertTo-Json -Compress))
}
'''


class HostObserver:
    def __init__(self, stderr_path):
        self.child = None
        self.stderr_path = stderr_path
        self.stderr = None
        self.buffer = b''
        self.sequence = 0
        self.windows_pid = None
        self.startup_seconds = None

    def line(self, timeout):
        deadline = time.monotonic() + timeout
        while b'\n' not in self.buffer:
            remaining = deadline - time.monotonic()
            if remaining <= 0 or not select.select([self.child.stdout], [], [], remaining)[0]:
                raise TimeoutError('Persistent host memory observation timed out')
            chunk = os.read(self.child.stdout.fileno(), 4096)
            if not chunk:
                raise RuntimeError('Persistent host memory observer closed its output')
            self.buffer += chunk
        raw, self.buffer = self.buffer.split(b'\n', 1)
        return json.loads(raw.decode('utf-8-sig'))

    def start(self):
        start = time.monotonic()
        encoded = base64.b64encode(POWERSHELL_SOURCE.encode('utf-16le')).decode()
        self.stderr = self.stderr_path.open('xb')
        self.child = subprocess.Popen([guard.POWERSHELL, '-NoProfile', '-NonInteractive',
                                       '-EncodedCommand', encoded], stdin=subprocess.PIPE,
                                      stdout=subprocess.PIPE, stderr=self.stderr)
        ready = self.line(30)
        if ready.get('state') != 'ready' or type(ready.get('windows_pid')) is not int:
            raise ValueError('Native host observer did not initialize')
        self.windows_pid = ready['windows_pid']
        self.startup_seconds = time.monotonic() - start

    def read(self):
        if self.child is None:
            self.start()
        start = time.monotonic()
        self.sequence += 1
        self.child.stdin.write((str(self.sequence) + '\n').encode())
        self.child.stdin.flush()
        value = self.line(10)
        if value.get('sequence') != self.sequence or value.get('windows_pid') != self.windows_pid:
            raise ValueError('Stale or unexpected host observer response')
        total, free = value['TotalVisibleMemorySize'], value['FreePhysicalMemory']
        if type(total) is not int or type(free) is not int or not 0 < free <= total:
            raise ValueError('Invalid native physical memory counters')
        return {'TotalVisibleMemorySize': total, 'FreePhysicalMemory': free,
                'observer_method': 'GlobalMemoryStatusEx', 'observer_windows_pid': self.windows_pid,
                'observer_sequence': self.sequence, 'observer_query_seconds': time.monotonic() - start,
                'observer_startup_seconds': self.startup_seconds}

    def close(self):
        if self.child is None:
            if self.stderr is not None:
                self.stderr.close()
            return
        try:
            self.child.stdin.write(b'quit\n')
            self.child.stdin.flush()
            self.child.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        try:
            self.child.wait(timeout=5)
        except subprocess.TimeoutExpired:
            self.child.terminate()
            try:
                self.child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.child.kill()
                self.child.wait(timeout=5)
        finally:
            self.child.stdout.close()
            self.stderr.close()


def probe(output):
    cgroup = guard.own_cgroup()
    limits = guard.verify_limits(cgroup, 2 * guard.GIB, guard.GIB)
    observer = HostObserver(output.with_suffix('.stderr.txt'))
    rows, error = [], None
    try:
        for _ in range(10):
            rows.append({'observed_utc': guard.now(), 'host_memory': observer.read(),
                         'linux_memory': guard.linux_memory(), 'cgroup_memory': guard.cgroup_memory(cgroup)})
            time.sleep(1)
    except Exception as caught:
        error = repr(caught)
    finally:
        observer.close()
    raw = Path(__file__).read_bytes()
    result = {'finished_utc': guard.now(), 'state': 'NATIVE_HOST_OBSERVER_PROBE_PASS' if error is None else 'PROBE_FAILED',
              'producer_sha256': hashlib.sha256(raw).hexdigest(), 'kernel_limits': limits,
              'observations': rows, 'error': error, 'observer_returncode': observer.child.returncode if observer.child else None,
              'model_calls': 0, 'reserve_policy_gib': 16,
              'source': 'https://learn.microsoft.com/en-us/windows/win32/api/sysinfoapi/ns-sysinfoapi-memorystatusex',
              'limit': 'Fresh native counters are volatile. A successful bounded probe is not a stability certificate.'}
    guard.write_new(output, result)
    print(json.dumps({'state': result['state'], 'observations': len(rows), 'error': error}), flush=True)
    return 0 if error is None else 1


def main():
    if len(sys.argv) > 1 and sys.argv[1] == 'probe':
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('mode', choices=['probe'])
        parser.add_argument('--output', type=Path, required=True)
        args = parser.parse_args()
        return probe(args.output)
    if len(sys.argv) < 2 or sys.argv[1] != 'run':
        raise SystemExit('Use probe --output PATH or run with the existing guard arguments')
    output = Path(sys.argv[sys.argv.index('--output') + 1])
    observer = HostObserver(output / 'host_observer.stderr.txt')
    guard.host_memory = observer.read
    sys.argv = [sys.argv[0]] + sys.argv[2:]
    try:
        return guard.main()
    finally:
        observer.close()


if __name__ == '__main__':
    raise SystemExit(main())
