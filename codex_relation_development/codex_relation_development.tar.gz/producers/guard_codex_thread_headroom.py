#!/usr/bin/env python3
"""Reuse native memory supervision with bounded CLI thread headroom.

The original 64-task service recorded pids.peak=64, pids.events max=1 and
a thread-spawn startup panic. This wrapper doubles that ceiling to 128;
memory, swap, CPU, priority, reserve and observation-stop rules are unchanged.
The frozen original guards and their failure records are not modified.
"""
import os
import guard_codex_measurement as native


def verify_limits(cgroup, memory_max, memory_high):
    guard = native.guard
    observed = {key: guard.number_file(cgroup / key) for key in
                ('memory.max', 'memory.high', 'memory.swap.max', 'pids.max')}
    observed['affinity'] = sorted(os.sched_getaffinity(0))
    observed['nice'] = os.getpriority(os.PRIO_PROCESS, 0)
    expected = {'memory.max': memory_max, 'memory.high': memory_high,
                'memory.swap.max': 0, 'pids.max': 128,
                'affinity': [0, 1], 'nice': 19}
    if observed != expected:
        raise ValueError(f'Kernel limits differ: {observed!r}; expected {expected!r}')
    return observed


if __name__ == '__main__':
    native.guard.verify_limits = verify_limits
    raise SystemExit(native.main())
