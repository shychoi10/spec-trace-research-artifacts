"""Same-extraction answer comparison, with no extra evidence for the resolver.

All conditions receive byte-identical question, full selected excerpts, and raw
automatic extraction. Only optional deterministic resolution hints differ.
This is an experimental control, not a GraphRAG reproduction or a result.
"""
import argparse
import json
import os
from pathlib import Path
import socket
import subprocess
import time
import urllib.error
import urllib.request

from resolve_issue_relations import (BASE, canonical, digest, excerpts,
                                     require_completed_control, resolve, validate)
from run_issue_lineage_generation import SYSTEM, SETTINGS, api, verify_answer

MODES = ('extraction_only', 'first_target', 'all_targets')
SYSTEM_COMMON = SYSTEM + '''
An automatic extraction follows the source excerpts. It is a fallible model
hypothesis, not gold annotation. You may correct it using the supplied excerpts.
Optional resolution hints are computations over that same extraction, not new
source evidence. Their invariance only concerns the supplied alternatives, not
semantic truth. Check speaker, event time, technical subject, conditions and
record role against the excerpts. A source's date is the containing record date,
not necessarily the date of a quoted utterance. Missing alternatives or mistaken
extraction can invalidate any hint. Resolve the question from the evidence;
neither extraction nor hints override source text. Preserve unresolved scope.'''


def compact_resolution(decoded):
    """Do not copy evidence again or convert world counts into confidence."""
    if decoded['status'] != 'resolved_hypotheses':
        return dict(status=decoded['status'], worlds_evaluated=decoded['worlds_evaluated'])
    result = []
    for e in decoded['events']:
        alternatives = []
        for a in e['alternatives']:
            content = a['content']
            if content is not None:
                content = dict(proposition=content['proposition'], conditions=[
                    {k: c[k] for k in ('chunk_id', 'occurrence_id', 'part_index', 'quote')}
                    for c in content['conditions']])
            alternatives.append(dict(content=content, paths=a['paths']))
        result.append(dict(id=e['id'], role=e['role'], speaker=e['speaker'],
                           historical_or_copy=e['historical_or_copy'],
                           attachment_invariant=e['attachment_invariant'],
                           alternatives=alternatives,
                           unresolved_reasons=sorted(e['unresolved_reasons'])))
    return dict(status=decoded['status'], events=result,
                semantics='conditional_on_extractor_hypotheses_not_source_truth')


def comparison_messages(question, groups, raw_graph):
    events = validate(raw_graph, groups)
    common = ('QUESTION:\n' + canonical(question) + '\nSOURCE EXCERPTS:\n' +
              '\n'.join(canonical(g) for g in groups) +
              '\nAUTOMATIC EXTRACTION:\n' + canonical(raw_graph))
    hints = dict(extraction_only=None,
                 first_target=compact_resolution(resolve(events, 'first')),
                 all_targets=compact_resolution(resolve(events, 'all')))
    return {mode: [dict(role='system', content=SYSTEM_COMMON),
                   dict(role='user', content=common + '\nOPTIONAL RESOLUTION HINTS:\n' + canonical(hints[mode]))]
            for mode in MODES}


def prepare(bundle_path, extraction_dir, output):
    """Freeze all 42 message pairs before tokenization or any comparison answer.

    Invalid extractions remain explicit failures for all three conditions. No
    manual corrections, omitted excerpts or per-method input selection.
    """
    frozen = require_completed_control()
    bundle = json.loads(bundle_path.read_text())
    if bundle['frozen_inputs_sha256'] != digest(BASE / 'frozen_inputs.json'):
        raise ValueError('Source manifest changed')
    if not (extraction_dir / 'completion.json').exists():
        raise ValueError('Automatic extraction pass is incomplete')
    launch = json.loads((extraction_dir / 'launch.json').read_text())
    if launch['bundle_sha256'] != digest(bundle_path):
        raise ValueError('Extraction bundle differs')
    originals = {r['id']: r for r in frozen['inputs']}
    if [x['id'] for x in bundle['inputs']] != list(originals):
        raise ValueError('Question set differs')
    rows = []
    for index, item in enumerate(bundle['inputs']):
        qid = item['id']
        original = BASE / originals[qid]['path']
        if digest(original) != item['source_input_sha256'] or digest(original) != originals[qid]['sha256']:
            raise ValueError('Original input changed')
        inp = json.loads(original.read_text())
        expected_q = {k: v for k, v in inp['question'].items() if k != 'source_family'}
        if item['groups'] != excerpts(inp) or item['question'] != expected_q:
            raise ValueError('Changed evidence or question')
        path = extraction_dir / (qid + '.response.json')
        decoded_path = extraction_dir / (qid + '.decoded.json')
        response = json.loads(path.read_text())
        check = json.loads(decoded_path.read_text())
        if check['response_sha256'] != digest(path):
            raise ValueError('Extraction response changed')
        row = dict(id=qid, source_input_sha256=digest(original),
                   extraction_response_sha256=digest(path), extraction_check_sha256=digest(decoded_path))
        if check['status'] != 'decoded':
            row.update(status='shared_extraction_failure', reason=check.get('error'), messages={})
        else:
            graph = json.loads(response['content'])
            messages = comparison_messages(item['question'], item['groups'], graph)
            # Rotate execution order across questions without using any outputs.
            order = list(MODES[index % 3:] + MODES[:index % 3])
            row.update(status='ready', messages=messages, execution_order=order)
        rows.append(row)
    result = dict(producer_sha256=digest(__file__), bundle_sha256=digest(bundle_path),
                  extraction_completion_sha256=digest(extraction_dir / 'completion.json'),
                  settings=SETTINGS, context_size=32768, max_prompt_tokens=28672,
                  model_sha256=frozen['model_sha256'], questions=rows,
                  common_information='Identical selected excerpts, metadata, raw automatic extraction',
                  cost='Same generation settings/cap, actual input lengths differ; report all token counts',
                  direct_control_cost_comparable=False, semantic_accuracy='NOT_EVALUATED')
    with output.open('x') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
        f.write('\n')
    return result


def tokenize_all(prepared, port):
    """Caller supplies the separately verified local 32768-context server.

    No answer is requested here. An overlong condition fails the whole preflight;
    do not drop source groups, graph events or hints to force a preferred method.
    """
    tokens = []
    for row in prepared['questions']:
        if row['status'] != 'ready':
            tokens.append(dict(id=row['id'], status=row['status']))
            continue
        conditions = {}
        for mode in row['execution_order']:
            prompt = api(port, 'apply-template', dict(messages=row['messages'][mode],
                chat_template_kwargs={'enable_thinking': False}, reasoning_effort='none'))['prompt']
            if not prompt.endswith('<think>\n\n</think>\n\n'):
                raise ValueError('Wrong local template')
            ids = api(port, 'tokenize', dict(content=prompt, add_special=True, parse_special=True))['tokens']
            if len(ids) > prepared['max_prompt_tokens']:
                raise ValueError(f'Over-budget pair: {row["id"]}/{mode}; no source truncation allowed')
            conditions[mode] = ids
        tokens.append(dict(id=row['id'], status='ready', conditions=conditions))
    return tokens


def run(prepared_path, output, port):
    """Run all prepared comparisons on a separately owned local CPU server."""
    frozen = require_completed_control()
    prepared = json.loads(prepared_path.read_text())
    if prepared['producer_sha256'] != digest(__file__) or prepared['settings'] != SETTINGS:
        raise ValueError('Prepared comparison producer/settings changed')
    if [q['id'] for q in prepared['questions']] != [q['id'] for q in frozen['inputs']]:
        raise ValueError('Comparison question set differs')
    required = [('runtime_launch.json', 'runtime_launch_sha256'),
                ('runtime_verification.json', 'runtime_verification_sha256'),
                ('source_units.json', 'source_units_sha256'),
                ('Qwen3-8B-Q4_K_M.gguf', 'model_sha256')]
    for name, key in required:
        if digest(BASE / name) != frozen[key]:
            raise ValueError('Changed runtime/model/source binding: ' + name)
    if digest(Path(__file__).with_name('run_issue_lineage_generation.py')) != frozen['producer_sha256']:
        raise ValueError('Changed generation helper')
    for entry in json.loads((BASE / 'runtime_verification.json').read_text())['files']:
        if digest(BASE / entry['path']) != entry['sha256']:
            raise ValueError('Changed runtime binary')
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', port))
    output.mkdir(exist_ok=False)

    def save(name, value):
        with (output / name).open('x') as f:
            json.dump(value, f, ensure_ascii=False)
            f.write('\n')

    def append(handle, value):
        handle.write(canonical(value) + '\n')
        handle.flush()
        os.fsync(handle.fileno())

    launch = json.loads((BASE / 'runtime_launch.json').read_text())
    command = launch['command'][:]
    command[command.index('--port') + 1] = str(port)
    command[command.index('--ctx-size') + 1] = str(prepared['context_size'])
    environment = os.environ.copy()
    environment.update(launch['environment_overrides'])
    save('launch.json', dict(command=command, prepared_sha256=digest(prepared_path),
                            producer_sha256=digest(__file__), inference='local_CPU4_GPU0_nice15',
                            model_sha256=frozen['model_sha256']))
    server = None
    try:
        with (output / 'runtime.log').open('x') as log:
            server = subprocess.Popen(['nice', '-n', '15', *command], env=environment,
                                      stdout=log, stderr=subprocess.STDOUT)
        deadline = time.monotonic() + 600
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        while True:
            if server.poll() is not None or time.monotonic() > deadline:
                raise RuntimeError('Comparison server startup failed')
            try:
                with opener.open(f'http://127.0.0.1:{port}/health', timeout=2) as response:
                    if json.load(response)['status'] == 'ok':
                        break
            except (urllib.error.URLError, TimeoutError):
                pass
            time.sleep(2)
        prompts = tokenize_all(prepared, port)
        save('frozen_prompts.json', dict(prepared_sha256=digest(prepared_path), questions=prompts))
        prompt_sha = digest(output / 'frozen_prompts.json')
        units = json.loads((BASE / 'source_units.json').read_text())
        original_rows = {q['id']: q for q in frozen['inputs']}
        total = 0
        failures = []
        # Three append-only ledgers instead of 126 per-question/condition files.
        with (output / 'requests.jsonl').open('x') as requests, \
                (output / 'responses.jsonl').open('x') as responses, \
                (output / 'checks.jsonl').open('x') as checks:
            for row, prompt_row in zip(prepared['questions'], prompts):
                qid = row['id']
                if row['status'] != 'ready':
                    failures.append(qid)
                    for mode in MODES:
                        append(checks, dict(id=qid, mode=mode, status='shared_extraction_failure'))
                    continue
                original_path = BASE / original_rows[qid]['path']
                if digest(original_path) != row['source_input_sha256']:
                    raise ValueError('Original input changed before answer generation')
                original = json.loads(original_path.read_text())
                for mode in row['execution_order']:
                    ids = prompt_row['conditions'][mode]
                    request = SETTINGS | dict(prompt=ids, json_schema={'type': 'object'})
                    started = time.time()
                    append(requests, dict(id=qid, mode=mode, started_unix=started,
                                          frozen_prompts_sha256=prompt_sha, tokens=len(ids),
                                          settings=SETTINGS))
                    response = api(port, 'completion', request)
                    elapsed = time.time() - started
                    append(responses, dict(id=qid, mode=mode, elapsed_seconds=elapsed, response=response))
                    if response.get('truncated') is not False or response.get('tokens_evaluated') != len(ids):
                        raise ValueError('Consumed prompt mismatch or context truncation')
                    try:
                        answer = json.loads(response['content'])
                        check = verify_answer(answer, original, units)
                    except (ValueError, KeyError, TypeError) as error:
                        check = dict(structural_errors=[repr(error)], semantic_correctness='NOT_EVALUATED')
                    append(checks, dict(id=qid, mode=mode, input_tokens=len(ids),
                                       output_tokens=response.get('tokens_predicted'),
                                       stop_type=response.get('stop_type'), elapsed_seconds=elapsed, **check))
                    total += 1
                    print(qid, mode, 'saved', flush=True)
        save('completion.json', dict(questions=len(prepared['questions']), answers_saved=total,
                                    shared_failed_question_ids=failures, denominator_excludes_failures=False,
                                    semantic_accuracy='NOT_EVALUATED', independent_human_labels=0,
                                    artifacts={n: digest(output / n) for n in
                                               ('frozen_prompts.json', 'requests.jsonl', 'responses.jsonl', 'checks.jsonl')}))
    except Exception as error:
        save('failure.json', dict(error=repr(error), automatic_retry=False))
        raise
    finally:
        if server is not None and server.poll() is None:
            server.terminate()
            try:
                server.wait(timeout=30)
            except subprocess.TimeoutExpired:
                server.kill()
                server.wait(timeout=10)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    a = sub.add_parser('prepare')
    a.add_argument('--bundle', type=Path, required=True)
    a.add_argument('--extractions', type=Path, required=True)
    a.add_argument('--output', type=Path, required=True)
    a = sub.add_parser('run')
    a.add_argument('--prepared', type=Path, required=True)
    a.add_argument('--output-dir', type=Path, required=True)
    a.add_argument('--port', type=int, default=18088)
    args = p.parse_args()
    if args.command == 'run':
        run(args.prepared, args.output_dir, args.port)
        return
    result = prepare(args.bundle, args.extractions, args.output)
    print(canonical(dict(questions=len(result['questions']),
                         ready=sum(r['status'] == 'ready' for r in result['questions']),
                         output_sha256=digest(args.output), model_requests=0)))


if __name__ == '__main__':
    main()
