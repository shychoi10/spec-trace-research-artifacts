#!/usr/bin/env python3
"""Freeze and collect source-grounded AI judgments for the relation comparison.

Method names are withheld from the judge prompt. This is a development assessment
with the same configured model family, not human gold or independent validation.
Literal bindings remain separate from the correctness of a semantic judgment.
"""
import argparse
import json
from pathlib import Path

import run_codex_relation_comparison as experiment

OUT = experiment.OUT
REVIEW = OUT / 'assessment'
LABELS = ('A', 'B', 'C', 'D')
POLICY = '''Assess the candidate answers using only the supplied question and
selected source groups. Do not use outside knowledge, infer unseen records,
count duplicated quotations as independent agreement, or treat missing records
as global absence. Source metadata and direct/quoted/copied channels matter.
Candidates are anonymous. No candidate is preferred. Identify both corrected
and newly introduced errors; do not reward verbosity or uncertainty alone.
The requested facets are a decomposition of the original question, not a gold
answer. Different supported formulations are valid. Read the entire answer,
its claims, evidence and uncertainty statements. Assess scope of response
separately from source support and literal citation validity.
For each requested facet and candidate return response complete/partial/absent
and support supported/contradicted/insufficient_evidence/undetermined. Distinguish
target, time_or_quoted_history, speaker_or_role, conditions, version and
record_status errors. Supported individual statements cannot establish group
agreement or normative publication. A claim's cause requires more than a
recorded author's reason. Check all substantive added claims separately.
Source anchors use {chunk_id,occurrence_id,part_index,quote}, with an exact,
nonempty, uniquely occurring substring of that selected source part. Answer
quotes are exact substrings of the raw candidate answer, or null when absent.
Source support and contradiction require anchors. Absence or insufficient
source material can have no anchors if the rationale explains the boundary.
Do not invent an anchor to prove absence. A facet answered with a justified
source-bound uncertainty can be complete and supported. Generic ignorance
without answering the requested distinction is not complete.
Return a JSON object without markdown:
{"question_id":"...","candidates":[{"label":"...","facets":[
{"id":"...","response":"...","support":"...","answer_quote":null,
"source_anchors":[],"error_types":[],"rationale":"..."}],
"added_claims":[{"answer_quote":"...","support":"...",
"source_anchors":[],"error_types":[],"rationale":"..."}],
"citation_issues":[{"answer_quote":"...","rationale":"..."}]}],
"cross_candidate_observations":["..."],"source_limitations":["..."]}.
Include every supplied candidate and every requested facet exactly once.
Added claims should cover substantive assertions outside those facets; an
empty list is allowed when there are none. Do not return an overall score,
statistical significance, causal method effect or a claim of independence.'''


def prepare(answer_summary_path=None):
    plan = experiment.verified_plan()
    answer_summary_path = answer_summary_path or OUT / 'answers/summary.json'
    answer_summary = experiment.read(answer_summary_path)
    answer_plan = experiment.read(OUT / 'answer_plan.json')
    experiment.verify(answer_summary['answer_plan'])
    recovery = answer_summary['state'] == 'AVAILABLE_ANSWER_CALLS_FINISHED_WITH_INTERRUPTION'
    if answer_summary['failure'] or answer_summary['state'] not in {
            'ADMITTED_ANSWER_CALLS_FINISHED', 'AVAILABLE_ANSWER_CALLS_FINISHED_WITH_INTERRUPTION'}:
        raise ValueError('Available answer collection did not finish; do not resample')
    expected = [(q['id'], m) for q in answer_plan['questions'] for m in q['execution_order']]
    interrupted = answer_summary.get('interrupted_calls', [])
    if recovery:
        for key in ('recovery_plan', 'original_summary', 'suffix_summary'):
            experiment.verify(answer_summary[key])
        if [(r['id'], r['mode']) for r in interrupted] != [('LQ06', 'direct')]:
            raise ValueError('Recovery does not match the declared startup interruption')
        for row in interrupted:
            for key in ('result', 'dispatch', 'events', 'stderr'):
                experiment.verify(row[key])
            result = experiment.read(experiment.verify(row['result']))
            if result['state'] != 'FAILED_OR_UNCONTROLLED_TURN' or result['answer'] is not None:
                raise ValueError('Unavailable candidate unexpectedly returned an answer')
        unavailable = {(r['id'], r['mode']) for r in interrupted}
        expected = [r for r in expected if r not in unavailable]
    elif interrupted:
        raise ValueError('Undeclared answer interruption')
    if [(r['id'], r['mode']) for r in answer_summary['results']] != expected:
        raise ValueError('Completed conditions differ from the frozen answer plan')
    protocol_path = OUT / 'assessment_protocol.json'
    protocol = experiment.read(protocol_path)
    experiment.verify(protocol['plan'])
    experiment.verify(protocol['source_protocol'])
    criteria = {q['id']: q for q in protocol['questions']}
    bundle = experiment.read(experiment.verify(plan['bundle']))
    by_question = {q['id']: q for q in bundle['inputs']}
    calls = {(r['id'], r['mode']): r for r in answer_summary['results']}
    REVIEW.mkdir()
    inputs = REVIEW / 'inputs'
    inputs.mkdir()
    policy_path = REVIEW / 'judge_policy.txt'
    experiment.text_new(policy_path, POLICY)
    rows = []
    for index, question in enumerate(answer_plan['questions']):
        qid = question['id']
        modes = list(experiment.MODES[index % 4:] + experiment.MODES[:index % 4])
        modes = [m for m in modes if (qid, m) in calls]
        candidates, bindings, mapping = [], [], {}
        for label, mode in zip(LABELS, modes):
            call = calls[(qid, mode)]
            result = experiment.read(experiment.verify(call['result']))
            experiment.verify(call['literal_check'])
            if result['state'] != 'SAVED_CONTROLLED_ANSWER':
                raise ValueError('Uncontrolled candidate answer')
            binding = result['answer']
            raw = experiment.verify(binding).read_text()
            candidates.append({'label': label, 'answer': raw})
            bindings.append({'label': label, 'answer': binding})
            mapping[label] = mode
        item = by_question[qid]
        packet = {'question': item['question'], 'requested_facets': criteria[qid]['facets'],
                  'selected_source_groups': item['groups'], 'candidate_answers': candidates}
        path = inputs / (qid + '.json')
        experiment.text_new(path, experiment.resolver.canonical(packet))
        rows.append({'id': qid, 'input': experiment.bind(path), 'candidates': bindings,
                     'label_to_mode': mapping, 'shared_extraction_failure': question['shared_extraction_failure'],
                     'admitted_judgment': bool(candidates),
                     'unavailable_answer_modes': [m for m in question['conditions'] if (qid, m) not in calls]})
    review_plan = {'created_utc': experiment.now(), 'state': 'ALL_JUDGE_INPUTS_FROZEN',
                   'model_plan': experiment.bind(OUT / 'plan.json'),
                   'answer_summary': experiment.bind(answer_summary_path),
                   'assessment_protocol': experiment.bind(protocol_path),
                   'producer': experiment.bind(Path(__file__).resolve()),
                   'policy': experiment.bind(policy_path), 'questions': rows,
                   'ordering': 'Original fixed question order; each source-grounded judgment once.',
                   'method_names_withheld_from_prompt': True,
                   'blind_or_independent_validation_certified': False,
                   'human_labels': 0, 'independent_semantic_gold': 0, 'automatic_retries': 0,
                   'full_question_denominator': len(rows),
                   'admitted_judgment_calls': sum(bool(r['candidates']) for r in rows),
                   'interrupted_answer_calls': interrupted,
                   'failure_policy': 'Stop subsequent dispatch after incomplete/uncontrolled transport. Preserve malformed judgments without repair; continue remaining fixed questions.'}
    experiment.save(REVIEW / 'plan.json', review_plan)
    print(json.dumps({'state': review_plan['state'], 'questions': len(rows),
                      'admitted_judgments': review_plan['admitted_judgment_calls']}), flush=True)


def checked_plan():
    model_plan = experiment.verified_plan()
    plan = experiment.read(REVIEW / 'plan.json')
    for key in ('model_plan', 'answer_summary', 'assessment_protocol', 'producer', 'policy'):
        experiment.verify(plan[key])
    for row in plan['questions']:
        experiment.verify(row['input'])
        for candidate in row['candidates']:
            experiment.verify(candidate['answer'])
    model_plan['policies'] = dict(model_plan['policies'], judge=plan['policy'])
    return model_plan, plan


def check_judgment(raw, row):
    packet = experiment.read(experiment.verify(row['input']))
    if raw['question_id'] != row['id']:
        raise ValueError('Wrong judgment question')
    candidates = {c['label']: c['answer'] for c in packet['candidate_answers']}
    facets = {f['id'] for f in packet['requested_facets']}
    if len(raw['candidates']) != len(candidates) or {c['label'] for c in raw['candidates']} != set(candidates):
        raise ValueError('Missing/duplicate judgment candidates')
    groups = {g['chunk_id']: g for g in packet['selected_source_groups']}
    bound = []
    errors = {'target', 'time_or_quoted_history', 'speaker_or_role', 'conditions', 'version', 'record_status'}
    for candidate in raw['candidates']:
        answer = candidates[candidate['label']]
        if len(candidate['facets']) != len(facets) or {f['id'] for f in candidate['facets']} != facets:
            raise ValueError('Missing/duplicate judgment facets')
        for item in candidate['facets'] + candidate['added_claims']:
            if item['support'] not in {'supported', 'contradicted', 'insufficient_evidence', 'undetermined'}:
                raise ValueError('Invalid support category')
            if 'response' in item and item['response'] not in {'complete', 'partial', 'absent'}:
                raise ValueError('Invalid response category')
            quote = item['answer_quote']
            if quote is not None and (not isinstance(quote, str) or not quote or quote not in answer):
                raise ValueError('Judgment answer quote missing')
            if not isinstance(item['rationale'], str) or not item['rationale']:
                raise ValueError('Missing judgment rationale')
            if not isinstance(item['error_types'], list) or any(e not in errors for e in item['error_types']):
                raise ValueError('Invalid interpretation error category')
            if not isinstance(item['source_anchors'], list):
                raise ValueError('Invalid judgment anchor list')
            if item['support'] in {'supported', 'contradicted'} and not item['source_anchors']:
                raise ValueError('Source support/contradiction without an anchor')
            anchors = [experiment.resolver.bind_anchor(a, groups) for a in item['source_anchors']]
            bound.append({'label': candidate['label'], 'facet': item.get('id'), 'anchors': anchors})
        for issue in candidate['citation_issues']:
            if not isinstance(issue['answer_quote'], str) or not issue['answer_quote'] or issue['answer_quote'] not in answer:
                raise ValueError('Citation issue quote missing')
            if not isinstance(issue['rationale'], str) or not issue['rationale']:
                raise ValueError('Citation issue rationale missing')
    for key in ('cross_candidate_observations', 'source_limitations'):
        if not isinstance(raw[key], list) or any(not isinstance(v, str) for v in raw[key]):
            raise ValueError('Invalid judgment observation list')
    return {'state': 'JUDGMENT_FORMAT_AND_LITERAL_ANCHORS_BOUND', 'anchors': bound,
            'semantic_judgment_certified': False, 'author_readback_completed': False}


def run():
    experiment.guarded()
    model_plan, plan = checked_plan()
    output = REVIEW / 'run'
    output.mkdir()
    rows, failure = [], None
    try:
        for row in plan['questions']:
            destination = output / row['id']
            if not row['admitted_judgment']:
                destination.mkdir()
                unavailable = {'state': 'NO_AVAILABLE_CANDIDATE_NO_JUDGMENT_DISPATCH',
                               'question_id': row['id'], 'input': row['input'],
                               'unavailable_answer_modes': row['unavailable_answer_modes'],
                               'semantic_error': False, 'model_calls': 0}
                experiment.save(destination / 'unavailable.json', unavailable)
                rows.append({'id': row['id'], 'unavailable': experiment.bind(destination / 'unavailable.json')})
                continue
            answer = experiment.turn(model_plan, destination, row['input'], 'judge')
            try:
                check = check_judgment(experiment.read(answer), row)
            except (ValueError, KeyError, TypeError, AttributeError) as error:
                check = {'state': 'INVALID_JUDGMENT_FORMAT_OR_LITERAL_BINDING', 'error': repr(error),
                         'semantic_judgment_certified': False, 'author_readback_completed': False}
            experiment.save(destination / 'literal_check.json', check)
            rows.append({'id': row['id'], 'result': experiment.bind(destination / 'result.json'),
                         'literal_check': experiment.bind(destination / 'literal_check.json')})
    except Exception as error:
        failure = repr(error)
    experiment.save(output / 'summary.json', {'finished_utc': experiment.now(),
        'plan': experiment.bind(REVIEW / 'plan.json'), 'questions': rows, 'failure': failure,
        'state': 'ALL_ADMITTED_JUDGMENTS_COLLECTED' if failure is None else 'STOPPED_INCOMPLETE_OR_UNCONTROLLED',
        'full_question_denominator': plan['full_question_denominator'],
        'admitted_judgment_calls': plan['admitted_judgment_calls'],
        'returned_judgment_calls': sum('result' in row for row in rows),
        'unavailable_question_ids': [r['id'] for r in rows if 'unavailable' in r],
        'human_labels': 0, 'independent_semantic_gold': 0, 'model_retries': 0,
        'author_readback_completed': False})
    if failure is not None:
        raise RuntimeError(failure)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'run'])
    parser.add_argument('--answer-summary', type=Path,
                        help='Explicit recovered collection summary; original terminal failure stays unchanged')
    args = parser.parse_args()
    if args.mode == 'prepare':
        prepare(args.answer_summary)
    else:
        if args.answer_summary is not None:
            parser.error('--answer-summary only applies to prepare')
        run()
