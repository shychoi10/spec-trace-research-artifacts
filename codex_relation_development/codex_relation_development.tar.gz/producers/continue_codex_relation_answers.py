#!/usr/bin/env python3
"""Complete only undispatched answer inputs after a recorded CLI startup panic.

Keep the original 44-call plan, seventeen returned answers and failed LQ06
call immutable. Scientific inputs/policies and model configuration do not
change. The separate recovery doubles only the local task ceiling to 128.
"""
import argparse
from pathlib import Path
import subprocess

import run_codex_relation_comparison as experiment

OUT = experiment.OUT
RECOVERY = OUT / 'answer_recovery'


def prepare():
    experiment.verified_plan()
    properties = subprocess.check_output(['systemctl', '--user', 'show',
        'spectra-kdd-relations-answer.service', '-p', 'ActiveState', '-p',
        'MainPID', '-p', 'ExecMainStatus'], text=True)
    actual = dict(line.split('=', 1) for line in properties.splitlines())
    if actual['MainPID'] != '0' or actual['ActiveState'] != 'failed':
        raise ValueError('Original answer job is not a terminal failure')
    original_summary = experiment.read(OUT / 'answers/summary.json')
    if original_summary['state'] != 'STOPPED_INCOMPLETE_OR_UNCONTROLLED':
        raise ValueError('Unexpected original answer collection state')
    plan = experiment.read(OUT / 'answer_plan.json')
    parity = experiment.read(OUT / 'answer_input_verification.json')
    experiment.verify(parity['answer_plan'])
    stop = experiment.read(OUT / 'answer_interruption/stop_record.json')
    experiment.verify(stop['stderr'])
    if stop['pids_peak'] != '64' or stop['pids_max'] != '64' or stop['call'] != 'LQ06/direct':
        raise ValueError('Unexpected observed thread-limit failure')
    closed, interrupted, untouched = [], [], []
    for question in plan['questions']:
        for mode in question['execution_order']:
            condition = question['conditions'][mode]
            experiment.verify(condition['input'])
            directory = OUT / 'answers' / question['id'] / mode
            item = {'id': question['id'], 'mode': mode, 'condition': condition}
            if (directory / 'result.json').exists():
                result = experiment.read(directory / 'result.json')
                if result['state'] == 'SAVED_CONTROLLED_ANSWER':
                    for key in ('answer', 'events', 'stderr'):
                        experiment.verify(result[key])
                    item.update(result=experiment.bind(directory / 'result.json'),
                                literal_check=experiment.bind(directory / 'literal_check.json'))
                    closed.append(item)
                elif result['state'] == 'FAILED_OR_UNCONTROLLED_TURN':
                    if result['answer'] is not None or result['event_count'] != 0:
                        raise ValueError('Unexpected partial answer/turn events')
                    item.update(result=experiment.bind(directory / 'result.json'),
                                dispatch=experiment.bind(directory / 'dispatch.json'),
                                events=result['events'], stderr=result['stderr'],
                                semantic_error=False, retry_permitted=False)
                    interrupted.append(item)
                else:
                    raise ValueError('Unknown result state')
            elif directory.exists():
                raise ValueError('Unclosed answer directory')
            else:
                untouched.append(item)
    if len(closed) != 17 or [(r['id'], r['mode']) for r in interrupted] != [('LQ06', 'direct')] or len(untouched) != 26:
        raise ValueError('Observed answer prefix differs from this declared recovery')
    if [(r['id'], r['mode']) for r in closed] != [(r['id'], r['mode']) for r in original_summary['results']]:
        raise ValueError('Closed prefix differs from original terminal summary')
    RECOVERY.mkdir()
    result = {'state': 'UNDISPATCHED_ANSWER_SUFFIX_FROZEN', 'created_utc': experiment.now(),
              'answer_plan': experiment.bind(OUT / 'answer_plan.json'),
              'model_plan': experiment.bind(OUT / 'plan.json'),
              'original_summary': experiment.bind(OUT / 'answers/summary.json'),
              'stop_record': experiment.bind(OUT / 'answer_interruption/stop_record.json'),
              'original_guard_result': experiment.bind(experiment.BASE / 'codex_relation_answer_guard/result.json'),
              'native_guard': experiment.bind(Path(__file__).with_name('guard_codex_measurement.py')),
              'headroom_guard': experiment.bind(Path(__file__).with_name('guard_codex_thread_headroom.py')),
              'producer': experiment.bind(Path(__file__).resolve()), 'unit_state': actual,
              'closed_calls': closed, 'interrupted_calls': interrupted, 'new_calls': untouched,
              'resource_amendment': {'pids_max_before': 64, 'pids_max_after': 128,
                  'reason': 'Observed 64-task saturation and one denied creation accompanying a CLI startup thread panic. Double bounded task headroom while preserving CPU2/nice19, MemoryMax2GiB/High1GiB/SwapMax0 and host/WSL reserve16GiB.'},
              'protocol_amendment': 'Original collector stopped as specified. Dispatch each still-absent frozen input once in original order. Never repeat the failed LQ06 request or any returned call. Keep all fourteen questions, with explicit answer unavailability, for source-grounded assessment.',
              'model_retries': 0, 'human_labels': 0, 'independent_semantic_gold': 0}
    experiment.save(RECOVERY / 'plan.json', result)
    print(experiment.resolver.canonical({'state': result['state'], 'closed_calls': 17,
                                       'interrupted_calls': 1, 'new_calls': 26}), flush=True)


def checked():
    model = experiment.verified_plan()
    plan = experiment.read(RECOVERY / 'plan.json')
    for key in ('answer_plan', 'model_plan', 'original_summary', 'stop_record',
                'original_guard_result', 'native_guard', 'headroom_guard', 'producer'):
        experiment.verify(plan[key])
    for row in plan['closed_calls']:
        experiment.verify(row['result'])
        experiment.verify(row['literal_check'])
    for row in plan['interrupted_calls']:
        for key in ('result', 'dispatch', 'events', 'stderr'):
            experiment.verify(row[key])
    for row in plan['new_calls']:
        experiment.verify(row['condition']['input'])
    return model, plan


def run():
    experiment.guarded()
    model, plan = checked()
    originals = {p['id']: experiment.read(experiment.verify(p['source_input'])) for p in model['inputs']}
    units = experiment.read(experiment.BASE / 'source_units.json')
    output = RECOVERY / 'calls'
    output.mkdir()
    rows, failure = [], None
    try:
        for row in plan['new_calls']:
            destination = output / row['id'] / row['mode']
            destination.parent.mkdir(exist_ok=True)
            condition = row['condition']
            answer = experiment.turn(model, destination, condition['input'], condition['policy'])
            try:
                audit = experiment.legacy.verify_answer(experiment.read(answer), originals[row['id']], units)
            except (ValueError, KeyError, TypeError, AttributeError) as error:
                audit = {'structural_errors': [repr(error)], 'literal_bindings': [],
                         'semantic_correctness': 'NOT_EVALUATED'}
            experiment.save(destination / 'literal_check.json', audit)
            rows.append({'id': row['id'], 'mode': row['mode'],
                         'result': experiment.bind(destination / 'result.json'),
                         'literal_check': experiment.bind(destination / 'literal_check.json')})
    except Exception as error:
        failure = repr(error)
    experiment.save(RECOVERY / 'summary.json', {'finished_utc': experiment.now(),
        'plan': experiment.bind(RECOVERY / 'plan.json'), 'results': rows, 'failure': failure,
        'state': 'UNDISPATCHED_ANSWER_SUFFIX_FINISHED' if failure is None else 'STOPPED_INCOMPLETE_OR_UNCONTROLLED',
        'model_retries': 0, 'human_labels': 0, 'independent_semantic_gold': 0})
    if failure is not None:
        raise RuntimeError(failure)
    available = [{k: r[k] for k in ('id', 'mode', 'result', 'literal_check')}
                 for r in plan['closed_calls']] + rows
    experiment.save(RECOVERY / 'collection_summary.json', {'finished_utc': experiment.now(),
        'state': 'AVAILABLE_ANSWER_CALLS_FINISHED_WITH_INTERRUPTION',
        'answer_plan': plan['answer_plan'], 'recovery_plan': experiment.bind(RECOVERY / 'plan.json'),
        'original_summary': plan['original_summary'], 'suffix_summary': experiment.bind(RECOVERY / 'summary.json'),
        'results': available, 'interrupted_calls': plan['interrupted_calls'],
        'full_question_denominator': 14, 'originally_planned_calls': 44,
        'returned_controlled_calls': len(available), 'failure': None,
        'model_retries': 0, 'human_labels': 0, 'independent_semantic_gold': 0})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'run'])
    args = parser.parse_args()
    {'prepare': prepare, 'run': run}[args.mode]()
