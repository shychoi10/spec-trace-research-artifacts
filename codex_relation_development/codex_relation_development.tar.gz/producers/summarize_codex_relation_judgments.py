#!/usr/bin/env python3
"""Account for first saved AI labels, preserving invalid judgments and absences.

Raw labels are descriptive development observations, not accuracy scores. A
source-bound uncertainty may receive complete even when requested text is not
retrieved. Whole-judgment acceptance and per-item literal diagnostics stay
separate from semantic author inspection.
"""
import argparse
from collections import Counter
from pathlib import Path

import assess_codex_relation_comparison as assessment
import run_codex_relation_comparison as experiment


def main(output):
    experiment.guarded()
    _, plan = assessment.checked_plan()
    run = assessment.REVIEW / 'run'
    summary = experiment.read(run / 'summary.json')
    if (summary['state'] != 'ALL_ADMITTED_JUDGMENTS_COLLECTED' or summary['failure']
            or summary['returned_judgment_calls'] != 13
            or summary['unavailable_question_ids'] != ['LQ06']):
        raise ValueError('The original admitted first-judgment collection is incomplete')
    experiment.verify(summary['plan'])
    counts = {mode: Counter() for mode in experiment.MODES}
    paired_counts = {mode: Counter() for mode in experiment.MODES}
    rows, readbacks = [], []
    for row in plan['questions']:
        qid = row['id']
        if not row['admitted_judgment']:
            rows.append({'id': qid, 'state': 'NO_AVAILABLE_ANSWER',
                         'unavailable': experiment.bind(run / qid / 'unavailable.json')})
            continue
        saved = next(r for r in summary['questions'] if r['id'] == qid)
        result = experiment.read(experiment.verify(saved['result']))
        check = experiment.read(experiment.verify(saved['literal_check']))
        raw = experiment.read(experiment.verify(result['answer']))
        author_path = experiment.OUT / 'author_readback' / (qid + '.json')
        author = experiment.read(author_path)
        if author['human_labels'] != 0 or author['independent_semantic_gold'] != 0:
            raise ValueError('Undeclared semantic gold')
        if author['full_raw_answers_read'] != [c['answer'] for c in row['candidates']]:
            # Two original pre-judgment readbacks use original mode order;
            # binding equality, not anonymous label order, is relevant here.
            actual = {b['sha256'] for b in author['full_raw_answers_read']}
            expected = {c['answer']['sha256'] for c in row['candidates']}
            if actual != expected:
                raise ValueError('Author answer readback does not cover every candidate')
        readbacks.append(experiment.bind(author_path))
        candidates = []
        paired = len(row['candidates']) == 4
        for candidate in raw['candidates']:
            mode = row['label_to_mode'][candidate['label']]
            for facet in candidate['facets']:
                fields = ('response:' + facet['response'], 'support:' + facet['support'])
                for field in fields:
                    counts[mode][field] += 1
                    if paired:
                        paired_counts[mode][field] += 1
            candidates.append({'label': candidate['label'], 'mode': mode,
                               'facets': candidate['facets'], 'added_claims': candidate['added_claims'],
                               'citation_issues': candidate['citation_issues']})
        rows.append({'id': qid, 'input': row['input'], 'result': saved['result'],
                     'raw_judgment': result['answer'], 'original_literal_check': saved['literal_check'],
                     'original_literal_state': check['state'], 'paired_four_conditions': paired,
                     'candidates': candidates, 'observations': raw['cross_candidate_observations'],
                     'source_limitations': raw['source_limitations']})
    value = {'state': 'FIRST_AI_LABELS_AND_BOUNDED_ANSWER_READBACK_ACCOUNTED',
             'observed_utc': experiment.now(), 'producer': experiment.bind(Path(__file__).resolve()),
             'plan': experiment.bind(assessment.REVIEW / 'plan.json'),
             'completed_run': experiment.bind(run / 'summary.json'),
             'answer_accounting': experiment.bind(experiment.OUT / 'completed_answer_accounting.json'),
             'author_answer_readbacks': readbacks, 'questions': rows,
             'full_question_denominator': 14, 'fixed_requested_facets': 35,
             'controlled_answers_read': 43, 'returned_first_ai_judgments': 13,
             'paired_question_denominator': 10, 'paired_requested_facets': 27,
             'raw_available_facet_labels_by_mode': {k: dict(v) for k, v in counts.items()},
             'raw_paired_facet_labels_by_mode': {k: dict(v) for k, v in paired_counts.items()},
             'whole_judgment_literal_states': dict(Counter(r['original_literal_state'] for r in rows
                                                         if 'original_literal_state' in r)),
             'interpretation': ['Raw labels from invalid judgments are retained as raw observations, not accepted scores.',
                                'Complete source-bound uncertainty does not recover missing requested source text.',
                                'One source component and dependent facets do not supply independent statistical samples.',
                                'Author readback is AI author inspection of bounded source parts, not human or independent gold.'],
             'original_labels_or_acceptance_rule_changed': False, 'semantic_accuracy_certified': False,
             'general_method_advantage_established': False, 'human_labels': 0,
             'independent_semantic_gold': 0, 'new_model_calls': 0, 'model_retries': 0}
    experiment.save(output, value)
    print({'state': value['state'], 'answers_read': 43, 'first_judgments': 13,
           'whole_judgment_literal_states': value['whole_judgment_literal_states']})


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    main(parser.parse_args().output)
