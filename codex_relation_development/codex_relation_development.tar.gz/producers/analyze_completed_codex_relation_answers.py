#!/usr/bin/env python3
"""Aggregate actually returned relation answers, preserving unavailable calls.

This is operational and literal accounting. It assigns no semantic score.
The full workload and the paired valid-extraction subset remain distinct.
"""
import argparse
from collections import Counter
import json
from pathlib import Path

import summarize_codex_relation_comparison as inspect

BASE = inspect.BASE


def analyze():
    summary_path = BASE / 'answer_recovery/collection_summary.json'
    summary = inspect.read(summary_path)
    if summary['state'] != 'AVAILABLE_ANSWER_CALLS_FINISHED_WITH_INTERRUPTION' or summary['failure']:
        raise ValueError('Recovered available calls have not finished')
    plan = inspect.read(inspect.verify(summary['answer_plan']))
    for key in ('recovery_plan', 'original_summary', 'suffix_summary'):
        inspect.verify(summary[key])
    interrupted = {(r['id'], r['mode']): r for r in summary['interrupted_calls']}
    expected = [(q['id'], m) for q in plan['questions'] for m in q['execution_order']]
    rows = summary['results']
    if [(r['id'], r['mode']) for r in rows] != [v for v in expected if v not in interrupted]:
        raise ValueError('Recovered call set/order differs from original frozen plan')
    for row in interrupted.values():
        result = inspect.read(inspect.verify(row['result']))
        if result['state'] != 'FAILED_OR_UNCONTROLLED_TURN' or result['answer'] is not None:
            raise ValueError('Unexpected recovered interruption')
    decoded = {q['id']: inspect.read(inspect.verify(q['extraction'])) for q in plan['questions']}
    protocol = inspect.read(BASE / 'assessment_protocol.json')
    facets = {q['id']: len(q['facets']) for q in protocol['questions']}
    by_mode = {m: [] for m in inspect.MODES}
    paired = {m: [] for m in inspect.MODES}
    calls = []
    for row in rows:
        value = inspect.call(inspect.verify(row['result']))
        check_path = inspect.verify(row['literal_check'])
        check = inspect.read(check_path)
        quotes = check['literal_bindings']
        value.update(id=row['id'], mode=row['mode'],
                     literal_check=inspect.binding(check_path),
                     structural_errors=check['structural_errors'],
                     evidence_strings=len(quotes),
                     strings_with_literal_matches=sum(bool(v.get('matches')) for v in quotes))
        by_mode[row['mode']].append(value)
        if decoded[row['id']]['status'] == 'decoded':
            paired[row['mode']].append(value)
        calls.append(value)
    extraction_calls = []
    paired_extractions = []
    for qid, record in decoded.items():
        if record['status'] == 'resource_interrupted':
            continue
        path = BASE / ('extraction' if qid <= 'LQ08' else 'continuation/extraction') / qid / 'result.json'
        value = inspect.call(path)
        extraction_calls.append(value)
        if record['status'] == 'decoded':
            paired_extractions.append(value)
    interventions = inspect.read(BASE / 'hint_field_differences.json')
    changed = interventions['questions']
    return {'state': 'AVAILABLE_ANSWER_OPERATIONAL_AND_LITERAL_ACCOUNTING_COMPLETE',
            'producer': inspect.binding(Path(__file__).resolve()),
            'accounting_helper': inspect.binding(Path(inspect.__file__).resolve()),
            'collection_summary': inspect.binding(summary_path),
            'answer_plan': summary['answer_plan'],
            'assessment_protocol': inspect.binding(BASE / 'assessment_protocol.json'),
            'hint_field_differences': inspect.binding(BASE / 'hint_field_differences.json'),
            'full_question_denominator': len(plan['questions']), 'requested_facets': sum(facets.values()),
            'originally_planned_answer_calls': len(expected), 'controlled_returned_answer_calls': len(calls),
            'interrupted_answer_calls': list(interrupted.values()),
            'interrupted_answer_usage': 'UNOBSERVED', 'interrupted_extraction_usage': 'UNOBSERVED',
            'extraction_counts': dict(Counter(v['status'] for v in decoded.values())),
            'decoded_question_ids': [q for q, v in decoded.items() if v['status'] == 'decoded'],
            'completed_extraction_usage': inspect.totals(extraction_calls),
            'completed_extraction_usage_on_decoded_questions': inspect.totals(paired_extractions),
            'completed_answer_usage_by_mode': {m: inspect.totals(v) for m, v in by_mode.items()},
            'completed_answer_usage_on_decoded_questions_by_mode': {m: inspect.totals(v) for m, v in paired.items()},
            'available_question_ids_by_mode': {m: [v['id'] for v in rs] for m, rs in by_mode.items()},
            'available_requested_facets_by_mode': {m: sum(facets[v['id']] for v in rs) for m, rs in by_mode.items()},
            'questions_with_changed_proposition_conditions_or_invariance': [r['id'] for r in changed
                if any(set(e['changed_fields']) & {'proposition_or_condition_alternatives', 'attachment_invariance'}
                       for e in r['changed_events'])],
            'questions_with_only_changed_unresolved_reasons': [r['id'] for r in changed
                if r['changed_events'] and all(e['changed_fields'] == ['unresolved_reason_categories']
                                              for e in r['changed_events'])],
            'questions_with_identical_hints': [r['id'] for r in changed if not r['changed_events']],
            'calls': calls, 'human_labels': 0, 'independent_semantic_gold': 0,
            'semantic_accuracy': 'NOT_EVALUATED', 'new_model_calls': 0,
            'interpretation': 'Counts of matching evidence strings/valid indices do not certify entailment. Direct returns thirteen of fourteen planned answers; each dependent condition returns ten. For a paired ten-question cost comparison, each graph condition requires its answer usage plus one shared-extraction pass per question. Interrupted usage is unknown, not zero. No monetary or efficiency advantage is inferred.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = analyze()
    with args.output.open('x') as handle:
        json.dump(result, handle, ensure_ascii=False, indent=2)
        handle.write('\n')
    print(json.dumps({k: result[k] for k in ('state', 'full_question_denominator',
                     'controlled_returned_answer_calls', 'available_requested_facets_by_mode')}), flush=True)
