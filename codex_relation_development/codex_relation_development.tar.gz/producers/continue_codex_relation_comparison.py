#!/usr/bin/env python3
"""Finish never-dispatched questions after an observed resource-guard failure.

The first pass, interrupted request and original stop policy remain preserved.
This declared recovery never repeats a returned or interrupted model request.
The interrupted question remains unavailable for graph-dependent conditions.
"""
import argparse
import json
from pathlib import Path
import subprocess

import run_codex_relation_comparison as experiment
import guard_codex_measurement as native_guard

OUT = experiment.OUT
RECOVERY = OUT / 'continuation'
OLD_GUARD = experiment.BASE / 'codex_relation_extract_guard'
OLD_UNIT = 'spectra-kdd-codex-relations-extract.service'


def terminal_guard():
    properties = subprocess.check_output(['systemctl', '--user', 'show', OLD_UNIT,
        '-p', 'ActiveState', '-p', 'MainPID', '-p', 'ExecMainStatus'], text=True)
    actual = dict(line.split('=', 1) for line in properties.splitlines())
    if actual['MainPID'] != '0' or actual['ActiveState'] not in {'failed', 'inactive'}:
        raise ValueError('The first extraction job is not terminal')
    result = experiment.read(OLD_GUARD / 'result.json')
    if result['state'] != 'STOPPED_GUARD_ERROR' or result['error_type'] != 'TimeoutExpired':
        raise ValueError('Unexpected interruption; do not assume this recovery applies')
    return actual


def prepare():
    plan = experiment.verified_plan()
    unit_state = terminal_guard()
    probe_path = OUT / 'native_host_observer_probe.json'
    probe = experiment.read(probe_path)
    if probe['state'] != 'NATIVE_HOST_OBSERVER_PROBE_PASS' or probe['model_calls'] != 0:
        raise ValueError('Native observation has not been verified')
    guard_path = Path(native_guard.__file__).resolve()
    if experiment.bind(guard_path)['sha256'] != probe['producer_sha256']:
        raise ValueError('Native guard differs from the probed producer')
    closed, interrupted, untouched = [], [], []
    for row in plan['inputs']:
        directory = OUT / 'extraction' / row['id']
        if (directory / 'decoded.json').exists():
            record = experiment.read(directory / 'decoded.json')
            result = experiment.read(experiment.verify(record['call']))
            experiment.verify(record['answer'])
            if result['state'] != 'SAVED_CONTROLLED_ANSWER':
                raise ValueError('Completed prefix contains an uncontrolled call')
            closed.append({'id': row['id'], 'decoded': experiment.bind(directory / 'decoded.json')})
        elif (directory / 'dispatch.json').exists():
            events = experiment.collector.inspect_events(directory / 'events.jsonl')
            if events['turn_completed_events'] or (directory / 'answer.txt').exists() or (directory / 'result.json').exists():
                raise ValueError('Interrupted request has an unexpected returned result')
            interrupted.append({'id': row['id'], 'status': 'resource_interrupted',
                'dispatch': experiment.bind(directory / 'dispatch.json'),
                'events': experiment.bind(directory / 'events.jsonl'),
                'stderr': experiment.bind(directory / 'stderr.txt'),
                'semantic_error': False, 'retry_permitted': False})
        elif directory.exists():
            raise ValueError('Unclassified extraction directory')
        else:
            untouched.append(row['id'])
    if [r['id'] for r in closed] != ['LQ%02d' % n for n in range(1, 9)] or [r['id'] for r in interrupted] != ['LQ09'] or untouched != ['LQ%02d' % n for n in range(10, 15)]:
        raise ValueError('Observed workload differs from this declared recovery')
    RECOVERY.mkdir()
    interruption = {'recorded_utc': experiment.now(), 'original_plan': experiment.bind(OUT / 'plan.json'),
        'guard_result': experiment.bind(OLD_GUARD / 'result.json'), 'unit_state': unit_state,
        'closed_questions': closed, 'interrupted_questions': interrupted,
        'never_dispatched_questions': untouched,
        'original_extraction_summary_written': False,
        'reason': 'Host CIM observation timed out. The first batch was stopped. Last observed cgroup records have no OOM; this is not a semantic model failure.'}
    experiment.save(RECOVERY / 'interruption.json', interruption)
    recovery_plan = {'created_utc': experiment.now(), 'state': 'NEVER_DISPATCHED_SUFFIX_FROZEN',
        'original_plan': experiment.bind(OUT / 'plan.json'),
        'interruption': experiment.bind(RECOVERY / 'interruption.json'),
        'native_observer_probe': experiment.bind(probe_path), 'native_guard': experiment.bind(guard_path),
        'producer': experiment.bind(Path(__file__).resolve()), 'questions': untouched,
        'contract': 'Complete only LQ10–14 once with the unchanged inputs, policy and model configuration. Do not repeat LQ01–09. Keep LQ09 unavailable for all three graph-dependent answer conditions. Direct answering retains every original question.',
        'protocol_amendment': 'The original batch obeyed its stop policy. This separately frozen suffix follows an observed operational repair, not a retry of incomplete or undesirable outputs. Original plans, calls and the interruption remain unchanged.',
        'automatic_retries': 0, 'semantic_gold': 0}
    experiment.save(RECOVERY / 'plan.json', recovery_plan)
    print(json.dumps({'state': recovery_plan['state'], 'returned_prefix': len(closed),
                      'interrupted': len(interrupted), 'new_calls': len(untouched)}), flush=True)


def verified():
    original = experiment.verified_plan()
    plan = experiment.read(RECOVERY / 'plan.json')
    for name in ('original_plan', 'interruption', 'native_observer_probe', 'native_guard', 'producer'):
        experiment.verify(plan[name])
    interruption = experiment.read(experiment.verify(plan['interruption']))
    experiment.verify(interruption['guard_result'])
    for row in interruption['closed_questions']:
        experiment.verify(row['decoded'])
    for row in interruption['interrupted_questions']:
        for name in ('dispatch', 'events', 'stderr'):
            experiment.verify(row[name])
    return original, plan, interruption


def extract():
    experiment.guarded()
    original, plan, interruption = verified()
    items = {r['id']: r for r in experiment.read(experiment.verify(original['bundle']))['inputs']}
    prepared = {r['id']: r for r in original['inputs']}
    output = RECOVERY / 'extraction'
    output.mkdir()
    rows, failure = [], None
    try:
        for qid in plan['questions']:
            destination = output / qid
            answer = experiment.turn(original, destination, prepared[qid]['extraction_input'], 'extract')
            check = {'id': qid, 'answer': experiment.bind(answer), 'call': experiment.bind(destination / 'result.json')}
            try:
                graph = experiment.read(answer)
                if not isinstance(graph.get('unestablished'), list) or any(not isinstance(v, str) for v in graph['unestablished']):
                    raise ValueError('Invalid unestablished list')
                events = experiment.resolver.validate(graph, items[qid]['groups'])
                check.update(status='decoded', event_count=len(events), empty_graph=not events,
                    first=experiment.resolver.resolve(events, 'first'), all=experiment.resolver.resolve(events, 'all'))
            except (ValueError, KeyError, TypeError, AttributeError) as error:
                check.update(status='invalid_extraction', error=repr(error))
            experiment.save(destination / 'decoded.json', check)
            rows.append({'id': qid, 'decoded': experiment.bind(destination / 'decoded.json')})
            print(json.dumps({'id': qid, 'status': check['status'], 'event_count': check.get('event_count')}), flush=True)
    except Exception as error:
        failure = repr(error)
    experiment.save(output / 'summary.json', {'finished_utc': experiment.now(), 'plan': experiment.bind(RECOVERY / 'plan.json'),
        'state': 'NEVER_DISPATCHED_SUFFIX_FINISHED' if failure is None else 'STOPPED_INCOMPLETE_OR_UNCONTROLLED',
        'returned_prefix': interruption['closed_questions'], 'interrupted_questions': interruption['interrupted_questions'],
        'new_rows': rows, 'failure': failure, 'model_retries': 0, 'total_original_questions': 14})
    if failure is not None:
        raise RuntimeError(failure)


def prepare_answers():
    original, plan, interruption = verified()
    summary_path = RECOVERY / 'extraction/summary.json'
    summary = experiment.read(summary_path)
    experiment.verify(summary['plan'])
    if summary['failure'] or [r['id'] for r in summary['new_rows']] != plan['questions']:
        raise ValueError('The suffix did not finish; do not restart')
    checks = {r['id']: r['decoded'] for r in interruption['closed_questions'] + summary['new_rows']}
    for row in interruption['interrupted_questions']:
        path = RECOVERY / (row['id'] + '.unavailable.json')
        experiment.save(path, row)
        checks[row['id']] = experiment.bind(path)
    items = experiment.read(experiment.verify(original['bundle']))['inputs']
    inputs = RECOVERY / 'answer_inputs'
    inputs.mkdir()
    rows = []
    for index, (prepared, item) in enumerate(zip(original['inputs'], items)):
        check = experiment.read(experiment.verify(checks[item['id']]))
        conditions = {'direct': {'input': prepared['direct_input'], 'policy': 'direct'}}
        if check['status'] == 'decoded':
            experiment.verify(check['call'])
            graph = experiment.read(experiment.verify(check['answer']))
            for mode, pair in experiment.comparison.comparison_messages(item['question'], item['groups'], graph).items():
                if pair[0]['content'] != experiment.verify(original['policies']['comparison']).read_text():
                    raise ValueError('Comparison policy changed')
                path = inputs / (item['id'] + '.' + mode + '.txt')
                experiment.text_new(path, pair[1]['content'])
                conditions[mode] = {'input': experiment.bind(path), 'policy': 'comparison'}
        order = experiment.MODES[index % 4:] + experiment.MODES[:index % 4]
        rows.append({'id': item['id'], 'extraction': checks[item['id']], 'conditions': conditions,
            'execution_order': [mode for mode in order if mode in conditions],
            'shared_extraction_failure': check['status'] != 'decoded', 'extraction_status': check['status']})
    answer_plan = {'created_utc': experiment.now(), 'plan': experiment.bind(OUT / 'plan.json'),
        'extraction_summary': experiment.bind(summary_path), 'recovery_plan': experiment.bind(RECOVERY / 'plan.json'),
        'questions': rows, 'denominator': 'All fourteen questions; invalid and resource-interrupted extractions retain skipped downstream conditions.',
        'semantic_accuracy': 'NOT_YET_EVALUATED', 'automatic_retries': 0}
    experiment.save(OUT / 'answer_plan.json', answer_plan)
    print(json.dumps({'state': 'ALL_ADMITTED_ANSWER_INPUTS_FROZEN', 'questions': len(rows),
        'planned_calls': sum(len(row['conditions']) for row in rows)}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['prepare', 'extract', 'prepare-answers'])
    mode = parser.parse_args().mode
    {'prepare': prepare, 'extract': extract, 'prepare-answers': prepare_answers}[mode]()
